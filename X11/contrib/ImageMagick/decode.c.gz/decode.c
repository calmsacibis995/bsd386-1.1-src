/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%                   DDDD   EEEEE   CCCC   OOO   DDDD   EEEEE                  %
%                   D   D  E      C      O   O  D   D  E                      %
%                   D   D  EEE    C      O   O  D   D  EEE                    %
%                   D   D  E      C      O   O  D   D  E                      %
%                   DDDD   EEEEE   CCCC   OOO   DDDD   EEEEE                  %
%                                                                             %
%                                                                             %
%                    Utility Routines to Read Image Formats                   %
%                                                                             %
%                                                                             %
%                                                                             %
%                             Software Design                                 %
%                               John Cristy                                   %
%                              January 1992                                   %
%                                                                             %
%                                                                             %
%  Copyright 1993 E. I. du Pont de Nemours & Company                          %
%                                                                             %
%  Permission to use, copy, modify, distribute, and sell this software and    %
%  its documentation for any purpose is hereby granted without fee,           %
%  provided that the above Copyright notice appear in all copies and that     %
%  both that Copyright notice and this permission notice appear in            %
%  supporting documentation, and that the name of E. I. du Pont de Nemours    %
%  & Company not be used in advertising or publicity pertaining to            %
%  distribution of the software without specific, written prior               %
%  permission.  E. I. du Pont de Nemours & Company makes no representations   %
%  about the suitability of this software for any purpose.  It is provided    %
%  "as is" without express or implied warranty.                               %
%                                                                             %
%  E. I. du Pont de Nemours & Company disclaims all warranties with regard    %
%  to this software, including all implied warranties of merchantability      %
%  and fitness, in no event shall E. I. du Pont de Nemours & Company be       %
%  liable for any special, indirect or consequential damages or any           %
%  damages whatsoever resulting from loss of use, data or profits, whether    %
%  in an action of contract, negligence or other tortious action, arising     %
%  out of or in connection with the use or performance of this software.      %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Functions in this library convert to and from `alien' image formats to the
%  MIFF image format.
%
%
*/

/*
  Include declarations.
*/
#include "display.h"
#include "image.h"
#include "compress.h"
#include "utility.h"
#include "X.h"
#include "XWDFile.h"

/*
  Forward declarations.
*/
static Image
  *ReadMIFFImage _Declare((ImageInfo *));

/*
  External declarations.
*/
extern char
  *client_name;

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d A L P H A I m a g e                                                %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadALPHAImage reads an image of raw alpha bytes and returns it.
%  It allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadALPHAImage routine is:
%
%      image=ReadALPHAImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadALPHAImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadALPHAImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    index,
    *p;

  unsigned char
    *alpha_pixels;

  unsigned int
    height,
    width;

  /*
    Allocate image structure.
  */
  image=AllocateImage("ALPHA");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create image.
  */
  image->alpha=True;
  width=512;
  height=512;
  if (image_info->geometry != (char *) NULL)
    (void) XParseGeometry(image_info->geometry,&x,&y,&width,&height);
  image->columns=width;
  image->rows=height;
  image->packets=image->columns*image->rows;
  alpha_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*sizeof(unsigned char));
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  if ((alpha_pixels == (unsigned char *) NULL) ||
      (image->pixels == (RunlengthPacket *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert raster image to runlength-encoded packets.
  */
  (void) ReadData((char *) alpha_pixels,1,(int) (image->columns*image->rows),
    image->file);
  p=alpha_pixels;
  q=image->pixels;
  for (i=0; i < (image->columns*image->rows); i++)
  {
    index=(*p++);
    q->red=0;
    q->green=0;
    q->blue=0;
    q->index=(unsigned short) index;
    q->length=0;
    q++;
  }
  (void) free((char *) alpha_pixels);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d A V S I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadAVSImage reads a AVS X image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadAVSImage routine is:
%
%      image=ReadAVSImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadAVSImage returns a pointer to the image after
%      reading. A null image is returned if there is a a memory shortage or if
%      the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadAVSImage(image_info)
ImageInfo
  *image_info;
{
  typedef struct _AVSHeader
  {
    int
      width,
      height;
  } AVSHeader;

  AVSHeader
    avs_header;

  Image
    *image;

  register int
    i;

  register unsigned char
    *p;

  register RunlengthPacket
    *q;

  unsigned char
    *avs_pixels;

  unsigned int
    status;

  /*
    Allocate image structure.
  */
  image=AllocateImage("AVS");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read AVS image.
  */
  status=ReadData((char *) &avs_header,1,sizeof(AVSHeader),image->file);
  if (status == False)
    {
      Warning("not a AVS image file",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  do
  {
    avs_pixels=(unsigned char *)
      malloc(4*avs_header.width*avs_header.height*sizeof(unsigned char));
    if (avs_pixels == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) ReadData((char *) avs_pixels,1,avs_header.width*avs_header.height*4,
      image->file);
    /*
      Create image.
    */
    image->alpha=True;
    image->columns=avs_header.width;
    image->rows=avs_header.height;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) sprintf(image->comments,"\n  Imported from AVS raster image:  %s\n",
      image->filename);
    /*
      Convert AVS raster image to runlength-encoded packets.
    */
    p=avs_pixels;
    q=image->pixels;
    for (i=0; i < (image->columns*image->rows); i++)
    {
      q->index=(unsigned char) (*p++);
      q->red=(*p++);
      q->green=(*p++);
      q->blue=(*p++);
      q->length=0;
      q++;
    }
    (void) free((char *) avs_pixels);
    status=ReadData((char *) &avs_header,1,sizeof(AVSHeader),image->file);
    if (status == True)
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("AVS");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (status == True);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d B M P I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadBMPImage reads a Microsoft Windows bitmap image file and
%  returns it.  It allocates the memory necessary for the new Image structure
%  and returns a pointer to the new image.
%
%  The format of the ReadBMPImage routine is:
%
%      image=ReadBMPImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadBMPImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadBMPImage(image_info)
ImageInfo
  *image_info;
{
  typedef struct _BMPHeader
  {
    unsigned long
      file_size;

    unsigned short
      reserved[2];

    unsigned long
      offset_bits,
      size,
      width,
      height;

    unsigned short
      planes,
      bit_count;

    unsigned long
      compression,
      image_size,
      x_pixels,
      y_pixels,
      number_colors,
      colors_important;
  } BMPHeader;

  BMPHeader
    bmp_header;

  Image
    *image;

  register int
    bit,
    i,
    x,
    y;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *bmp_data,
    *bmp_pixels,
    magick[12];

  unsigned int
    bytes_per_line,
    status;

  /*
    Allocate image structure.
  */
  image=AllocateImage("BMP");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Determine if this is a BMP file.
  */
  status=ReadData((char *) magick,1,2,image->file);
  do
  {
    /*
      Verify BMP identifier.
    */
    if ((status == False) || (strncmp((char *) magick,"BM",2) != 0))
      {
        Warning("not a BMP image file",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    bmp_header.file_size=LSBFirstReadLong(image->file);
    bmp_header.reserved[0]=LSBFirstReadShort(image->file);
    bmp_header.reserved[1]=LSBFirstReadShort(image->file);
    bmp_header.offset_bits=LSBFirstReadLong(image->file);
    bmp_header.size=LSBFirstReadLong(image->file);
    bmp_header.width=LSBFirstReadLong(image->file);
    bmp_header.height=LSBFirstReadLong(image->file);
    bmp_header.planes=LSBFirstReadShort(image->file);
    bmp_header.bit_count=LSBFirstReadShort(image->file);
    bmp_header.compression=LSBFirstReadLong(image->file);
    bmp_header.image_size=LSBFirstReadLong(image->file);
    bmp_header.x_pixels=LSBFirstReadLong(image->file);
    bmp_header.y_pixels=LSBFirstReadLong(image->file);
    bmp_header.number_colors=LSBFirstReadLong(image->file);
    bmp_header.colors_important=LSBFirstReadLong(image->file);
    for (i=0; i < ((int) bmp_header.size-40); i++)
      (void) fgetc(image->file);
    if (bmp_header.bit_count < 24)
      {
        unsigned char
          *bmp_colormap;

        /*
          Read BMP raster colormap.
        */
        image->class=PseudoClass;
        image->colors=bmp_header.number_colors;
        if (image->colors == 0)
          image->colors=1 << bmp_header.bit_count;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        bmp_colormap=(unsigned char *)
          malloc(4*image->colors*sizeof(unsigned char));
        if ((image->colormap == (ColorPacket *) NULL) ||
            (bmp_colormap == (unsigned char *) NULL))
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) ReadData((char *) bmp_colormap,4,(int) image->colors,
          image->file);
        p=bmp_colormap;
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].blue=(*p++);
          image->colormap[i].green=(*p++);
          image->colormap[i].red=(*p++);
          p++;
        }
        (void) free((char *) bmp_colormap);
      }
    /*
      Read image data.
    */
    if (bmp_header.image_size == 0)
      bmp_header.image_size=
        ((bmp_header.width*bmp_header.bit_count+31)/32)*4*bmp_header.height;
    bmp_data=(unsigned char *)
      malloc(bmp_header.image_size*sizeof(unsigned char));
    if (bmp_data == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    status=ReadData((char *) bmp_data,1,(int) bmp_header.image_size,
      image->file);
    if (status == False)
      {
        Warning("unable to read image data",image_info->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    bmp_pixels=bmp_data;
    if (bmp_header.compression != 0)
      {
        /*
          Convert run-length encoded raster pixels.
        */
        bmp_pixels=(unsigned char *)
          malloc(bmp_header.image_size*sizeof(unsigned char));
        if (bmp_pixels == (unsigned char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) BMPDecodeImage(bmp_data,bmp_pixels,
          (unsigned int) bmp_header.width,(unsigned int) bmp_header.height);
        (void) free((char *) bmp_data);
      }
    /*
      Create image.
    */
    image->columns=bmp_header.width;
    image->rows=bmp_header.height;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    (void) sprintf(image->comments,
      "\n  Imported from BMP raster image:  %s\n",image->filename);
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Convert BMP raster image to runlength-encoded packets.
    */
    bytes_per_line=((image->columns*bmp_header.bit_count+31)/32)*4;
    switch (bmp_header.bit_count)
    {
      case 1:
      {
        /*
          Convert bitmap scanline to runlength-encoded color packets.
        */
        for (y=image->rows-1; y >= 0; y--)
        {
          p=bmp_pixels+(image->rows-y-1)*bytes_per_line;
          q=image->pixels+(y*image->columns);
          for (x=0; x < (image->columns-7); x+=8)
          {
            for (bit=0; bit < 8; bit++)
            {
              q->index=((*p) & (0x80 >> bit) ? 0x00 : 0x01);
              q->length=0;
              q++;
            }
            p++;
          }
          if ((image->columns % 8) != 0)
            {
              for (bit=0; bit < (8-(image->columns % 8)); bit++)
              {
                q->index=((*p) & (0x80 >> bit) ? 0x00 : 0x01);
                q->length=0;
                q++;
              }
              p++;
            }
        }
        SyncImage(image);
        break;
      }
      case 4:
      {
        /*
          Convert PseudoColor scanline to runlength-encoded color packets.
        */
        for (y=image->rows-1; y >= 0; y--)
        {
          p=bmp_pixels+(image->rows-y-1)*bytes_per_line;
          q=image->pixels+(y*image->columns);
          for (x=0; x < (image->columns-1); x+=2)
          {
            q->index=(*p >> 4) & 0xf;
            q->length=0;
            q++;
            q->index=(*p) & 0xf;
            q->length=0;
            p++;
            q++;
          }
          if ((image->columns % 2) != 0)
            {
              q->index=(*p >> 4) & 0xf;
              q->length=0;
              q++;
              p++;
            }
        }
        SyncImage(image);
        CompressColormap(image);
        break;
      }
      case 8:
      {
        /*
          Convert PseudoColor scanline to runlength-encoded color packets.
        */
        for (y=image->rows-1; y >= 0; y--)
        {
          p=bmp_pixels+(image->rows-y-1)*bytes_per_line;
          q=image->pixels+(y*image->columns);
          for (x=0; x < image->columns; x++)
          {
            q->index=(*p++);
            q->length=0;
            q++;
          }
        }
        SyncImage(image);
        CompressColormap(image);
        break;
      }
      case 24:
      {
        /*
          Convert DirectColor scanline to runlength-encoded color packets.
        */
        for (y=image->rows-1; y >= 0; y--)
        {
          p=bmp_pixels+(image->rows-y-1)*bytes_per_line;
          q=image->pixels+(y*image->columns);
          for (x=0; x < image->columns; x++)
          {
            q->index=(unsigned short) (image->alpha ? (*p++) : 0);
            q->blue=(*p++);
            q->green=(*p++);
            q->red=(*p++);
            q->length=0;
            q++;
          }
        }
        break;
      }
      default:
      {
        Warning("not a BMP image file",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    }
    (void) free((char *) bmp_pixels);
    /*
      Proceed to next image.
    */
    status=ReadData((char *) magick,1,2,image->file);
    if ((status == True) && (strncmp((char *) magick,"BM",2) == 0))
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("BMP");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while ((status == True) && (strncmp((char *) magick,"BM",2) == 0));
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d C M Y K I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadCMYKImage reads an image of raw cyan, magenta, yellow, and
%  black bytes and returns it.  It allocates the memory necessary for the new
%  Image structure and returns a pointer to the new image.
%
%  The format of the ReadCMYKImage routine is:
%
%      image=ReadCMYKImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadCMYKImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadCMYKImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    black,
    *cmyk_pixels,
    cyan,
    magenta,
    yellow;

  unsigned int
    height,
    width;

  /*
    Allocate image structure.
  */
  image=AllocateImage("CMYK");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create image.
  */
  width=512;
  height=512;
  if (image_info->geometry != (char *) NULL)
    (void) XParseGeometry(image_info->geometry,&x,&y,&width,&height);
  image->columns=width;
  image->rows=height;
  image->packets=image->columns*image->rows;
  cmyk_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*4*sizeof(unsigned char));
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  if ((cmyk_pixels == (unsigned char *) NULL) ||
      (image->pixels == (RunlengthPacket *) NULL))
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert raster image to runlength-encoded packets.
  */
  (void) ReadData((char *) cmyk_pixels,4,(int) (image->columns*image->rows),
    image->file);
  p=cmyk_pixels;
  switch (image_info->interlace)
  {
    case NoneInterlace:
    default:
    {
      /*
        No interlacing:  CMYKCMYKCMYKCMYKCMYKCMYK...
      */
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->red=(*p++);
        q->green=(*p++);
        q->blue=(*p++);
        q->index=(*p++);
        q->length=0;
        q++;
      }
      break;
    }
    case LineInterlace:
    {
      /*
        Line interlacing:  CCC...MMM...YYY...KKK...CCC...MMM...YYY...KKK...
      */
      for (y=0; y < image->rows; y++)
      {
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->red=(*p++);
          q->length=0;
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->green=(*p++);
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->blue=(*p++);
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->index=(*p++);
          q++;
        }
      }
      break;
    }
    case PlaneInterlace:
    {
      /*
        Plane interlacing:  CCCCCC...MMMMMM...YYYYYY...KKKKKK...
      */
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->red=(*p++);
        q->length=0;
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->green=(*p++);
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->blue=(*p++);
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->index=(*p++);
        q++;
      }
      break;
    }
  }
  /*
    Transform image to CMYK.
  */
  q=image->pixels;
  for (i=0; i < (image->columns*image->rows); i++)
  {
    cyan=q->red;
    magenta=q->green;
    yellow=q->blue;
    black=q->index;
    if ((unsigned int) (cyan+black) > MaxRGB)
      q->red=0;
    else
      q->red=MaxRGB-(cyan+black);
    if ((unsigned int) (magenta+black) > MaxRGB)
      q->green=0;
    else
      q->green=MaxRGB-(magenta+black);
    if ((unsigned int) (yellow+black) > MaxRGB)
      q->blue=0;
    else
      q->blue=MaxRGB-(yellow+black);
    q->index=0;
    q->length=0;
    q++;
  }
  (void) free((char *) cmyk_pixels);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d F A X I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadFAXImage reads a Group 3 FAX image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadFAXImage routine is:
%
%      image=ReadFAXImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadFAXImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadFAXImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  Warning("Cannot read FAX images",image_info->filename);
  image=ReadMIFFImage(image_info);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%   R e a d F I T S I m a g e                                                 %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadFITSImage reads a FITS image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadFITSImage routine is:
%
%      image=ReadFITSImage(image_info)
%
%  A description of each parameter follows:
%
%    o image: Function ReadFITSImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or if
%      the image cannot be read.
%
%    o filename: Specifies the name of the image to read.
%
%
*/
static Image *ReadFITSImage(image_info)
ImageInfo
  *image_info;
{
#define MaxKeywordLength  2048

  typedef struct _FITSHeader
  {
    unsigned int
      simple;

    int
      bits_per_pixel;

    unsigned int
      number_of_axis,
      columns,
      rows,
      depth;

    double
      min_data,
      max_data,
      zero,
      scale;
  } FITSHeader;

  char
    keyword[MaxKeywordLength],
    value[MaxKeywordLength];

  double
    scaled_pixel;

  FITSHeader
    fits_header;

  Image
    *image;

  long
    count,
    pixel;

  register int
    c,
    i,
    j;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *fits_pixels;

  unsigned int
    packet_size,
    status,
    value_expected;

  /*
    Allocate image structure.
  */
  image=AllocateImage("FITS");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Initialize image header.
  */
  fits_header.simple=False;
  fits_header.bits_per_pixel=8;
  fits_header.columns=1;
  fits_header.rows=1;
  fits_header.depth=1;
  fits_header.min_data=0.0;
  fits_header.max_data=0.0;
  fits_header.zero=0.0;
  fits_header.scale=1.0;
  /*
    Decode image header.
  */
  c=fgetc(image->file);
  count=1;
  if (c == EOF)
    {
      DestroyImage(image);
      return((Image *) NULL);
    }
  while (count < 2880)
  {
    if (!isalnum(c))
      {
        c=fgetc(image->file);
        count++;
      }
    else
      {
        register char
          *p;

        /*
          Determine a keyword and its value.
        */
        p=keyword;
        do
        {
          if ((p-keyword) < (MaxKeywordLength-1))
            *p++=(char) c;
          c=fgetc(image->file);
          count++;
        } while (isalnum(c) || (c == '_'));
        *p='\0';
        if (strcmp(keyword,"END") == 0)
          break;
        value_expected=False;
        while (isspace(c) || (c == '='))
        {
          if (c == '=')
            value_expected=True;
          c=fgetc(image->file);
          count++;
        }
        if (value_expected == False)
          continue;
        p=value;
        while (isalnum(c) || (c == '-') || (c == '+') || (c == '.'))
        {
          if ((p-value) < (MaxKeywordLength-1))
            *p++=(char) c;
          c=fgetc(image->file);
          count++;
        }
        *p='\0';
        /*
          Assign a value to the specified keyword.
        */
        if (strcmp(keyword,"SIMPLE") == 0)
          fits_header.simple=(*value == 'T') || (*value == 't');
        if (strcmp(keyword,"BITPIX") == 0)
          fits_header.bits_per_pixel=(unsigned int) atoi(value);
        if (strcmp(keyword,"NAXIS") == 0)
          fits_header.number_of_axis=(unsigned int) atoi(value);
        if (strcmp(keyword,"NAXIS1") == 0)
          fits_header.columns=(unsigned int) atoi(value);
        if (strcmp(keyword,"NAXIS2") == 0)
          fits_header.rows=(unsigned int) atoi(value);
        if (strcmp(keyword,"NAXIS3") == 0)
          fits_header.depth=(unsigned int) atoi(value);
        if (strcmp(keyword,"DATAMAX") == 0)
          fits_header.max_data=atof(value);
        if (strcmp(keyword,"DATAMIN") == 0)
          fits_header.min_data=atof(value);
        if (strcmp(keyword,"BZERO") == 0)
          fits_header.zero=atof(value);
        if (strcmp(keyword,"BSCALE") == 0)
          fits_header.scale=atof(value);
      }
    while (isspace(c) && (count < 2880))
    {
      c=fgetc(image->file);
      count++;
    }
  }
  for ( ; count < 2880; count++)
    fgetc(image->file);
  /*
    Verify that required image information is defined.
  */
  if ((!fits_header.simple) || (fits_header.bits_per_pixel < 0) ||
      (fits_header.number_of_axis < 1) || (fits_header.number_of_axis > 3) ||
      (fits_header.columns*fits_header.rows) == 0)
    {
      Warning("unable to read FITS image","image type not supported");
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create linear colormap.
  */
  image->columns=fits_header.columns;
  image->rows=fits_header.rows;
  image->class=PseudoClass;
  image->colors=MaxRGB+1;
  image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
  if (image->colormap == (ColorPacket *) NULL)
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  for (i=0; i < image->colors; i++)
  {
    image->colormap[i].red=(unsigned char) i;
    image->colormap[i].green=(unsigned char) i;
    image->colormap[i].blue=(unsigned char) i;
  }
  /*
    Create image.
  */
  image->packets=image->columns*image->rows;
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  image->comments=(char *)
    malloc((strlen(image->filename)+2048)*sizeof(char));
  packet_size=fits_header.bits_per_pixel/8;
  fits_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*packet_size*sizeof(unsigned char));
  if ((image->pixels == (RunlengthPacket *) NULL) ||
      (image->comments == (char *) NULL) ||
      (fits_pixels == (unsigned char *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  (void) sprintf(image->comments,"\n  Imported from FITS image:  %s\n",
    image->filename);
  /*
    Convert FITS pixels to runlength-encoded packets.
  */
  status=ReadData((char *) fits_pixels,packet_size,(int) image->packets,
    image->file);
  if (status == False)
    Warning("insufficient image data in file",image->filename);
  if ((fits_header.min_data == 0.0) && (fits_header.max_data == 0.0))
    {
      /*
        Determine minimum and maximum intensity.
      */
      p=fits_pixels;
      pixel=(*p++);
      for (j=0; j < (packet_size-1); j++)
        pixel=(pixel << 8) | (*p++);
      fits_header.min_data=pixel*fits_header.scale+fits_header.zero;
      fits_header.max_data=pixel*fits_header.scale+fits_header.zero;
      for (i=1; i < image->packets; i++)
      {
        pixel=(*p++);
        for (j=0; j < (packet_size-1); j++)
          pixel=(pixel << 8) | (*p++);
        scaled_pixel=pixel*fits_header.scale+fits_header.zero;
        if (scaled_pixel < fits_header.min_data)
          fits_header.min_data=scaled_pixel;
        if (scaled_pixel > fits_header.max_data)
          fits_header.max_data=scaled_pixel;
      }
    }
  /*
    Convert FITS pixels to runlength-encoded packets.
  */
  p=fits_pixels;
  q=image->pixels;
  for (i=0; i < image->packets; i++)
  {
    pixel=(*p++);
    for (j=0; j < (packet_size-1); j++)
      pixel=(pixel << 8) | (*p++);
    scaled_pixel=MaxRGB*(pixel*fits_header.scale+fits_header.zero+
      fits_header.min_data)/(fits_header.max_data-fits_header.min_data);
    q->index=(unsigned short) scaled_pixel;
    q->length=0;
    q++;
  }
  (void) free((char *) fits_pixels);
  SyncImage(image);
  CompressColormap(image);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d G I F I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadGIFImage reads a Compuserve Graphics image file and returns it.
%  It allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadGIFImage routine is:
%
%      image=ReadGIFImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadGIFImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      an error occurs.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadGIFImage(image_info)
ImageInfo
  *image_info;
{
#define BitSet(byte,bit)  (((byte) & (bit)) == (bit))
#define LSBFirstOrder(x,y)  (((y) << 8) | (x))

  Image
    *image;

  int
    pass,
    status,
    x,
    y;

  register int
    i;

  register unsigned char
    *p;

  unsigned char
    c,
    *global_colormap,
    header[2048],
    magick[12];

  unsigned int
    global_colors,
    image_count,
    interlace,
    local_colormap;

  /*
    Allocate image structure.
  */
  image=AllocateImage("GIF");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Determine if this is a GIF file.
  */
  status=ReadData((char *) magick,1,6,image->file);
  if ((status == False) || ((strncmp((char *) magick,"GIF87",5) != 0) &&
      (strncmp((char *) magick,"GIF89",5) != 0)))
    {
      Warning("not a GIF image file",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read the screen descriptor.
  */
  status=ReadData((char *) header,1,7,image->file);
  if (status == False)
    {
      Warning("failed to read screen descriptor",(char *) NULL );
      DestroyImage(image);
      return((Image *) NULL);
    }
  global_colors=0;
  global_colormap=(unsigned char *) NULL;
  if (BitSet(header[4],0x80))
    {
      /*
        Read global colormap.
      */
      global_colors=1 << ((header[4] & 0x07)+1);
      global_colormap=(unsigned char *)
        malloc(3*global_colors*sizeof(unsigned char));
      if (global_colormap == (unsigned char *) NULL)
        {
          Warning("unable to read image colormap","memory allocation failed");
          DestroyImage(image);
          return((Image *) NULL);
        }
      (void) ReadData((char *) global_colormap,1,(int) (3*global_colors),
        image->file);
    }
  image_count=0;
  for ( ; ; )
  {
    status=ReadData((char *) &c,1,1,image->file);
    if (status == False)
      break;
    if (c == ';')
      break;  /* terminator */
    if (c == '!')
      {
        /*
          GIF Extension block.
        */
        status=ReadData((char *) &c,1,1,image->file);
        if (status == False)
          {
            Warning("unable to read extention block",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        if (c != 0xfe)
          while (ReadDataBlock((char *) header,image->file) != 0);
        else
          while (ReadDataBlock((char *) header,image->file) != 0)
          {
            /*
              Comment extension block.
            */
            if (image->comments != (char *) NULL)
              image->comments=(char *) realloc((char *) image->comments,
                (unsigned int) (strlen(image->comments)+
                strlen((char *) header)+1));
            else
              {
                image->comments=(char *)
                  malloc((strlen((char *) header)+1)*sizeof(char));
                *image->comments='\0';
              }
            if (image->comments == (char *) NULL)
              {
                Warning("memory allocation error",(char *) NULL);
                DestroyImages(image);
                return((Image *) NULL);
              }
            (void) strcat(image->comments,(char *) header);
          }
      }
    if (c != ',')
      continue;
    /*
      Read image attributes.
    */
    if (image_count != 0)
      {
        /*
          Allocate image structure.
        */
        CompressColormap(image);
        image->next=AllocateImage("GIF");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
    image_count++;
    status=ReadData((char *) header,1,9,image->file);
    if (status == False)
      {
        Warning("unable to read left/top/width/height",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    interlace=BitSet(header[8],0x40);
    local_colormap=BitSet(header[8],0x80);
    /*
      Allocate image.
    */
    image->columns=LSBFirstOrder(header[4],header[5]);
    image->rows=LSBFirstOrder(header[6],header[7]);
    image->packets=image->columns*image->rows;
    if (image->pixels != (RunlengthPacket *) NULL)
      (void) free((char *) image->pixels);
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    if (image->pixels == (RunlengthPacket *) NULL)
      {
        Warning("unable to read image","memory allocation failed");
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Inititialize colormap.
    */
    image->class=PseudoClass;
    image->colors=!local_colormap ? global_colors : 1 << ((header[8] & 0x07)+1);
    image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
    if (image->colormap == (ColorPacket *) NULL)
      {
        Warning("unable to read image","memory allocation failed");
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (!local_colormap)
      {
        /*
          Use global colormap.
        */
        p=global_colormap;
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=(*p++);
          image->colormap[i].green=(*p++);
          image->colormap[i].blue=(*p++);
        }
      }
    else
      {
        unsigned char
          *colormap;

        /*
          Read local colormap.
        */
        colormap=(unsigned char *)
          malloc(3*image->colors*sizeof(unsigned char));
        if (colormap == (unsigned char *) NULL)
          {
            Warning("unable to read local colormap","memory allocation failed");
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) ReadData((char *) colormap,1,(int) image->colors*3,image->file);
        p=colormap;
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=(*p++);
          image->colormap[i].green=(*p++);
          image->colormap[i].blue=(*p++);
        }
        (void) free((char *) colormap);
      }
    /*
      Decode image.
    */
    status=LZWDecodeImage(image);
    if (status == False)
      {
        Warning("unable to read image data",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (interlace)
      {
        Image
          *interlaced_image;

        register RunlengthPacket
          *p,
          *q;

        static int
          interlace_rate[4] = { 8, 8, 4, 2 },
          interlace_start[4] = { 0, 4, 2, 1 };

        /*
          Interlace image.
        */
        interlaced_image=image;
        image=CopyImage(interlaced_image,interlaced_image->columns,
          interlaced_image->rows,False);
        if (image == (Image *) NULL)
          {
            Warning("unable to read image","memory allocation failed");
            DestroyImages(interlaced_image);
            return((Image *) NULL);
          }
        p=interlaced_image->pixels;
        q=image->pixels;
        for (pass=0; pass < 4; pass++)
        {
          y=interlace_start[pass];
          while (y < image->rows)
          {
            q=image->pixels+(y*image->columns);
            for (x=0; x < image->columns; x++)
            {
              *q=(*p);
              p++;
              q++;
            }
            y+=interlace_rate[pass];
          }
        }
        DestroyImages(interlaced_image);
      }
  }
  (void) free((char *) global_colormap);
  CompressColormap(image);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d G R A Y I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadGRAYImage reads an image of raw grayscale bytes and returns it.
%  It allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadGRAYImage routine is:
%
%      image=ReadGRAYImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadGRAYImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadGRAYImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    index,
    *p;

  unsigned char
    *gray_pixels;

  unsigned int
    height,
    width;

  /*
    Allocate image structure.
  */
  image=AllocateImage("GRAY");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create linear colormap.
  */
  image->class=PseudoClass;
  image->colors=256;
  image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
  if (image->colormap == (ColorPacket *) NULL)
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  for (i=0; i < image->colors; i++)
  {
    image->colormap[i].red=(unsigned char) i;
    image->colormap[i].green=(unsigned char) i;
    image->colormap[i].blue=(unsigned char) i;
  }
  /*
    Create image.
  */
  width=512;
  height=512;
  if (image_info->geometry != (char *) NULL)
    (void) XParseGeometry(image_info->geometry,&x,&y,&width,&height);
  image->columns=width;
  image->rows=height;
  image->packets=image->columns*image->rows;
  gray_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*sizeof(unsigned char));
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  if ((gray_pixels == (unsigned char *) NULL) ||
      (image->pixels == (RunlengthPacket *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert raster image to runlength-encoded packets.
  */
  (void) ReadData((char *) gray_pixels,1,(int) (image->columns*image->rows),
    image->file);
  p=gray_pixels;
  q=image->pixels;
  for (i=0; i < (image->columns*image->rows); i++)
  {
    index=(*p++);
    q->red=index;
    q->green=index;
    q->blue=index;
    q->index=(unsigned short) index;
    q->length=0;
    q++;
  }
  (void) free((char *) gray_pixels);
  CompressColormap(image);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d H I S T O G R A M I m a g e                                        %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadHISTOGRAMImage reads a HISTOGRAM image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadHISTOGRAMImage routine is:
%
%      image=ReadHISTOGRAMImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadHISTOGRAMImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadHISTOGRAMImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  Warning("Cannot read HISTOGRAM images",image_info->filename);
  image=ReadMIFFImage(image_info);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d I R I S I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadIRISImage reads a SGI RGB image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadIRISImage routine is:
%
%      image=ReadIRISImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadIRISImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/

static void IRISDecode(packets,pixels)
unsigned char
  *packets,
  *pixels;
{
  unsigned char
    count,
    pixel;

  for ( ; ;)
  {
    pixel=(*packets++);
    count=pixel & 0x7f;
    if (count == 0)
      break;
    if (pixel & 0x80)
      for ( ; count != 0; count--)
      {
        *pixels=(*packets++);
        pixels+=4;
      }
    else
      {
        pixel=(*packets++);
        for ( ; count != 0; count--)
        {
          *pixels=pixel;
          pixels+=4;
        }
      }
  }
}

static Image *ReadIRISImage(image_info)
ImageInfo
  *image_info;
{
  typedef struct _IRISHeader
  {
    unsigned short
      magic,
      type,
      dimension,
      columns,
      rows,
      depth;

    unsigned long
      minimum_value,
      maximum_value;

    unsigned char
      filler[492];
  } IRISHeader;

  Image
    *image;

  IRISHeader
    iris_header;

  register int
    i,
    x,
    y,
    z;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *iris_pixels;

  /*
    Allocate image structure.
  */
  image=AllocateImage("IRIS");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read IRIS raster header.
  */
  iris_header.magic=MSBFirstReadShort(image->file);
  do
  {
    /*
      Verify IRIS identifier.
    */
    if (iris_header.magic != 0x01DA)
      {
        Warning("not a IRIS RGB image,",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    iris_header.type=MSBFirstReadShort(image->file);
    if (((iris_header.type) & 0x00ff) != 1)
      {
        Warning("image must have 1 byte per pixel channel,",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    iris_header.dimension=MSBFirstReadShort(image->file);
    iris_header.columns=MSBFirstReadShort(image->file);
    iris_header.rows=MSBFirstReadShort(image->file);
    iris_header.depth=MSBFirstReadShort(image->file);
    iris_header.minimum_value=MSBFirstReadLong(image->file);
    iris_header.maximum_value=MSBFirstReadLong(image->file);
    (void) ReadData((char *) iris_header.filler,1,sizeof(iris_header.filler),
      image->file);
    /*
      Allocate IRIS pixels.
    */
    iris_pixels=(unsigned char *)
      malloc(4*iris_header.columns*iris_header.rows*sizeof(unsigned char));
    if (iris_pixels == (unsigned char *) NULL)
      {
        Warning("memory allocation error",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (((iris_header.type) & 0xff00) != 0x0100)
      {
        unsigned char
          *scanline;

        /*
          Read standard image format.
        */
        scanline=(unsigned char *)
          malloc(iris_header.columns*sizeof(unsigned char));
        if (scanline == (unsigned char *) NULL)
          {
            Warning("memory allocation error",image->filename);
            DestroyImages(image);
            return((Image *) NULL);
          }
        for (z=0; z < (int) iris_header.depth; z++)
        {
          p=iris_pixels+z;
          for (y=0; y < (int) iris_header.rows; y++)
          {
            (void) ReadData((char *) scanline,1,(int) iris_header.columns,
              image->file);
            for (x=0; x < (int) iris_header.columns; x++)
            {
              *p=scanline[x];
              p+=4;
            }
          }
        }
        (void) free(scanline);
      }
    else
      {
        unsigned char
          *packets;

        unsigned int
          data_order;

        unsigned long
          offset,
          *offsets,
          *runlength;

        /*
          Read runlength-encoded image format.
        */
        offsets=(unsigned long *)
          malloc(iris_header.rows*iris_header.depth*sizeof(unsigned long));
        packets=(unsigned char *)
          malloc((2*iris_header.columns+10)*sizeof(unsigned char));
        runlength=(unsigned long *)
          malloc(iris_header.rows*iris_header.depth*sizeof(unsigned long));
        if ((offsets == (unsigned long *) NULL) ||
            (packets == (unsigned char *) NULL) ||
            (runlength == (unsigned long *) NULL))
          {
            Warning("memory allocation error",image->filename);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) ReadData((char *) offsets,sizeof(unsigned long),
          (int) (iris_header.rows*iris_header.depth),image->file);
        (void) ReadData((char *) runlength,sizeof(unsigned long),
          (int) (iris_header.rows*iris_header.depth),image->file);
        /*
          Check data order.
        */
        offset=0;
        data_order=0;
        for (y=0; ((y < (int) iris_header.rows) && !data_order); y++)
          for (z=0; ((z < (int) iris_header.depth) && !data_order); z++)
          {
            if (offsets[y+z*iris_header.rows] < offset)
              data_order=1;
            offset=offsets[y+z*iris_header.rows];
          }
        offset=512+
          2*(iris_header.rows*iris_header.depth)*sizeof(unsigned long);
        if (data_order == 1)
          {
            for (z=0; z < (int) iris_header.depth; z++)
            {
              p=iris_pixels;
              for (y=0; y < (int) iris_header.rows; y++)
              {
                if (offset != offsets[y+z*iris_header.rows])
                  {
                    offset=offsets[y+z*iris_header.rows];
                    (void) fseek(image->file,(int) offset,0);
                  }
                (void) ReadData((char *) packets,1,
                  (int) runlength[y+z*iris_header.rows],image->file);
                offset+=runlength[y+z*iris_header.rows];
                IRISDecode(packets,p+z);
                p+=(iris_header.columns*4);
              }
            }
          }
        else
          {
            p=iris_pixels;
            for (y=0; y < (int) iris_header.rows; y++)
            {
              for (z=0; z < (int) iris_header.depth; z++)
              {
                if (offset != offsets[y+z*iris_header.rows])
                  {
                    offset=offsets[y+z*iris_header.rows];
                    (void) fseek(image->file,(int) offset,0);
                  }
                (void) ReadData((char *) packets,1,
                  (int) runlength[y+z*iris_header.rows],image->file);
                offset+=runlength[y+z*iris_header.rows];
                IRISDecode(packets,p+z);
              }
              p+=(iris_header.columns*4);
            }
          }
        (void) free(runlength);
        (void) free(packets);
        (void) free(offsets);
      }
    /*
      Create image.
    */
    image->alpha=iris_header.depth == 4;
    image->columns=iris_header.columns;
    image->rows=iris_header.rows;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) sprintf(image->comments,"\n  Imported from IRIS raster image:  %s\n",
      image->filename);
    /*
      Convert IRIS raster image to runlength-encoded packets.
    */
    q=image->pixels;
    if (iris_header.depth >= 3)
      {
        /*
          Convert IRIS image to DirectClass runlength-encoded packets.
        */
        for (y=0; y < image->rows; y++)
        {
          p=iris_pixels+((image->rows-1)-y)*(image->columns*4);
          for (x=0; x < image->columns; x++)
          {
            q->red=(*p);
            q->green=(*(p+1));
            q->blue=(*(p+2));
            q->index=(*(p+3));
            q->length=0;
            p+=4;
            q++;
          }
        }
      }
    else
      {
        unsigned short
          index;

        /*
          Create grayscale map.
        */
        image->class=PseudoClass;
        image->colors=256;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        if (image->colormap == (ColorPacket *) NULL)
          {
            Warning("unable to read image","memory allocation failed");
            DestroyImage(image);
            return((Image *) NULL);
          }
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=(unsigned char) i;
          image->colormap[i].green=(unsigned char) i;
          image->colormap[i].blue=(unsigned char) i;
        }
        /*
          Convert IRIS image to PseudoClass runlength-encoded packets.
        */
        for (y=0; y < image->rows; y++)
        {
          p=iris_pixels+((image->rows-1)-y)*(image->columns*4);
          for (x=0; x < image->columns; x++)
          {
            index=(unsigned short) (*p);
            q->red=image->colormap[index].red;
            q->green=image->colormap[index].green;
            q->blue=image->colormap[index].blue;
            q->index=index;
            q->length=0;
            p+=4;
            q++;
          }
        }
      }
    (void) free((char *) iris_pixels);
    /*
      Proceed to next image.
    */
    iris_header.magic=MSBFirstReadShort(image->file);
    if (iris_header.magic == 0x01DA)
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("IRIS");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (iris_header.magic == 0x01DA);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

#ifdef HasJPEG
#undef FREAD
#undef FWRITE
#undef const
#include "jinclude.h"
static Image
  *jpeg_image;

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d J P E G I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadJPEGImage reads a JPEG image file and returns it.  It allocates
%  the memory necessary for the new Image structure and returns a pointer to
%  the new image.
%
%  The format of the ReadJPEGImage routine is:
%
%      image=ReadJPEGImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadJPEGImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o filename:  Specifies the name of the jpeg_image to read.
%
%
*/

static void MIFFInitializeImage(jpeg_info)
decompress_info_ptr
  jpeg_info;
{
  /*
    Create jpeg_image.
  */
  jpeg_image->columns=jpeg_info->image_width;
  jpeg_image->rows=jpeg_info->image_height;
  jpeg_image->packets=jpeg_image->columns*jpeg_image->rows;
  jpeg_image->pixels=(RunlengthPacket *)
    malloc(jpeg_image->packets*sizeof(RunlengthPacket));
  jpeg_image->comments=(char *)
    malloc((strlen(jpeg_image->filename)+2048)*sizeof(char));
  if ((jpeg_image->pixels == (RunlengthPacket *) NULL) ||
      (jpeg_image->comments == (char *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      exit(1);
    }
  (void) sprintf(jpeg_image->comments,
    "\n  Imported from JFIF JPEG image:  %s\n",jpeg_image->filename);
  jpeg_image->packet=jpeg_image->pixels;
}

static void MIFFOutputTermMethod(jpeg_info)
decompress_info_ptr
  jpeg_info;
{
}

static void MIFFWriteGRAY(jpeg_info,number_rows,pixel_data)
decompress_info_ptr
  jpeg_info;

int
  number_rows;

JSAMPIMAGE
  pixel_data;
{
  register int
    column,
    row;

  register JSAMPROW
    gray;

  register RunlengthPacket
    *q;

  /*
    Transfer grayscale JPEG pixel data to MIFF pixels.
  */
  q=jpeg_image->packet;
  for (row=0; row < number_rows; row++)
  {
    gray=pixel_data[0][row];
    for (column=jpeg_info->image_width; column > 0; column--)
    {
      q->red=GETJSAMPLE(*gray);
      q->green=GETJSAMPLE(*gray);
      q->blue=GETJSAMPLE(*gray);
      q->index=(unsigned short) GETJSAMPLE(*gray);
      q->length=0;
      q++;
      gray++;
    }
  }
  jpeg_image->packet=q;
}

static void MIFFWriteRGB(jpeg_info,number_rows,pixel_data)
decompress_info_ptr
  jpeg_info;

int
  number_rows;

JSAMPIMAGE
  pixel_data;
{
  register int
    column,
    row;

  register JSAMPROW
    blue,
    green,
    red;

  register RunlengthPacket
    *q;

  /*
    Transfer JPEG pixel data to MIFF pixels.
  */
  q=jpeg_image->packet;
  for (row=0; row < number_rows; row++)
  {
    red=pixel_data[0][row];
    green=pixel_data[1][row];
    blue=pixel_data[2][row];
    for (column=jpeg_info->image_width; column > 0; column--)
    {
      q->red=GETJSAMPLE(*red++);
      q->green=GETJSAMPLE(*green++);
      q->blue=GETJSAMPLE(*blue++);
      q->index=0;
      q->length=0;
      q++;
    }
  }
  jpeg_image->packet=q;
}

static void MIFFSelectMethod(jpeg_info)
decompress_info_ptr
  jpeg_info;
{
  jpeg_info->methods->put_pixel_rows=MIFFWriteRGB;
  jpeg_info->out_color_space=CS_RGB;
  if (jpeg_info->jpeg_color_space == CS_GRAYSCALE)
    {
      jpeg_info->out_color_space=CS_GRAYSCALE;
      jpeg_info->methods->put_pixel_rows=MIFFWriteGRAY;
    }
  jpeg_info->data_precision=8;
}

static Image *ReadJPEGImage(image_info)
ImageInfo
  *image_info;
{
  struct Decompress_info_struct
    jpeg_info;

  struct Decompress_methods_struct
    jpeg_methods;

  struct External_methods_struct
    external_methods;

  /*
    Allocate jpeg_image structure.
  */
  jpeg_image=AllocateImage("JPEG");
  if (jpeg_image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(jpeg_image->filename,image_info->filename);
  OpenImage(jpeg_image,"r");
  if (jpeg_image->file == (FILE *) NULL)
    {
      Warning("unable to open file",jpeg_image->filename);
      DestroyImage(jpeg_image);
      return((Image *) NULL);
    }
  /*
    Initialize the JPEG system-dependent methods.
  */
  jpeg_info.methods=(&jpeg_methods);
  jpeg_info.emethods=(&external_methods);
  jselerror(&external_methods);
  jselmemmgr(&external_methods);
  jpeg_info.methods->output_init=MIFFInitializeImage;
  jpeg_info.methods->output_term=MIFFOutputTermMethod;
  jpeg_methods.d_ui_method_selection=MIFFSelectMethod;
  j_d_defaults(&jpeg_info,True);
  /*
    Read a JFIF JPEG file.
  */
  jpeg_info.input_file=jpeg_image->file;
  jpeg_info.output_file=(FILE *) NULL;
  jselrjfif(&jpeg_info);
  jpeg_decompress(&jpeg_info);
  if (jpeg_info.jpeg_color_space == CS_GRAYSCALE)
    {
      register int
        i;

      /*
        Initialize grayscale colormap.
      */
      jpeg_image->class=PseudoClass;
      jpeg_image->colors=256;
      jpeg_image->colormap=(ColorPacket *)
        malloc(jpeg_image->colors*sizeof(ColorPacket));
      if (jpeg_image->colormap == (ColorPacket *) NULL)
        {
          Warning("unable to create image colormap","memory allocation failed");
          DestroyImage(jpeg_image);
          return((Image *) NULL);
        }
      for (i=0; i < jpeg_image->colors; i++)
      {
        jpeg_image->colormap[i].red=(unsigned short) i;
        jpeg_image->colormap[i].green=(unsigned short) i;
        jpeg_image->colormap[i].blue=(unsigned short) i;
      }
    }
  CloseImage(jpeg_image);
  return(jpeg_image);
}
#else
static Image *ReadJPEGImage(image_info)
ImageInfo
  *image_info;
{
  Warning("JPEG library is not available",image_info->filename);
  return(ReadMIFFImage(image_info));
}
#endif

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%   R e a d M I F F I m a g e                                                 %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadMIFFImage reads a MIFF image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadMIFFImage routine is:
%
%      image=ReadMIFFImage(filename)
%
%  A description of each parameter follows:
%
%    o image: Function ReadMIFFImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadMIFFImage(image_info)
ImageInfo
  *image_info;
{
#define MaxKeywordLength  2048

  char
    keyword[MaxKeywordLength],
    value[MaxKeywordLength];

  Image
    *image;

  register int
    c,
    i;

  register unsigned char
    *p;

  unsigned int
    max_characters,
    packet_size,
    status;

  unsigned long
    count,
    packets;

  /*
    Allocate image structure.
  */
  image=AllocateImage("MIFF");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Decode image header;  header terminates one character beyond a ':'.
  */
  c=fgetc(image->file);
  if (c == EOF)
    {
      DestroyImage(image);
      return((Image *) NULL);
    }
  do
  {
    /*
      Decode image header;  header terminates one character beyond a ':'.
    */
    image->compression=NoCompression;
    while (isgraph(c) && (c != ':'))
    {
      register char
        *p;

      if (c == '{')
        {
          /*
            Comment.
          */
          max_characters=2048;
          image->comments=(char *) malloc(max_characters*sizeof(char));
          if (image->comments == (char *) NULL)
            {
              Warning("unable to read image","memory allocation failed");
              DestroyImages(image);
              return((Image *) NULL);
            }
          p=image->comments;
          *p='\0';
          c=fgetc(image->file);
          while ((isgraph(c) || isspace(c)) && (c != '}'))
          {
            if (p >= (image->comments+max_characters-1))
              {
                /*
                  Allocate more memory for the comment.
                */
                max_characters<<=1;
                image->comments=(char *)
                  realloc((char *) image->comments,max_characters);
                if (image->comments == (char *) NULL)
                  {
                    Warning("unable to read image","memory allocation failed");
                    DestroyImages(image);
                    return((Image *) NULL);
                  }
                p=image->comments+strlen(image->comments);
              }
            *p++=(unsigned char) c;
            c=fgetc(image->file);
          }
          *p='\0';
          c=fgetc(image->file);
        }
      else
        if (isalnum(c))
          {
            /*
              Determine a keyword and its value.
            */
            p=keyword;
            do
            {
              if ((p-keyword) < (MaxKeywordLength-1))
                *p++=(char) c;
              c=fgetc(image->file);
            } while (isalnum(c));
            *p='\0';
            while (isspace(c) || (c == '='))
              c=fgetc(image->file);
            p=value;
            while (!isspace(c))
            {
              if ((p-value) < (MaxKeywordLength-1))
                *p++=(char) c;
              c=fgetc(image->file);
            }
            *p='\0';
            /*
              Assign a value to the specified keyword.
            */
            if (strcmp(keyword,"alpha") == 0)
              if ((strcmp(value,"True") == 0) || (strcmp(value,"true") == 0))
                image->alpha=True;
              else
                image->class=False;
            if (strcmp(keyword,"class") == 0)
              if (strcmp(value,"PseudoClass") == 0)
                image->class=PseudoClass;
              else
                if (strcmp(value,"DirectClass") == 0)
                  image->class=DirectClass;
                else
                  image->class=UndefinedClass;
            if (strcmp(keyword,"colors") == 0)
              image->colors=(unsigned int) atoi(value);
            if (strcmp(keyword,"compression") == 0)
              if (strcmp(value,"QEncoded") == 0)
                image->compression=QEncodedCompression;
              else
                if (strcmp(value,"RunlengthEncoded") == 0)
                  image->compression=RunlengthEncodedCompression;
                else
                  image->compression=UndefinedCompression;
            if (strcmp(keyword,"columns") == 0)
              image->columns=(unsigned int) atoi(value);
            if (strcmp(keyword,"id") == 0)
              if (strcmp(value,"ImageMagick") == 0)
                image->id=ImageMagickId;
              else
                image->id=UndefinedId;
            if (strcmp(keyword,"montage") == 0)
              {
                image->montage=(char *) malloc(strlen(value)+1*sizeof(char));
                if (image->montage == (char *) NULL)
                  {
                    Warning("unable to read image","memory allocation failed");
                    DestroyImages(image);
                    return((Image *) NULL);
                  }
                (void) strcpy(image->montage,value);
              }
            if (strcmp(keyword,"packets") == 0)
              image->packets=(unsigned int) atoi(value);
            if (strcmp(keyword,"rows") == 0)
              image->rows=(unsigned int) atoi(value);
            if (strcmp(keyword,"scene") == 0)
              image->scene=(unsigned int) atoi(value);
            if (strcmp(keyword,"signature") == 0)
              {
                image->signature=(char *)
                  malloc((strlen(value)+1)*sizeof(char));
                if (image->signature == (char *) NULL)
                  {
                    Warning("unable to read image","memory allocation failed");
                    DestroyImages(image);
                    return((Image *) NULL);
                  }
                (void) strcpy(image->signature,value);
              }
          }
        else
          c=fgetc(image->file);
      while (isspace(c))
        c=fgetc(image->file);
    }
    (void) fgetc(image->file);
    /*
      Verify that required image information is defined.
    */
    if ((image->id == UndefinedId) || (image->class == UndefinedClass) ||
        (image->compression == UndefinedCompression) || (image->columns == 0) ||
        (image->rows == 0))
      {
        Warning("incorrect image header in file",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if ((image->columns*image->rows) > MaxImageSize)
      {
        Warning("unable to read image","image size too large");
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (image->montage != (char *) NULL)
      {
        register char
          *p;

        /*
          Image directory.
        */
        max_characters=2048;
        image->directory=(char *) malloc(max_characters*sizeof(char));
        if (image->directory == (char *) NULL)
          {
            Warning("unable to read image","memory allocation failed");
            DestroyImages(image);
            return((Image *) NULL);
          }
        p=image->directory;
        do
        {
          if (p >= (image->directory+max_characters-1))
            {
              /*
                Allocate more memory for the image directory.
              */
              max_characters<<=1;
              image->directory=(char *)
                realloc((char *) image->directory,max_characters);
              if (image->directory == (char *) NULL)
                {
                  Warning("unable to read image","memory allocation failed");
                  DestroyImages(image);
                  return((Image *) NULL);
                }
              p=image->directory+strlen(image->directory);
            }
          c=fgetc(image->file);
          *p++=(unsigned char) c;
        } while (c != '\0');
      }
    if (image->class == PseudoClass)
      {
        unsigned int
          colors;

        /*
          PseudoClass image cannot have alpha data or be QEncoded.
        */
        if (image->alpha)
          {
            Warning("unable to read image","alpha images must be DirectClass");
            DestroyImages(image);
            return((Image *) NULL);
          }
        if (image->compression == QEncodedCompression)
          {
            Warning("unable to read image",
              "QEncoded images must be DirectClass");
            DestroyImages(image);
            return((Image *) NULL);
          }
        /*
          Create image colormap.
        */
        colors=image->colors;
        if (colors == 0)
          colors=256;
        image->colormap=(ColorPacket *) malloc(colors*sizeof(ColorPacket));
        if (image->colormap == (ColorPacket *) NULL)
          {
            Warning("unable to read image","memory allocation failed");
            DestroyImages(image);
            return((Image *) NULL);
          }
        if (image->colors == 0)
          for (i=0; i < colors; i++)
          {
            image->colormap[i].red=(unsigned char) i;
            image->colormap[i].green=(unsigned char) i;
            image->colormap[i].blue=(unsigned char) i;
            image->colors++;
          }
        else
          {
            unsigned char
              *colormap;

            /*
              Read image colormap from file.
            */
            colormap=(unsigned char *)
              malloc(3*image->colors*sizeof(unsigned char));
            if (colormap == (unsigned char *) NULL)
              {
                Warning("unable to read image","memory allocation failed");
                DestroyImages(image);
                return((Image *) NULL);
              }
            (void) ReadData((char *) colormap,1,(int) (3*image->colors),
              image->file);
            p=colormap;
            for (i=0; i < image->colors; i++)
            {
              image->colormap[i].red=(*p++);
              image->colormap[i].green=(*p++);
              image->colormap[i].blue=(*p++);
            }
            (void) free((char *) colormap);
          }
      }
    /*
      Determine packed packet size.
    */
    if (image->class == PseudoClass)
      {
        image->packet_size=1;
        if (image->colors > 256)
          image->packet_size++;
      }
    else
      {
        image->packet_size=3;
        if (image->alpha)
          image->packet_size++;
      }
    if (image->compression == RunlengthEncodedCompression)
      image->packet_size++;
    packet_size=image->packet_size;
    if (image->compression == QEncodedCompression)
      packet_size=1;
    /*
      Allocate image pixels.
    */
    if (image->compression == NoCompression)
      image->packets=image->columns*image->rows;
    packets=image->packets;
    if (image->packets == 0)
      packets=image->columns*image->rows;
    image->packed_pixels=(unsigned char *)
      malloc((unsigned int) packets*packet_size*sizeof(unsigned char));
    if (image->packed_pixels == (unsigned char *) NULL)
      {
        Warning("unable to read image","memory allocation failed");
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Read image pixels from file.
    */
    if ((image->compression != RunlengthEncodedCompression) ||
        (image->packets != 0))
      (void) ReadData((char *) image->packed_pixels,1,
        (int) (packets*packet_size),image->file);
    else
      {
        /*
          Number of runlength packets is unspecified.
        */
        count=0;
        p=image->packed_pixels;
        do
        {
          (void) ReadData((char *) p,1,(int) packet_size,image->file);
          image->packets++;
          p+=(packet_size-1);
          count+=(*p+1);
          p++;
        }
        while (count < (image->columns*image->rows));
      }
    if (image->compression ==  QEncodedCompression)
      {
        unsigned char
          *compressed_pixels;

        /*
          Uncompress image pixels with Q encoding.
        */
        image->packets=image->columns*image->rows;
        compressed_pixels=image->packed_pixels;
        image->packed_pixels=(unsigned char *) malloc((unsigned int)
          image->packets*image->packet_size*sizeof(unsigned char));
        if (image->packed_pixels == (unsigned char *) NULL)
          {
            Warning("unable to write image","memory allocation failed");
            DestroyImage(image);
            return(False);
          }
        packets=QDecodeImage(compressed_pixels,image->packed_pixels,
          image->columns*(int) image->packet_size,image->rows);
        if (packets != (image->packets*image->packet_size))
          {
            Warning("Q encoding failed",image->filename);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) free((char *) compressed_pixels);
      }
    /*
      Unpack the packed image pixels into runlength-encoded pixel packets.
    */
    status=RunlengthDecodeImage(image);
    if (status == False)
      {
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Proceed to next image.
    */
    do
    {
      c=fgetc(image->file);
    } while (!isgraph(c) && (c != EOF));
    if (c != EOF)
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("MIFF");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (c != EOF);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d M T V I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadMTVImage reads a MTV image file and returns it.  It allocates
%  the memory necessary for the new Image structure and returns a pointer to
%  the new image.
%
%  The format of the ReadMTVImage routine is:
%
%      image=ReadMTVImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadMTVImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadMTVImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    count;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *mtv_pixels;

  unsigned int
    columns,
    rows;

  /*
    Allocate image structure.
  */
  image=AllocateImage("MTV");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read MTV image.
  */
  count=fscanf(image->file,"%u %u\n",&columns,&rows);
  if (count == 0)
    {
      Warning("not a MTV image,",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  do
  {
    /*
      Allocate image pixels.
    */
    mtv_pixels=(unsigned char *) malloc(3*columns*rows*sizeof(unsigned char));
    if (mtv_pixels == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Read image pixels.
    */
    (void) ReadData((char *) mtv_pixels,1,(int) (columns*rows*3),image->file);
    /*
      Create image.
    */
    image->columns=columns;
    image->rows=rows;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) sprintf(image->comments,"\n  Imported from MTV raster image:  %s\n",
      image->filename);
    /*
      Convert MTV raster image to runlength-encoded packets.
    */
    p=mtv_pixels;
    q=image->pixels;
    for (i=0; i < (image->columns*image->rows); i++)
    {
      q->red=(*p++);
      q->green=(*p++);
      q->blue=(*p++);
      q->index=0;
      q->length=0;
      q++;
    }
    (void) free((char *) mtv_pixels);
    /*
      Proceed to next image.
    */
    count=fscanf(image->file,"%u %u\n",&columns,&rows);
    if (count > 0)
      {
        /*
          Allocate next image structure.
        */
        image->next=AllocateImage("MTV");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (count > 0);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d P C X I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadPCXImage reads a ZSoft IBM PC Paintbrush file and returns it.
%  It allocates the memory necessary for the new Image structure and returns
%  a pointer to the new image.
%
%  The format of the ReadPCXImage routine is:
%
%      image=ReadPCXImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadPCXImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadPCXImage(image_info)
ImageInfo
  *image_info;
{
  typedef struct _PCXHeader
  {
    unsigned char
      identifier,
      version,
      encoding,
      bits_per_pixel;

    short int
      left,
      top,
      right,
      bottom,
      horizonal_resolution,
      vertical_resolution;

    unsigned char
      reserved,
      planes;

    short int
      bytes_per_line,
      palette_info;

    unsigned char
      colormap_signature;
  } PCXHeader;

  PCXHeader
    pcx_header;

  Image
    *image;

  int
    count,
    packets;

  register int
    i,
    x,
    y;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    packet,
    *pcx_colormap,
    *pcx_pixels;

  unsigned int
    status;

  /*
    Allocate image structure.
  */
  image=AllocateImage("PCX");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Determine if this is a PCX file.
  */
  status=ReadData((char *) &pcx_header.identifier,1,1,image->file);
  do
  {
    /*
      Verify PCX identifier.
    */
    if ((status == False) || (pcx_header.identifier != 0x0a))
      {
        Warning("not a PCX image file",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) ReadData((char *) &pcx_header.version,1,1,image->file);
    (void) ReadData((char *) &pcx_header.encoding,1,1,image->file);
    (void) ReadData((char *) &pcx_header.bits_per_pixel,1,1,image->file);
    pcx_header.left=LSBFirstReadShort(image->file);
    pcx_header.top=LSBFirstReadShort(image->file);
    pcx_header.right=LSBFirstReadShort(image->file);
    pcx_header.bottom=LSBFirstReadShort(image->file);
    pcx_header.horizonal_resolution=LSBFirstReadShort(image->file);
    pcx_header.vertical_resolution=LSBFirstReadShort(image->file);
    /*
      Read PCX raster colormap.
    */
    image->columns=(pcx_header.right-pcx_header.left)+1;
    image->rows=(pcx_header.bottom-pcx_header.top)+1;
    image->class=PseudoClass;
    image->colors=16;
    image->colormap=(ColorPacket *) malloc(256*sizeof(ColorPacket));
    pcx_colormap=(unsigned char *) malloc(3*256*sizeof(unsigned char));
    if ((image->colormap == (ColorPacket *) NULL) ||
        (pcx_colormap == (unsigned char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) ReadData((char *) pcx_colormap,3,(int) image->colors,image->file);
    p=pcx_colormap;
    for (i=0; i < image->colors; i++)
    {
      image->colormap[i].red=(*p++);
      image->colormap[i].green=(*p++);
      image->colormap[i].blue=(*p++);
    }
    (void) ReadData((char *) &pcx_header.reserved,1,1,image->file);
    (void) ReadData((char *) &pcx_header.planes,1,1,image->file);
    pcx_header.bytes_per_line=LSBFirstReadShort(image->file);
    pcx_header.palette_info=LSBFirstReadShort(image->file);
    for (i=0; i < 58; i++)
      (void) fgetc(image->file);
    /*
      Read image data.
    */
    packets=image->rows*pcx_header.bytes_per_line*pcx_header.planes;
    pcx_pixels=(unsigned char *) malloc(packets*sizeof(unsigned char));
    if (pcx_pixels == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Uncompress image data.
    */
    p=pcx_pixels;
    while (packets > 0)
    {
      packet=fgetc(image->file);
      if ((packet & 0xc0) != 0xc0)
        {
          *p++=packet;
          packets--;
          continue;
        }
      count=packet & 0x3f;
      packet=fgetc(image->file);
      packets-=count;
      while (--count >= 0)
        *p++=packet;
    }
    image->colors=1 << (pcx_header.bits_per_pixel*pcx_header.planes);
    if (image->colors > 16)
      {
        /*
          256 color images have their color map at the end of the file.
        */
        (void) ReadData((char *) &pcx_header.colormap_signature,1,1,
          image->file);
        (void) ReadData((char *) pcx_colormap,3,(int) image->colors,
          image->file);
        p=pcx_colormap;
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=(*p++);
          image->colormap[i].green=(*p++);
          image->colormap[i].blue=(*p++);
        }
      }
    else
      if (image->colors == 2)
        if (Intensity(image->colormap[0]) == Intensity(image->colormap[1]))
          {
            /*
              Monochrome colormap.
            */
            image->colormap[0].red=MaxRGB;
            image->colormap[0].green=MaxRGB;
            image->colormap[0].blue=MaxRGB;
            image->colormap[1].red=0;
            image->colormap[1].green=0;
            image->colormap[1].blue=0;
          }
    (void) free((char *) pcx_colormap);
    /*
      Create image.
    */
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    (void) sprintf(image->comments,
      "\n  Imported from PCX raster image:  %s\n",image->filename);
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Convert PCX raster image to runlength-encoded packets.
    */
    q=image->pixels;
    if (pcx_header.planes > 1)
      {
        register int
          bits,
          mask;

        /*
          Convert multi-plane format into runlength-encoded pixels.
        */
        for (i=0; i < image->packets; i++)
        {
          q->index=0;
          q->length=0;
          q++;
        }
        for (y=0; y < image->rows; y++)
        {
          p=pcx_pixels+(y*pcx_header.bytes_per_line*pcx_header.planes);
          for (i=0; i < (int) pcx_header.planes; i++)
          {
            q=image->pixels+y*image->columns;
            for (x=0; x < pcx_header.bytes_per_line; x++)
            {
              bits=(*p++);
              for (mask=0x80; mask != 0; mask>>=1)
              {
                if (bits & mask)
                  q->index|=1 << i;
                q++;
              }
            }
          }
        }
      }
    else
      for (y=0; y < image->rows; y++)
      {
        p=pcx_pixels+y*pcx_header.bytes_per_line;
        switch (pcx_header.bits_per_pixel)
        {
          case 1:
          {
            register int
              bit;

            for (x=0; x < (image->columns-7); x+=8)
            {
              for (bit=7; bit >= 0; bit--)
              {
                q->index=((*p) & (0x01 << bit) ? 0x01 : 0x00);
                q->length=0;
                q++;
              }
              p++;
            }
            if ((image->columns % 8) != 0)
              {
                for (bit=7; bit >= (8-(image->columns % 8)); bit--)
                {
                  q->index=((*p) & (0x01 << bit) ? 0x01 : 0x00);
                  q->length=0;
                  q++;
                }
                p++;
              }
            break;
          }
          case 2:
          {
            for (x=0; x < (image->columns-3); x+=4)
            {
              q->index=(*p >> 6) & 0x3;
              q->length=0;
              q++;
              q->index=(*p >> 4) & 0x3;
              q->length=0;
              q++;
              q->index=(*p >> 2) & 0x3;
              q->length=0;
              q++;
              q->index=(*p) & 0x3;
              q->length=0;
              q++;
              p++;
            }
            if ((image->columns % 4) != 0)
              {
                for (i=3; i >= (4-(image->columns % 4)); i--)
                {
                  q->index=(*p >> (i*2)) & 0x03;
                  q->length=0;
                  q++;
                }
                p++;
              }
            break;
          }
          case 4:
          {
            for (x=0; x < (image->columns-1); x+=2)
            {
              q->index=(*p >> 4) & 0xf;
              q->length=0;
              q++;
              q->index=(*p) & 0xf;
              q->length=0;
              q++;
              p++;
            }
            if ((image->columns % 2) != 0)
              {
                q->index=(*p >> 4) & 0xf;
                q->length=0;
                q++;
                p++;
              }
            break;
          }
          case 8:
          {
            for (x=0; x < image->columns; x++)
            {
              q->index=(*p);
              q->length=0;
              q++;
              p++;
            }
            break;
          }
          default:
            break;
        }
      }
    (void) free((char *) pcx_pixels);
    SyncImage(image);
    /*
      Proceed to next image.
    */
    status=ReadData((char *) &pcx_header.identifier,1,1,image->file);
    if ((status == True) && (pcx_header.identifier == 0x0a))
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("PCX");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while ((status == True) && (pcx_header.identifier == 0x0a));
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d P I C T I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadPICTImage reads a Apple Macintosh QuickDraw/PICT image file
%  and returns it.  It allocates the memory necessary for the new Image
%  structure and returns a pointer to the new image.
%
%  The format of the ReadPICTImage routine is:
%
%      image=ReadPICTImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadPICTImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadPICTImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  Warning("Cannot read PICT images",image_info->filename);
  image=ReadMIFFImage(image_info);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d P N M I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadPNMImage reads a Portable Anymap image file and returns it.
%  It allocates the memory necessary for the new Image structure and returns
%  a pointer to the new image.
%
%  The format of the ReadPNMImage routine is:
%
%      image=ReadPNMImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadPNMImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/

static unsigned int GetInteger(file)
FILE
  *file;
{
  char
    c;

  int
    status;

  unsigned int
    value;

  /*
    Skip any leading whitespace.
  */
  do
  {
    status=ReadData(&c,1,1,file);
    if (status == False)
      return(0);
    if (c == '#')
      do
      {
        /*
          Skip any comments.
        */
        status=ReadData(&c,1,1,file);
        if (status == False)
          return(0);
      } while (c != '\n');
  } while (!isdigit(c));
  /*
    Evaluate number.
  */
  value=0;
  do
  {
    value*=10;
    value+=c-'0';
    status=ReadData(&c,1,1,file);
    if (status == False)
      return(0);
  }
  while (isdigit(c));
  return(value);
}

static Image *ReadPNMImage(image_info)
ImageInfo
  *image_info;
{
  char
    format;

  Image
    *image;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *pixels,
    *scale;

  unsigned int
    max_value,
    status;

  /*
    Allocate image structure.
  */
  image=AllocateImage("PNM");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read PNM image.
  */
  status=ReadData((char *) &format,1,1,image->file);
  do
  {
    /*
      Verify PNM identifier.
    */
    if ((status == False) || (format != 'P'))
      {
        Warning("not a PNM image file",(char *) NULL);
        DestroyImage(image);
        return((Image *) NULL);
      }
    /*
      Create image.
    */
    format=fgetc(image->file);
    image->columns=GetInteger(image->file);
    image->rows=GetInteger(image->file);
    if ((image->columns*image->rows) == 0)
      {
        Warning("unable to read image","image dimensions are zero");
        return((Image *) NULL);
      }
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) sprintf(image->comments,"\n  Imported from PNM raster image:  %s\n",
      image->filename);
    if ((format == '1') || (format == '4'))
      max_value=1;  /* bitmap */
    else
      max_value=GetInteger(image->file);
    scale=(unsigned char *) NULL;
    if (max_value != MaxRGB)
      {
        /*
          Compute pixel scaling table.
        */
        scale=(unsigned char *) malloc((max_value+1)*sizeof(unsigned char));
        if (scale == (unsigned char *) NULL)
          {
            Warning("unable to read image","memory allocation failed");
            DestroyImages(image);
            return((Image *) NULL);
          }
        for (i=0; i <= max_value; i++)
          scale[i]=(unsigned char) ((i*MaxRGB+(max_value >> 1))/max_value);
      }
    if ((format != '3') && (format != '6'))
      {
        /*
          Create gray scale colormap.
        */
        image->class=PseudoClass;
        image->colors=Min(max_value,MaxRGB)+1;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        if (image->colormap == (ColorPacket *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=(MaxRGB*i)/(image->colors-1);
          image->colormap[i].green=(MaxRGB*i)/(image->colors-1);
          image->colormap[i].blue=(MaxRGB*i)/(image->colors-1);
        }
      }
    /*
      Convert PNM pixels to runlength-encoded MIFF packets.
    */
    q=image->pixels;
    switch (format)
    {
      case '1':
      {
        /*
          Convert PBM image to runlength-encoded packets.
        */
        for (i=0; i < image->packets; i++)
        {
          q->index=GetInteger(image->file);
          if (q->index > 1)
            q->index=1;
          q->length=0;
          q++;
        }
        SyncImage(image);
        break;
      }
      case '2':
      {
        /*
          Convert PGM image to runlength-encoded packets.
        */
        if (max_value == MaxRGB)
          for (i=0; i < image->packets; i++)
          {
            q->index=GetInteger(image->file);
            q->length=0;
            q++;
          }
        else
          for (i=0; i < image->packets; i++)
          {
            q->index=scale[GetInteger(image->file)];
            q->length=0;
            q++;
          }
        SyncImage(image);
        break;
      }
      case '3':
      {
        /*
          Convert PNM image to runlength-encoded packets.
        */
        if (max_value == MaxRGB)
          for (i=0; i < image->packets; i++)
          {
            q->red=GetInteger(image->file);
            q->green=GetInteger(image->file);
            q->blue=GetInteger(image->file);
            q->index=0;
            q->length=0;
            q++;
          }
        else
          for (i=0; i < image->packets; i++)
          {
            q->red=scale[GetInteger(image->file)];
            q->green=scale[GetInteger(image->file)];
            q->blue=scale[GetInteger(image->file)];
            q->index=0;
            q->length=0;
            q++;
          }
        break;
      }
      case '4':
      {
        unsigned char
          bit,
          byte;

        unsigned int
          x,
          y;

        /*
          Convert PBM raw image to runlength-encoded packets.
        */
        for (y=0; y < image->rows; y++)
        {
          bit=0;
          byte=0;
          for (x=0; x < image->columns; x++)
          {
            if (bit == 0)
              byte=fgetc(image->file);
            q->index=(byte & 0x80) ? 0 : 1;
            q->length=0;
            q++;
            bit++;
            if (bit == 8)
              bit=0;
            byte<<=1;
          }
        }
        SyncImage(image);
        break;
      }
      case '5':
      {
        /*
          Convert PGM raw image to runlength-encoded packets.
        */
        pixels=(unsigned char *)
          malloc((unsigned int) image->packets*sizeof(unsigned char));
        if (pixels == (unsigned char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        status=ReadData((char *) pixels,1,(int) image->packets,image->file);
        if (status == False)
          {
            Warning("insufficient image data in file",image->filename);
            DestroyImages(image);
            return((Image *) NULL);
          }
        /*
          Convert PNM raw image to runlength-encoded packets.
        */
        p=pixels;
        if (max_value == MaxRGB)
          for (i=0; i < image->packets; i++)
          {
            q->index=(*p++);
            q->length=0;
            q++;
          }
        else
          for (i=0; i < image->packets; i++)
          {
            q->index=scale[*p++];
            q->length=0;
            q++;
          }
        SyncImage(image);
        break;
      }
      case '6':
      {
        /*
          Convert PNM raster image to runlength-encoded packets.
        */
        pixels=(unsigned char *)
          malloc((unsigned int) image->packets*3*sizeof(unsigned char));
        if (pixels == (unsigned char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        status=ReadData((char *) pixels,1,(int) image->packets*3,image->file);
        if (status == False)
          {
            Warning("insufficient image data in file",image->filename);
            DestroyImages(image);
            return((Image *) NULL);
          }
        p=pixels;
        if (max_value == MaxRGB)
          for (i=0; i < image->packets; i++)
          {
            q->red=(*p++);
            q->green=(*p++);
            q->blue=(*p++);
            q->index=0;
            q->length=0;
            q++;
          }
        else
          for (i=0; i < image->packets; i++)
          {
            q->red=scale[*p++];
            q->green=scale[*p++];
            q->blue=scale[*p++];
            q->index=0;
            q->length=0;
            q++;
          }
        break;
      }
      default:
      {
        Warning("not a PNM image file",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    }
    if (scale != (unsigned char *) NULL)
      (void) free((char *) scale);
    if (image->class == PseudoClass)
      CompressColormap(image);
    /*
      Proceed to next image.
    */
    status=ReadData((char *) &format,1,1,image->file);
    if ((status == True) && (format == 'P'))
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("PNM");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while ((status == True) && (format == 'P'));
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d P S I m a g e                                                      %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadPSImage reads a Adobe Postscript image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadPSImage routine is:
%
%      image=ReadPSImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadPSImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%    o density: Specifies a pointer to a image density string;  horizonal
%      and vertical dots per inch.
%
%
*/
static Image *ReadPSImage(image_info)
ImageInfo
  *image_info;
{
#define XResolution  72
#define YResolution  72

  char
    command[2048],
    clip_geometry[2048],
    *device,
    *directory,
    filename[2048],
    options[2048];

  Image
    *image,
    *next_image;

  unsigned int
    status;

  /*
    Allocate image structure.
  */
  image=AllocateImage("PS");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Determine if Postscript specifies a bounding box.
  */
  *options='\0';
  *clip_geometry='\0';
  while (fgets(command,sizeof(command)-1,image->file) != (char *) NULL)
    if (strncmp("%%BoundingBox:",command,strlen("%%BoundingBox:")) == 0)
      {
        int
          count,
          lower_x,
          lower_y,
          upper_x,
          upper_y,
          x,
          y;

        unsigned int
          x_resolution,
          y_resolution;

        count=sscanf(command,"%%%%BoundingBox: %d %d %d %d",&lower_x,&lower_y,
          &upper_x,&upper_y);
        if (count != 4)
          break;
        /*
          Set clip geometry as specified by the bounding box.
        */
        x_resolution=XResolution;
        y_resolution=YResolution;
        if (image_info->density != (char *) NULL)
          {
            int
              flags;

            /*
              User specified density.
            */
            flags=XParseGeometry(image_info->density,&x,&y,&x_resolution,
              &y_resolution);
            if ((flags & WidthValue) == 0)
              x_resolution=XResolution;
            if ((flags & HeightValue) == 0)
              y_resolution=x_resolution;
          }
        (void) sprintf(clip_geometry,"%ux%u+%u-%u",
          ((upper_x-lower_x)*x_resolution+(XResolution >> 1))/XResolution,
          ((upper_y-lower_y)*y_resolution+(YResolution >> 1))/YResolution,
          (lower_x*x_resolution+(XResolution >> 1))/XResolution,
          ((lower_y*y_resolution+(YResolution >> 1))/YResolution));
        if (image_info->page == (char *) NULL)
          (void) sprintf(options,"-g%ux%u",
            (upper_x*x_resolution+(XResolution >> 1))/XResolution,
            (upper_y*y_resolution+(YResolution >> 1))/YResolution);
        break;
      }
  CloseImage(image);
  /*
    Rendered Postscript goes to temporary PNM file.
  */
  directory=(char *) getenv("TMPDIR");
  if (directory == (char *) NULL)
    directory="/tmp";
  (void) sprintf(filename,"%s/magickXXXXXX",directory);
  (void) mktemp(filename);
  device="ppmraw";
  if (image_info->monochrome)
    device="pbmraw";
  /*
    Determine if page geometry or density options are specified.
  */
  if (image_info->page != (char *) NULL)
    {
      (void) strcat(options," -g");
      (void) strcat(options,image_info->page);
    }
  if (image_info->density != (char *) NULL)
    {
      (void) strcat(options," -r");
      (void) strcat(options,image_info->density);
    }
  /*
    Use Ghostscript to convert Postscript image.
  */
  (void) sprintf(command,"gs -q -sDEVICE=%s -sOutputFile=%s %s %s",
    device,filename,options,image_info->filename);
  (void) strcat(command," < /dev/null > /dev/null");
  status=system(command);
  if (status != 0)
    {
      Warning("unable to execute ghostscript (gs)",image_info->filename);
      return((Image *) NULL);
    }
  (void) strcpy(image_info->filename,filename);
  (void) strcpy(filename,image->filename);
  DestroyImage(image);
  image=ReadPNMImage(image_info);
  (void) unlink(image_info->filename);
  if (image == (Image *) NULL)
    {
      Warning("Postscript translation failed",image_info->filename);
      return((Image *) NULL);
    }
  do
  {
    if (image->previous == (Image *) NULL)
      (void) strcpy(image->filename,filename);
    else
      (void) sprintf(image->filename,"%s.%u",filename,image->scene);
    (void) strcpy(image->magick,"PS");
    if (*clip_geometry != '\0')
      {
        /*
          Clip image as specified by the bounding box.
        */
        TransformImage(&image,clip_geometry,(char *) NULL,(char *) NULL);
        if (image->next != (Image *) NULL)
          image->next->previous=image;
      }
    next_image=image->next;
    if (next_image != (Image *) NULL)
      image=next_image;
  } while (next_image != (Image *) NULL);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d R G B I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadRGBImage reads an image of raw red, green, and blue bytes and
%  returns it.  It allocates the memory necessary for the new Image structure
%  and returns a pointer to the new image.
%
%  The format of the ReadRGBImage routine is:
%
%      image=ReadRGBImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadRGBImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadRGBImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *rgb_pixels;

  unsigned int
    height,
    width;

  /*
    Allocate image structure.
  */
  image=AllocateImage("RGB");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create image.
  */
  width=512;
  height=512;
  if (image_info->geometry != (char *) NULL)
    (void) XParseGeometry(image_info->geometry,&x,&y,&width,&height);
  image->columns=width;
  image->rows=height;
  image->packets=image->columns*image->rows;
  rgb_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*3*sizeof(unsigned char));
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  if ((rgb_pixels == (unsigned char *) NULL) ||
      (image->pixels == (RunlengthPacket *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert raster image to runlength-encoded packets.
  */
  (void) ReadData((char *) rgb_pixels,3,(int) (image->columns*image->rows),
    image->file);
  p=rgb_pixels;
  switch (image_info->interlace)
  {
    case NoneInterlace:
    default:
    {
      /*
        No interlacing:  RGBRGBRGBRGBRGBRGB...
      */
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->red=(*p++);
        q->green=(*p++);
        q->blue=(*p++);
        q->index=0;
        q->length=0;
        q++;
      }
      break;
    }
    case LineInterlace:
    {
      /*
        Line interlacing:  RRR...GGG...BBB...RRR...GGG...BBB...
      */
      for (y=0; y < image->rows; y++)
      {
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->red=(*p++);
          q->index=0;
          q->length=0;
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->green=(*p++);
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->blue=(*p++);
          q++;
        }
      }
      break;
    }
    case PlaneInterlace:
    {
      /*
        Plane interlacing:  RRRRRR...GGGGGG...BBBBBB...
      */
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->red=(*p++);
        q->index=0;
        q->length=0;
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->green=(*p++);
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->blue=(*p++);
        q++;
      }
      break;
    }
  }
  (void) free((char *) rgb_pixels);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d R L E I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadRLEImage reads a run-length encoded Utah Raster Toolkit
%  image file and returns it.  It allocates the memory necessary for the new
%  Image structure and returns a pointer to the new image.
%
%  The format of the ReadRLEImage routine is:
%
%      image=ReadRLEImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadRLEImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadRLEImage(image_info)
ImageInfo
  *image_info;
{
#define SkipLinesOp  0x01
#define SetColorOp  0x02
#define SkipPixelsOp  0x03
#define ByteDataOp  0x05
#define RunDataOp  0x06
#define EOFOp  0x07

  char
    magick[12];

  Image
    *image;

  int
    opcode,
    operand,
    status,
    x,
    y;

  register int
    i,
    j;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    background_color[256],
    *colormap,
    header[2048],
    integer[2],
    pixel,
    plane,
    *rle_pixels;

  unsigned int
    bits_per_pixel,
    flags,
    map_length,
    number_colormaps,
    number_planes;

  /*
    Allocate image structure.
  */
  image=AllocateImage("RLE");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Determine if this is a RLE file.
  */
  status=ReadData((char *) magick,1,2,image->file);
  if ((status == False) || (strncmp(magick,"\122\314",2) != 0))
    {
      Warning("not a RLE image file",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  do
  {
    /*
      Read image header.
    */
    status=ReadData((char *) header,1,13,image->file);
    if (status == False)
      {
        Warning("unable to read RLE image header",(char *) NULL);
        DestroyImage(image);
        return((Image *) NULL);
      }
    image->columns=header[4]+(header[5] << 8);
    image->rows=header[6]+(header[7] << 8);
    image->packets=image->columns*image->rows;
    flags=header[8];
    image->alpha=flags & 0x04;
    number_planes=header[9];
    bits_per_pixel=header[10];
    number_colormaps=header[11];
    map_length=1 << header[12];
    if ((number_planes == 0) || (number_planes == 2) || (bits_per_pixel != 8) ||
        ((image->columns*image->rows) == 0))
      {
        Warning("unsupported RLE image file",(char *) NULL);
        DestroyImage(image);
        return((Image *) NULL);
      }
    if (flags & 0x02)
      {
        /*
          No background color-- initialize to black.
        */
        for (i=0; i < number_planes; i++)
          background_color[i]=(unsigned char) 0;
        (void) fgetc(image->file);
      }
    else
      {
        /*
          Initialize background color.
        */
        p=background_color;
        for (i=0; i < number_planes; i++)
          *p++=(unsigned char) fgetc(image->file);
        if ((number_planes % 2) == 0)
          (void) fgetc(image->file);
      }
    colormap=(unsigned char *) NULL;
    if (number_colormaps != 0)
      {
        /*
          Read image colormaps.
        */
        colormap=(unsigned char *)
          malloc(number_colormaps*map_length*sizeof(unsigned char));
        if (colormap == (unsigned char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImage(image);
            return((Image *) NULL);
          }
        p=colormap;
        for (i=0; i < number_colormaps; i++)
          for (j=0; j < map_length; j++)
          {
            (void) fgetc(image->file);
            *p++=(unsigned char) fgetc(image->file);
          }
      }
    /*
      Allocate image comment.
    */
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    if (image->comments == (char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImage(image);
        return((Image *) NULL);
      }
    (void) sprintf(image->comments,"\n  Imported from Utah raster image:  %s\n",
      image->filename);
    if (flags & 0x08)
      {
        unsigned int
          comment_length;

        /*
          Read image comment.
        */
        (void) ReadData((char *) integer,1,2,image->file);
        comment_length=integer[0]+(integer[1] << 8);
        image->comments=(char *) realloc((char *) image->comments,
          (unsigned int) (strlen(image->comments)+comment_length+2048));
        if (image->comments == (char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImage(image);
            return((Image *) NULL);
          }
        (void) strcat(image->comments,"\n  ");
        status=ReadData((char *) image->comments+strlen(image->comments),1,
          (int) comment_length+(comment_length % 2 ? 0 : 1),image->file);
        if (status == False)
          {
            Warning("unable to read RLE comment",(char *) NULL);
            DestroyImage(image);
            return((Image *) NULL);
          }
        (void) strcat(image->comments,"\n");
      }
    /*
      Allocate RLE pixels.
    */
    if (image->alpha)
      number_planes++;
    rle_pixels=(unsigned char *)
      malloc((unsigned int) image->packets*number_planes*sizeof(unsigned char));
    if (rle_pixels == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImage(image);
        return((Image *) NULL);
      }
    if ((flags & 0x01) && ((~flags) & 0x02))
      {
        /*
          Set background color.
        */
        p=rle_pixels;
        for (i=0; i < image->packets; i++)
        {
          if (!image->alpha)
            for (j=0; j < number_planes; j++)
              *p++=background_color[j];
          else
            {
              for (j=0; j < (number_planes-1); j++)
                *p++=background_color[j];
              *p++=0;  /* initialize alpha channel */
            }
        }
      }
    /*
      Read runlength-encoded image.
    */
    plane=0;
    x=0;
    y=0;
    (void) fgetc(image->file);
    opcode=fgetc(image->file);
    while (((opcode & 0x3f) != EOFOp) && (opcode != EOF))
    {
      switch (opcode & 0x3f)
      {
        case SkipLinesOp:
        {
          operand=fgetc(image->file);
          if (opcode & 0x40)
            {
              (void) ReadData((char *) integer,1,2,image->file);
              operand=integer[0]+(integer[1] << 8);
            }
          x=0;
          y+=operand;
          break;
        }
        case SetColorOp:
        {
          operand=fgetc(image->file);
          plane=operand;
          if (plane == 255)
            plane=number_planes-1;
          x=0;
          break;
        }
        case SkipPixelsOp:
        {
          operand=fgetc(image->file);
          if (opcode & 0x40)
            {
              (void) ReadData((char *) integer,1,2,image->file);
              operand=integer[0]+(integer[1] << 8);
            }
          x+=operand;
          break;
        }
        case ByteDataOp:
        {
          operand=fgetc(image->file);
          if (opcode & 0x40)
            {
              (void) ReadData((char *) integer,1,2,image->file);
              operand=integer[0]+(integer[1] << 8);
            }
          p=rle_pixels+((image->rows-y-1)*image->columns*number_planes)+
            x*number_planes+plane;
          operand++;
          for (i=0; i < operand; i++)
          {
            pixel=fgetc(image->file);
            if ((y < image->rows) && ((x+i) < image->columns))
              *p=pixel;
            p+=number_planes;
          }
          if (operand & 0x01)
            (void) fgetc(image->file);
          x+=operand;
          break;
        }
        case RunDataOp:
        {
          operand=fgetc(image->file);
          if (opcode & 0x40)
            {
              (void) ReadData((char *) integer,1,2,image->file);
              operand=integer[0]+(integer[1] << 8);
            }
          pixel=fgetc(image->file);
          (void) fgetc(image->file);
          operand++;
          p=rle_pixels+((image->rows-y-1)*image->columns*number_planes)+
            x*number_planes+plane;
          for (i=0; i < operand; i++)
          {
            if ((y < image->rows) && ((x+i) < image->columns))
              *p=pixel;
            p+=number_planes;
          }
          x+=operand;
          break;
        }
        default:
          break;
      }
      opcode=fgetc(image->file);
    }
    if (number_colormaps != 0)
      {
        unsigned char
          pixel;

        unsigned int
          mask;

        /*
          Apply colormap transformation to image.
        */
        mask=(map_length-1);
        p=rle_pixels;
        for (i=0; i < image->packets; i++)
          for (j=0; j < number_planes; j++)
          {
            pixel=colormap[j*map_length+(*p & mask)];
            *p++=pixel;
          }
        (void) free((char *) colormap);
      }
    /*
      Create image.
    */
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    if (image->pixels == (RunlengthPacket *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImage(image);
        return((Image *) NULL);
      }
    p=rle_pixels;
    q=image->pixels;
    if (number_planes >= 3)
      {
        /*
          Convert raster image to DirectClass runlength-encoded packets.
        */
        for (i=0; i < (image->columns*image->rows); i++)
        {
          q->red=(*p++);
          q->green=(*p++);
          q->blue=(*p++);
          q->index=(unsigned short) (image->alpha ? (*p++) : 0);
          q->length=0;
          q++;
        }
      }
    else
      {
        unsigned short
          index;

        /*
          Create grayscale map.
        */
        image->class=PseudoClass;
        image->colors=256;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        if (image->colormap == (ColorPacket *) NULL)
          {
            Warning("unable to read image","memory allocation failed");
            DestroyImage(image);
            return((Image *) NULL);
          }
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=(unsigned char) i;
          image->colormap[i].green=(unsigned char) i;
          image->colormap[i].blue=(unsigned char) i;
        }
        /*
          Convert raster image to PseudoClass runlength-encoded packets.
        */
        for (i=0; i < (image->columns*image->rows); i++)
        {
          index=(unsigned short) (*p++);
          q->red=image->colormap[index].red;
          q->green=image->colormap[index].green;
          q->blue=image->colormap[index].blue;
          q->index=index;
          q->length=0;
          q++;
        }
      }
    (void) free((char *) rle_pixels);
    /*
      Proceed to next image.
    */
    (void) fgetc(image->file);
    status=ReadData((char *) magick,1,2,image->file);
    if ((status == True) && (strncmp(magick,"\122\314",2) == 0))
      {
        /*
          Allocate next image structure.
        */
        image->next=AllocateImage("RLE");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while ((status == True) && (strncmp(magick,"\122\314",2) == 0));
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d S U N I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadSUNImage reads a SUN image file and returns it.  It allocates
%  the memory necessary for the new Image structure and returns a pointer to
%  the new image.
%
%  The format of the ReadSUNImage routine is:
%
%      image=ReadSUNImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadSUNImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadSUNImage(image_info)
ImageInfo
  *image_info;
{
#define RMT_EQUAL_RGB  1
#define RMT_NONE  0
#define RMT_RAW  2
#define RT_STANDARD  1
#define RT_ENCODED  2
#define RT_FORMAT_RGB  3

  typedef struct _SUNHeader
  {
    unsigned long
      magic,
      width,
      height,
      depth,
      length,
      type,
      maptype,
      maplength;
  } SUNHeader;

  Image
    *image;

  register int
    bit,
    i,
    x,
    y;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  SUNHeader
    sun_header;

  unsigned char
    *sun_data,
    *sun_pixels;

  unsigned int
    status;

  /*
    Allocate image structure.
  */
  image=AllocateImage("SUN");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read SUN raster header.
  */
  sun_header.magic=MSBFirstReadLong(image->file);
  do
  {
    /*
      Verify SUN identifier.
    */
    if (sun_header.magic != 0x59a66a95)
      {
        Warning("not a SUN raster,",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    sun_header.width=MSBFirstReadLong(image->file);
    sun_header.height=MSBFirstReadLong(image->file);
    sun_header.depth=MSBFirstReadLong(image->file);
    sun_header.length=MSBFirstReadLong(image->file);
    sun_header.type=MSBFirstReadLong(image->file);
    sun_header.maptype=MSBFirstReadLong(image->file);
    sun_header.maplength=MSBFirstReadLong(image->file);
    switch (sun_header.maptype)
    {
      case RMT_NONE:
      {
        if (sun_header.depth < 24)
          {
            /*
              Create linear color ramp.
            */
            image->colors=1 << sun_header.depth;
            image->colormap=(ColorPacket *)
              malloc(image->colors*sizeof(ColorPacket));
            if (image->colormap == (ColorPacket *) NULL)
              {
                Warning("memory allocation error",(char *) NULL);
                return((Image *) NULL);
              }
            for (i=0; i < image->colors; i++)
            {
              image->colormap[i].red=(255*i)/(image->colors-1);
              image->colormap[i].green=(255*i)/(image->colors-1);
              image->colormap[i].blue=(255*i)/(image->colors-1);
            }
          }
        break;
      }
      case RMT_EQUAL_RGB:
      {
        unsigned char
          *sun_colormap;

        /*
          Read SUN raster colormap.
        */
        image->colors=sun_header.maplength/3;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        sun_colormap=(unsigned char *)
          malloc(image->colors*sizeof(unsigned char));
        if ((image->colormap == (ColorPacket *) NULL) ||
            (sun_colormap == (unsigned char *) NULL))
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) ReadData((char *) sun_colormap,1,(int) image->colors,
          image->file);
        for (i=0; i < image->colors; i++)
          image->colormap[i].red=sun_colormap[i];
        (void) ReadData((char *) sun_colormap,1,(int) image->colors,
          image->file);
        for (i=0; i < image->colors; i++)
          image->colormap[i].green=sun_colormap[i];
        (void) ReadData((char *) sun_colormap,1,(int) image->colors,
          image->file);
        for (i=0; i < image->colors; i++)
          image->colormap[i].blue=sun_colormap[i];
        (void) free((char *) sun_colormap);
        break;
      }
      case RMT_RAW:
      {
        unsigned char
          *sun_colormap;

        /*
          Read SUN raster colormap.
        */
        sun_colormap=(unsigned char *)
          malloc(sun_header.maplength*sizeof(unsigned char));
        if (sun_colormap == (unsigned char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) ReadData((char *) sun_colormap,1,(int) sun_header.maplength,
          image->file);
        (void) free((char *) sun_colormap);
        break;
      }
      default:
      {
        Warning("colormap type is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    }
    sun_data=(unsigned char *) malloc(sun_header.length*sizeof(unsigned char));
    if (sun_data == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    status=ReadData((char *) sun_data,1,(int) sun_header.length,image->file);
    if (status == False)
      {
        Warning("unable to read image data",image_info->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    sun_pixels=sun_data;
    if (sun_header.type == RT_ENCODED)
      {
        unsigned int
          number_pixels;

        /*
          Read run-length encoded raster pixels.
        */
        number_pixels=(sun_header.width+(sun_header.width % 2))*
          sun_header.height*(((sun_header.depth-1) >> 3)+1);
        sun_pixels=(unsigned char *)
          malloc(number_pixels*sizeof(unsigned char));
        if (sun_pixels == (unsigned char *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) SUNDecodeImage(sun_data,sun_pixels,
          (unsigned int) sun_header.width,(unsigned int) sun_header.height);
        (void) free((char *) sun_data);
      }
    /*
      Create image.
    */
    image->alpha=(sun_header.depth == 32);
    image->class=(sun_header.depth < 24 ? PseudoClass : DirectClass);
    image->columns=sun_header.width;
    image->rows=sun_header.height;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    (void) sprintf(image->comments,
      "\n  Imported from SUN raster image:  %s\n",image->filename);
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Convert SUN raster image to runlength-encoded packets.
    */
    p=sun_pixels;
    q=image->pixels;
    if (sun_header.depth == 1)
      for (y=0; y < image->rows; y++)
      {
        /*
          Convert bitmap scanline to runlength-encoded color packets.
        */
        for (x=0; x < (image->columns >> 3); x++)
        {
          for (bit=7; bit >= 0; bit--)
          {
            q->index=((*p) & (0x01 << bit) ? 0x00 : 0x01);
            q->length=0;
            q++;
          }
          p++;
        }
        if ((image->columns % 8) != 0)
          {
            for (bit=7; bit >= (8-(image->columns % 8)); bit--)
            {
              q->index=((*p) & (0x01 << bit) ? 0x00 : 0x01);
              q->length=0;
              q++;
            }
            p++;
          }
        if ((((image->columns/8)+(image->columns % 8 ? 1 : 0)) % 2) != 0)
          p++;
      }
    else
      if (image->class == PseudoClass)
        for (y=0; y < image->rows; y++)
        {
          /*
            Convert PseudoColor scanline to runlength-encoded color packets.
          */
          for (x=0; x < image->columns; x++)
          {
            q->index=(*p++);
            q->length=0;
            q++;
          }
          if ((image->columns % 2) != 0)
            p++;
        }
      else
        for (y=0; y < image->rows; y++)
        {
          /*
            Convert DirectColor scanline to runlength-encoded color packets.
          */
          for (x=0; x < image->columns; x++)
          {
            q->index=(unsigned short) (image->alpha ? (*p++) : 0);
            if (sun_header.type == RT_STANDARD)
              {
                q->blue=(*p++);
                q->green=(*p++);
                q->red=(*p++);
              }
            else
              {
                q->red=(*p++);
                q->green=(*p++);
                q->blue=(*p++);
              }
            if (image->colors != 0)
              {
                q->red=image->colormap[q->red].red;
                q->green=image->colormap[q->green].green;
                q->blue=image->colormap[q->blue].blue;
              }
            q->length=0;
            q++;
          }
          if (((image->columns % 2) != 0) && (image->alpha == False))
            p++;
        }
    (void) free((char *) sun_pixels);
    if (image->class == PseudoClass)
      {
        SyncImage(image);
        CompressColormap(image);
      }
    /*
      Proceed to next image.
    */
    sun_header.magic=MSBFirstReadLong(image->file);
    if (sun_header.magic == 0x59a66a95)
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("SUN");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (sun_header.magic == 0x59a66a95);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d T A R G A I m a g e                                                %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadTARGAImage reads a Truevision Targa image file and returns
%  it.  It allocates the memory necessary for the new Image structure and
%  returns a pointer to the new image.
%
%  The format of the ReadTARGAImage routine is:
%
%      image=ReadTARGAImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadTARGAImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadTARGAImage(image_info)
ImageInfo
  *image_info;
{
#define TargaColormap 1
#define TargaRGB 2
#define TargaMonochrome 3
#define TargaRLEColormap  9
#define TargaRLERGB  10
#define TargaRLEMonochrome  11

  typedef struct _TargaHeader
  {
    unsigned char
      id_length,
      colormap_type,
      image_type;

    unsigned short
      colormap_index,
      colormap_length;

    unsigned char
      colormap_size;

    unsigned short
      x_origin,
      y_origin,
      width,
      height;

    unsigned char
      pixel_size,
      attributes;
  } TargaHeader;

  Image
    *image;

  register int
    i,
    x,
    y;

  register RunlengthPacket
    *q;

  TargaHeader
    targa_header;

  unsigned char
    blue,
    green,
    j,
    k,
    red,
    runlength;

  unsigned int
    base,
    flag,
    real,
    skip,
    status,
    true;

  unsigned short
    index;

  /*
    Allocate image structure.
  */
  image=AllocateImage("TGA");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Determine if this is a TARGA file.
  */
  status=ReadData((char *) &targa_header.id_length,1,1,image->file);
  do
  {
    /*
      Read TARGA header information.
    */
    if (status == False)
      {
        Warning("not a TARGA image file",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    targa_header.colormap_type=fgetc(image->file);
    targa_header.image_type=fgetc(image->file);
    targa_header.colormap_index=LSBFirstReadShort(image->file);
    targa_header.colormap_length=LSBFirstReadShort(image->file);
    targa_header.colormap_size=fgetc(image->file);
    targa_header.x_origin=LSBFirstReadShort(image->file);
    targa_header.y_origin=LSBFirstReadShort(image->file);
    targa_header.width=LSBFirstReadShort(image->file);
    targa_header.height=LSBFirstReadShort(image->file);
    targa_header.pixel_size=fgetc(image->file);
    targa_header.attributes=fgetc(image->file);
    /*
      Create image.
    */
    image->alpha=targa_header.pixel_size == 32;
    image->columns=targa_header.width;
    image->rows=targa_header.height;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    if (targa_header.id_length != 0)
      image->comments=(char *) malloc((targa_header.id_length+1)*sizeof(char));
    else
      image->comments=(char *)
        malloc((strlen(image->filename)+2048)*sizeof(char));
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (targa_header.id_length == 0)
      (void) sprintf(image->comments,
        "\n  Imported from TARGA raster image:  %s\n",image->filename);
    else
      {
        (void) ReadData(image->comments,1,targa_header.id_length,image->file);
        image->comments[targa_header.id_length]='\0';
      }
    if (targa_header.colormap_type != 0)
      {
        /*
          Read TARGA raster colormap.
        */
        image->class=PseudoClass;
        image->colors=targa_header.colormap_length;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        if (image->colormap == (ColorPacket *) NULL)
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        for (i=0; i < image->colors; i++)
        {
          switch (targa_header.colormap_size)
          {
            case 8:
            default:
            {
              /*
                Gray scale.
              */
              red=fgetc(image->file);
              green=red;
              blue=red;
              break;
            }
            case 15:
            case 16:
            {
              /*
                5 bits each of red green and blue.
              */
              j=fgetc(image->file);
              k=fgetc(image->file);
              red=(unsigned char) ((MaxRGB*((int) (k & 0x7c) >> 2))/31);
              green=(unsigned char)
                ((MaxRGB*(((int) (k & 0x03) << 3)+((int) (j & 0xe0) >> 5)))/31);
              blue=(unsigned char) ((MaxRGB*((int) (j & 0x1f)))/31);
              break;
            }
            case 32:
            case 24:
            {
              /*
                8 bits each of blue green and red.
              */
              blue=fgetc(image->file);
              green=fgetc(image->file);
              red=fgetc(image->file);
              break;
            }
          }
          image->colormap[i].red=red;
          image->colormap[i].green=green;
          image->colormap[i].blue=blue;
        }
      }
    /*
      Convert TARGA pixels to runlength-encoded packets.
    */
    base=0;
    flag=0;
    index=0;
    skip=False;
    real=0;
    runlength=0;
    true=0;
    for (y=0; y < image->rows; y++)
    {
      real=true;
      if (((unsigned char) (targa_header.attributes & 0x20) >> 5) == 0)
        real=image->rows-real-1;
      q=image->pixels+(real*image->columns)-1;
      for (x=0; x < image->columns; x++)
      {
        if ((targa_header.image_type == TargaRLEColormap) ||
            (targa_header.image_type == TargaRLERGB) ||
            (targa_header.image_type == TargaRLEMonochrome))
          if (runlength != 0)
            {
              runlength--;
              skip=flag != 0;
            }
          else
            {
              status=ReadData((char *) &runlength,1,1,image->file);
              if (status == False)
                {
                  Warning("unable to read image data",image_info->filename);
                  DestroyImages(image);
                  return((Image *) NULL);
                }
              flag=runlength & 0x80;
              if (flag != 0)
                runlength-=128;
              skip=False;
            }
        if (!skip)
          switch (targa_header.pixel_size)
          {
            case 8:
            default:
            {
              /*
                Gray scale.
              */
              index=fgetc(image->file);
              if (targa_header.colormap_type == 0)
                {
                  red=(unsigned char) index;
                  green=(unsigned char) index;
                  blue=(unsigned char) index;
                }
              else
                {
                  red=image->colormap[index].red;
                  green=image->colormap[index].green;
                  blue=image->colormap[index].blue;
                }
              break;
            }
            case 15:
            case 16:
            {
              /*
                5 bits each of red green and blue.
              */
              j=fgetc(image->file);
              k=fgetc(image->file);
              red=(unsigned char) ((MaxRGB*((int) (k & 0x7c) >> 2))/31);
              green=(unsigned char)
                ((MaxRGB*(((int) (k & 0x03) << 3)+((int) (j & 0xe0) >> 5)))/31);
              blue=(unsigned char) ((MaxRGB*((int) (j & 0x1f)))/31);
              break;
            }
            case 24:
            case 32:
            {
              /*
                8 bits each of blue green and red.
              */
              blue=fgetc(image->file);
              green=fgetc(image->file);
              red=fgetc(image->file);
              if (targa_header.pixel_size == 32)
                index=fgetc(image->file);
              break;
            }
          }
        if (status == False)
          {
            Warning("unable to read image data",image_info->filename);
            DestroyImages(image);
            return((Image *) NULL);
          }
        q->red=red;
        q->green=green;
        q->blue=blue;
        q->index=index;
        q->length=0;
        q++;
      }
      if (((unsigned char) (targa_header.attributes & 0xc0) >> 6) == 4)
        true+=4;
      else
        if (((unsigned char) (targa_header.attributes & 0xc0) >> 6) == 2)
          true+=2;
        else
          true++;
      if (true >= image->rows)
        {
          base++;
          true=base;
        }
    }
    if ((targa_header.image_type == TargaMonochrome) ||
        (targa_header.image_type == TargaRLEMonochrome))
      {
        QuantizeImage(image,2,8,False,GRAYColorspace,True);
        SyncImage(image);
      }
    /*
      Proceed to next image.
    */
    status=ReadData((char *) &targa_header.id_length,1,1,image->file);
    if (status == True)
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("TGA");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (status == True);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d T E X T I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadTEXTImage reads a text file and returns it as an image.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadTEXTImage routine is:
%
%      image=ReadTEXTImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadTEXTImage returns a pointer to the image after
%      reading. A null image is returned if there is a a memory shortage or if
%      the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadTEXTImage(image_info)
ImageInfo
  *image_info;
{
#define PageHeight  60
#define PageWidth  80

  char
    *resource_value,
    *text_status,
    text[2048];

  Display
    *display;

  Image
    *image;

  int
    status,
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *p;

  RunlengthPacket
    background_color;

  unsigned int
    height,
    width;

  XAnnotateInfo
    annotate_info;

  XFontStruct
    *font_info;

  XPixelInfo
    pixel_info;

  XResourceInfo
    resource_info;

  XrmDatabase
    resource_database,
    server_database;

  XStandardColormap
    map_info;

  XVisualInfo
    *visual_info;

  XWindowInfo
    image_window;

  /*
    Allocate image structure.
  */
  image=AllocateImage("TEXT");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Open X server connection.
  */
  display=XOpenDisplay(image_info->server_name);
  if (display == (Display *) NULL)
    {
      Warning("unable to connect to X server",
        XDisplayName(image_info->server_name));
      return((Image *) NULL);
    }
  /*
    Set our forgiving error handler.
  */
  XSetErrorHandler(XError);
  /*
    Initialize resource database.
  */
  XrmInitialize();
  resource_database=XrmGetDatabase(display);
  resource_value=XResourceManagerString(display);
  if (resource_value == (char *) NULL)
    resource_value="";
  server_database=XrmGetStringDatabase(resource_value);
  XrmMergeDatabases(server_database,&resource_database);
  /*
    Get user defaults from X resource database.
  */
  XGetResourceInfo(resource_database,client_name,&resource_info);
  /*
    Initialize visual info.
  */
  visual_info=XBestVisualInfo(display,"default",(char *) NULL,
    (XStandardColormap *) NULL);
  if (visual_info == (XVisualInfo *) NULL)
    {
      Warning("unable to get visual",resource_info.visual_type);
      return((Image *) NULL);
    }
  /*
    Determine background and foreground colors.
  */
  map_info.colormap=XDefaultColormap(display,visual_info->screen);
  XGetPixelInfo(display,visual_info,&map_info,&resource_info,(Image *) NULL,
    &pixel_info);
  pixel_info.annotate_color=pixel_info.foreground_color;
  pixel_info.annotate_index=1;
  /*
    Initialize font info.
  */
  if (image_info->font != (char *) NULL)
    resource_info.font=image_info->font;
  font_info=XBestFont(display,&resource_info,(char *) NULL,~0);
  if (font_info == (XFontStruct *) NULL)
    {
      Warning("unable to load font",resource_info.font);
      return((Image *) NULL);
    }
  /*
    Window superclass.
  */
  image_window.id=XRootWindow(display,visual_info->screen);
  image_window.screen=visual_info->screen;
  image_window.depth=visual_info->depth;
  image_window.visual_info=visual_info;
  image_window.pixel_info=(&pixel_info);
  image_window.font_info=font_info;
  /*
    Initialize Image structure.
  */
  width=PageWidth;
  height=PageHeight;
  if (image_info->density != (char *) NULL)
    {
      int
        flags;

      /*
        User specified density.
      */
      flags=XParseGeometry(image_info->density,&x,&y,&width,&height);
      if ((flags & WidthValue) == 0)
        width=PageWidth;
      if ((flags & HeightValue) == 0)
        height=width;
    }
  image->columns=width*font_info->max_bounds.width+4;
  image->rows=height*
    (font_info->max_bounds.ascent+font_info->max_bounds.descent)+4;
  image->packets=image->columns*image->rows;
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  image->comments=(char *) malloc((strlen(image->filename)+2048)*sizeof(char));
  if ((image->pixels == (RunlengthPacket *) NULL) ||
      (image->comments == (char *) NULL))
    {
      Warning("unable to allocate image","memory allocation error");
      DestroyImage(image);
      return((Image *) NULL);
    }
  (void) sprintf(image->comments,"\n  Imported from text file:  %s\n",
    image->filename);
  /*
    Create colormap.
  */
  image->colors=2;
  image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
  if (image->colormap == (ColorPacket *) NULL)
    {
      Warning("unable to read image","memory allocation failed");
      DestroyImage(image);
      return((Image *) NULL);
    }
  image->colormap[0].red=pixel_info.background_color.red >> 8;
  image->colormap[0].green=pixel_info.background_color.green >> 8;
  image->colormap[0].blue=pixel_info.background_color.blue >> 8;
  image->colormap[1].red=pixel_info.foreground_color.red >> 8;
  image->colormap[1].green=pixel_info.foreground_color.green >> 8;
  image->colormap[1].blue=pixel_info.foreground_color.blue >> 8;
  /*
    Initialize text image to background color.
  */
  background_color.red=image->colormap[0].red;
  background_color.green=image->colormap[0].green;
  background_color.blue=image->colormap[0].blue;
  background_color.index=0;
  background_color.length=0;
  p=image->pixels;
  for (i=0; i < image->packets; i++)
    *p++=background_color;
  /*
    Annotate the text image.
  */
  XGetAnnotateInfo(&annotate_info);
  annotate_info.font_info=font_info;
  annotate_info.text=(char *)
    malloc((image->columns/Max(font_info->min_bounds.width,1)+2)*sizeof(char));
  if (annotate_info.text == (char *) NULL)
    {
      Warning("unable to read image","memory allocation failed");
      DestroyImage(image);
      return((Image *) NULL);
    }
  image->colormap[0].red=pixel_info.background_color.red >> 8;
  annotate_info.height=font_info->ascent+font_info->descent;
  x=0;
  y=0;
  text[sizeof(text)-1]='\0';
  text_status=fgets(text,sizeof(text)-1,image->file);
  if ((int) strlen(text) > 0)
    text[strlen(text)-1]='\0';
  while (text_status != (char *) NULL)
  {
    *annotate_info.text='\0';
    if (*text != '\0')
      {
        /*
          Compute width of text.
        */
        (void) strcpy(annotate_info.text,text);
        annotate_info.width=
          XTextWidth(font_info,annotate_info.text,strlen(annotate_info.text));
        if ((annotate_info.width+4) >= image->columns)
          {
            /*
              Reduce text until width is within bounds.
            */
            i=strlen(annotate_info.text);
            for (; (annotate_info.width+4) >= image->columns; i--)
              annotate_info.width=XTextWidth(font_info,annotate_info.text,
                (unsigned int) i);
            annotate_info.text[i]='\0';
            while ((i > 0) && !isspace(annotate_info.text[i]))
              i--;
            if (i > 0)
              annotate_info.text[i]='\0';
            annotate_info.width=XTextWidth(font_info,annotate_info.text,
              strlen(annotate_info.text));
          }
        /*
          Annotate image with text.
        */
        (void) sprintf(annotate_info.geometry,"%ux%u%+d%+d",
          annotate_info.width,annotate_info.height,x+2,y+2);
        status=XAnnotateImage(display,&image_window,&annotate_info,False,image);
        if (status == 0)
          {
            Warning("unable to annotate image","memory allocation error");
            DestroyImage(image);
            return((Image *) NULL);
          }
      }
    /*
      Get next string.
    */
    if (strlen(text) != strlen(annotate_info.text))
      (void) strcpy(text,text+strlen(annotate_info.text)+1);
    else
      {
        text_status=fgets(text,sizeof(text)-1,image->file);
        if ((int) strlen(text) > 0)
          text[strlen(text)-1]='\0';
      }
    y+=annotate_info.height;
    if ((text_status != (char *) NULL) &&
        ((y+font_info->ascent+4) > image->rows))
      {
        /*
          Page is full-- allocate next image structure.
        */
        image->orphan=True;
        image->next=CopyImage(image,image->columns,image->rows,False);
        image->orphan=False;
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
        /*
          Initialize text image to background color.
        */
        p=image->pixels;
        for (i=0; i < image->packets; i++)
          *p++=background_color;
        y=0;
      }
  }
  /*
    Free resources.
  */
  (void) free((char *) annotate_info.text);
  XFreeFont(display,font_info);
  XFree((void *) visual_info);
  /*
    Force to runlength-encoded PseudoClass image.
  */
  while (image->previous != (Image *) NULL)
  {
    image->class=PseudoClass;
    image=image->previous;
  }
  image->class=PseudoClass;
  CloseImage(image);
  XCloseDisplay(display);
  return(image);
}

#ifdef HasTIFF
#include "tiff.h"
#include "tiffio.h"

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d T I F F I m a g e                                                  %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadTIFFImage reads a Tagged image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadTIFFImage routine is:
%
%      image=ReadTIFFImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadTIFFImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadTIFFImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    range;

  register int
    i,
    quantum,
    x,
    y;

  register RunlengthPacket
    *q;

  TIFF
    *tiff;

  unsigned int
    status;

  unsigned long
    height,
    width;

  unsigned short
    bits_per_sample,
    max_sample_value,
    min_sample_value,
    photometric,
    samples_per_pixel;

  /*
    Allocate image structure.
  */
  image=AllocateImage("TIFF");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open TIFF image tiff.
  */
  (void) strcpy(image->filename,image_info->filename);
  tiff=TIFFOpen(image->filename,"r");
  if (tiff == (TIFF *) NULL)
    {
      Warning("unable to open tiff image",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  do
  {
    if (image_info->verbose)
      TIFFPrintDirectory(tiff,stderr,False);
    /*
      Allocate memory for the image and pixel buffer.
    */
    TIFFGetField(tiff,TIFFTAG_IMAGEWIDTH,&width);
    TIFFGetField(tiff,TIFFTAG_IMAGELENGTH,&height);
    for (quantum=1; quantum <= 16; quantum<<=1)
    {
      image->columns=width/quantum;
      image->rows=height/quantum;
      image->packets=image->columns*image->rows;
      image->pixels=(RunlengthPacket *)
        malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
      if ((image->pixels != (RunlengthPacket *) NULL))
        break;
    }
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("unable to allocate memory",(char *) NULL);
        DestroyImages(image);
        TIFFClose(tiff);
        return((Image *) NULL);
      }
    (void) sprintf(image->comments,"\n  Imported from TIFF image %s.\n",
      image->filename);
    TIFFGetFieldDefaulted(tiff,TIFFTAG_BITSPERSAMPLE,&bits_per_sample);
    TIFFGetFieldDefaulted(tiff,TIFFTAG_MINSAMPLEVALUE,&min_sample_value);
    TIFFGetFieldDefaulted(tiff,TIFFTAG_MAXSAMPLEVALUE,&max_sample_value);
    TIFFGetFieldDefaulted(tiff,TIFFTAG_PHOTOMETRIC,&photometric);
    TIFFGetFieldDefaulted(tiff,TIFFTAG_SAMPLESPERPIXEL,&samples_per_pixel);
    range=max_sample_value-min_sample_value;
    if ((bits_per_sample > 8) || (samples_per_pixel > 1) || TIFFIsTiled(tiff))
      {
        register unsigned long
          *p,
          *pixels;

        /*
          Convert TIFF image to DirectClass MIFF image.
        */
        image->alpha=samples_per_pixel > 3;
        pixels=(unsigned long *)
          malloc(image->columns*image->rows*sizeof(unsigned long));
        if (pixels == (unsigned long *) NULL)
          {
            Warning("unable to allocate memory",(char *) NULL);
            DestroyImages(image);
            TIFFClose(tiff);
            return((Image *) NULL);
          }
        if (quantum > 1)
          Warning("not enough memory","cropping required");
        status=TIFFReadRGBAImage(tiff,image->columns,image->rows,pixels,0);
        if (status == False)
          {
            Warning("unable to read TIFF image",(char *) NULL);
            (void) free((char *) pixels);
            DestroyImages(image);
            TIFFClose(tiff);
            return((Image *) NULL);
          }
        /*
          Convert image to DirectClass runlength-encoded packets.
        */
        q=image->pixels;
        for (y=image->rows-1; y >= 0; y--)
        {
          p=pixels+y*image->columns;
          for (x=0; x < image->columns; x++)
          {
            q->red=TIFFGetR(*p);
            q->green=TIFFGetG(*p);
            q->blue=TIFFGetB(*p);
            q->index=(unsigned short) (image->alpha ? TIFFGetA(*p) : 0);
            q->length=0;
            p++;
            q++;
          }
        }
        (void) free((char *) pixels);
        if (samples_per_pixel == 1)
          QuantizeImage(image,(unsigned int) range,8,False,RGBColorspace,True);
      }
    else
      {
        unsigned char
          *p,
          *scanline;

        /*
          Convert TIFF image to PseudoClass MIFF image.
        */
        image->class=PseudoClass;
        image->colors=range+1;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        scanline=(unsigned char *) malloc(TIFFScanlineSize(tiff));
        if ((image->colormap == (ColorPacket *) NULL) ||
            (scanline == (unsigned char *) NULL))
          {
            Warning("unable to allocate memory",(char *) NULL);
            DestroyImages(image);
            TIFFClose(tiff);
            return((Image *) NULL);
          }
        /*
          Create colormap.
        */
        switch (photometric)
        {
          case PHOTOMETRIC_MINISBLACK:
          {
            for (i=0; i < image->colors; i++)
            {
              image->colormap[i].red=(MaxRGB*i)/range;
              image->colormap[i].green=(MaxRGB*i)/range;
              image->colormap[i].blue=(MaxRGB*i)/range;
            }
            break;
          }
          case PHOTOMETRIC_MINISWHITE:
          {
            for (i=0; i < image->colors; i++)
            {
              image->colormap[i].red=((range-i)*MaxRGB)/range;
              image->colormap[i].green=((range-i)*MaxRGB)/range;
              image->colormap[i].blue=((range-i)*MaxRGB)/range;
            }
            break;
          }
          case PHOTOMETRIC_PALETTE:
          {
            unsigned short
              *blue_colormap,
              *green_colormap,
              *red_colormap;

            TIFFGetField(tiff,TIFFTAG_COLORMAP,&red_colormap,&green_colormap,
              &blue_colormap);
            for (i=0; i < image->colors; i++)
            {
              image->colormap[i].red=((int) red_colormap[i]*MaxRGB)/65535;
              image->colormap[i].green=((int) green_colormap[i]*MaxRGB)/65535;
              image->colormap[i].blue=((int) blue_colormap[i]*MaxRGB)/65535;
            }
            break;
          }
          default:
            break;
        }
        /*
          Convert image to PseudoClass runlength-encoded packets.
        */
        if (quantum > 1)
          Warning("not enough memory","subsampling required");
        q=image->pixels;
        for (y=0; y < image->rows; y++)
        {
          for (i=0; i < quantum; i++)
            TIFFReadScanline(tiff,scanline,y*quantum+i,0);
          p=scanline;
          switch (photometric)
          {
            case PHOTOMETRIC_MINISBLACK:
            case PHOTOMETRIC_MINISWHITE:
            {
              switch (bits_per_sample)
              {
                case 1:
                {
                  register int
                    bit;

                  for (x=0; x < (image->columns-7); x+=8)
                  {
                    for (bit=7; bit >= 0; bit--)
                    {
                      q->index=((*p) & (0x01 << bit) ? 0x01 : 0x00);
                      q->length=0;
                      q++;
                    }
                    p+=quantum;
                  }
                  if ((image->columns % 8) != 0)
                    {
                      for (bit=7; bit >= (8-(image->columns % 8)); bit--)
                      {
                        q->index=((*p) & (0x01 << bit) ? 0x00 : 0x01);
                        q->length=0;
                        q++;
                      }
                      p+=quantum;
                    }
                  break;
                }
                case 2:
                {
                  for (x=0; x < (image->columns-3); x+=4)
                  {
                    q->index=(*p >> 6) & 0x3;
                    q->length=0;
                    q++;
                    q->index=(*p >> 4) & 0x3;
                    q->length=0;
                    q++;
                    q->index=(*p >> 2) & 0x3;
                    q->length=0;
                    q++;
                    q->index=(*p) & 0x3;
                    q->length=0;
                    q++;
                    p+=quantum;
                  }
                  if ((image->columns % 4) != 0)
                    {
                      for (i=3; i >= (4-(image->columns % 4)); i--)
                      {
                        q->index=(*p >> (i*2)) & 0x03;
                        q->length=0;
                        q++;
                      }
                      p++;
                    }
                  break;
                }
                case 4:
                {
                  for (x=0; x < (image->columns-1); x+=2)
                  {
                    q->index=(*p >> 4) & 0xf;
                    q->length=0;
                    q++;
                    q->index=(*p) & 0xf;
                    q->length=0;
                    q++;
                    p+=quantum;
                  }
                  if ((image->columns % 2) != 0)
                    {
                      q->index=(*p >> 4) & 0xf;
                      q->length=0;
                      q++;
                      p+=quantum;
                    }
                  break;
                }
                case 8:
                {
                  for (x=0; x < image->columns; x++)
                  {
                    q->index=(*p);
                    q->length=0;
                    q++;
                    p+=quantum;
                  }
                  break;
                }
                default:
                  break;
              }
              break;
            }
            case PHOTOMETRIC_PALETTE:
            {
              for (x=0; x < image->columns; x++)
              {
                q->index=(*p);
                q->length=0;
                q++;
                p+=quantum;
              }
              break;
            }
            default:
              break;
          }
        }
        (void) free((char *) scanline);
      }
    if (image->class == PseudoClass)
      {
        SyncImage(image);
        CompressColormap(image);
      }
    /*
      Proceed to next image.
    */
    status=TIFFReadDirectory(tiff);
    if (status == True)
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("TIFF");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while (status == True);
  TIFFClose(tiff);
  while (image->previous != (Image *) NULL)
    image=image->previous;
  return(image);
}
#else
static Image *ReadTIFFImage(image_info)
ImageInfo
  *image_info;
{
  Warning("TIFF library is not available",image_info->filename);
  return(ReadMIFFImage(image_info));
}
#endif

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%   R e a d V I C A R I m a g e                                               %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadVICARImage reads a VICAR image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadVICARImage routine is:
%
%      image=ReadVICARImage(image_info)
%
%  A description of each parameter follows:
%
%    o image: Function ReadVICARImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or if
%      the image cannot be read.
%
%    o filename: Specifies the name of the image to read.
%
%
*/
static Image *ReadVICARImage(image_info)
ImageInfo
  *image_info;
{
#define MaxKeywordLength  2048

  char
    keyword[MaxKeywordLength],
    value[MaxKeywordLength];

  Image
    *image;

  long
    count;

  register int
    c,
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *vicar_pixels;

  unsigned int
    header_length,
    status,
    value_expected;

  /*
    Allocate image structure.
  */
  image=AllocateImage("VICAR");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Decode image header.
  */
  c=fgetc(image->file);
  count=1;
  if (c == EOF)
    {
      DestroyImage(image);
      return((Image *) NULL);
    }
  header_length=0;
  while (isgraph(c) && ((image->columns*image->rows) == 0))
  {
    if (!isalnum(c))
      {
        c=fgetc(image->file);
        count++;
      }
    else
      {
        register char
          *p;

        /*
          Determine a keyword and its value.
        */
        p=keyword;
        do
        {
          if ((p-keyword) < (MaxKeywordLength-1))
            *p++=(char) c;
          c=fgetc(image->file);
          count++;
        } while (isalnum(c) || (c == '_'));
        *p='\0';
        value_expected=False;
        while (isspace(c) || (c == '='))
        {
          if (c == '=')
            value_expected=True;
          c=fgetc(image->file);
          count++;
        }
        if (value_expected == False)
          continue;
        p=value;
        while (isalnum(c))
        {
          if ((p-value) < (MaxKeywordLength-1))
            *p++=(char) c;
          c=fgetc(image->file);
          count++;
        }
        *p='\0';
        /*
          Assign a value to the specified keyword.
        */
        if (strcmp(keyword,"LABEL_RECORDS") == 0)
          header_length=(unsigned int) atoi(value);
        if (strcmp(keyword,"LBLSIZE") == 0)
          header_length=(unsigned int) atoi(value);
        if (strcmp(keyword,"RECORD_BYTES") == 0)
          image->columns=(unsigned int) atoi(value);
        if (strcmp(keyword,"NS") == 0)
          image->columns=(unsigned int) atoi(value);
        if (strcmp(keyword,"LINES") == 0)
          image->rows=(unsigned int) atoi(value);
        if (strcmp(keyword,"NL") == 0)
          image->rows=(unsigned int) atoi(value);
      }
    while (isspace(c))
    {
      c=fgetc(image->file);
      count++;
    }
  }
  /*
    Read the rest of the header.
  */
  while (count < header_length)
  {
    c=fgetc(image->file);
    count++;
  }
  /*
    Verify that required image information is defined.
  */
  if ((image->columns*image->rows) == 0)
    {
      Warning("incorrect image header in file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create linear colormap.
  */
  image->class=PseudoClass;
  image->colors=256;
  image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
  if (image->colormap == (ColorPacket *) NULL)
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  for (i=0; i < image->colors; i++)
  {
    image->colormap[i].red=(unsigned char) i;
    image->colormap[i].green=(unsigned char) i;
    image->colormap[i].blue=(unsigned char) i;
  }
  /*
    Create image.
  */
  image->packets=image->columns*image->rows;
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  image->comments=(char *)
    malloc((strlen(image->filename)+2048)*sizeof(char));
  vicar_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*sizeof(unsigned char));
  if ((image->pixels == (RunlengthPacket *) NULL) ||
      (image->comments == (char *) NULL) ||
      (vicar_pixels == (unsigned char *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  (void) sprintf(image->comments,"\n  Imported from VICAR image:  %s\n",
    image->filename);
  /*
    Convert VICAR pixels to runlength-encoded packets.
  */
  status=ReadData((char *) vicar_pixels,1,(int) image->packets,image->file);
  if (status == False)
    {
      Warning("insufficient image data in file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert VICAR pixels to runlength-encoded packets.
  */
  p=vicar_pixels;
  q=image->pixels;
  for (i=0; i < image->packets; i++)
  {
    q->red=(*p);
    q->green=(*p);
    q->blue=(*p);
    q->index=(unsigned short) *p;
    q->length=0;
    p++;
    q++;
  }
  (void) free((char *) vicar_pixels);
  CompressColormap(image);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%   R e a d V I F F I m a g e                                                 %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadVIFFImage reads a Khoros Visualization image file and returns
%  it.  It allocates the memory necessary for the new Image structure and
%  returns a pointer to the new image.
%
%  The format of the ReadVIFFImage routine is:
%
%      image=ReadVIFFImage(image_info)
%
%  A description of each parameter follows:
%
%    o image: Function ReadVIFFImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or if
%      the image cannot be read.
%
%    o filename: Specifies the name of the image to read.
%
%
*/
static Image *ReadVIFFImage(image_info)
ImageInfo
  *image_info;
{
#define VFF_CM_genericRGB  15
#define VFF_CM_ntscRGB  1
#define VFF_CM_NONE  0
#define VFF_DEP_DECORDER  0x4
#define VFF_DEP_NSORDER  0x8
#define VFF_DES_RAW  0
#define VFF_LOC_IMPLICIT  1
#define VFF_MAPTYP_NONE  0
#define VFF_MAPTYP_1_BYTE  1
#define VFF_MS_NONE  0
#define VFF_MS_ONEPERBAND  1
#define VFF_MS_SHARED  3
#define VFF_TYP_BIT  0
#define VFF_TYP_1_BYTE  1

  typedef struct _ViffHeader
  {
    unsigned char
      identifier,
      file_type,
      release,
      version,
      machine_dependency,
      reserve[3],
      comment[512];

    unsigned long
      rows,
      columns,
      subrows;

    long
      x_offset,
      y_offset;

    float
      x_pixel_size,
      y_pixel_size;

    unsigned long
      location_type,
      location_dimension,
      number_of_images,
      number_data_bands,
      data_storage_type,
      data_encode_scheme,
      map_scheme,
      map_storage_type,
      map_rows,
      map_columns,
      map_subrows,
      map_enable,
      maps_per_cycle,
      color_space_model;
  } ViffHeader;

  Image
    *image;

  register int
    bit,
    i,
    x,
    y;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    buffer[7],
    *viff_pixels;

  unsigned int
    status;

  unsigned long
    packets;

  ViffHeader
    viff_header;

  /*
    Allocate image structure.
  */
  image=AllocateImage("VIFF");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read VIFF header (1024 bytes).
  */
  status=ReadData((char *) &viff_header.identifier,1,1,image->file);
  do
  {
    /*
      Verify VIFF identifier.
    */
    if ((status == False) || ((unsigned char) viff_header.identifier != 0xab))
      {
        Warning("not a VIFF raster,",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Initialize VIFF image.
    */
    (void) ReadData((char *) buffer,1,7,image->file);
    viff_header.file_type=buffer[0];
    viff_header.release=buffer[1];
    viff_header.version=buffer[2];
    viff_header.machine_dependency=buffer[3];
    (void) ReadData((char *) viff_header.comment,1,512,image->file);
    if ((viff_header.machine_dependency == VFF_DEP_DECORDER) ||
        (viff_header.machine_dependency == VFF_DEP_NSORDER))
      {
        viff_header.rows=LSBFirstReadLong(image->file);
        viff_header.columns=LSBFirstReadLong(image->file);
        viff_header.subrows=LSBFirstReadLong(image->file);
        viff_header.x_offset=LSBFirstReadLong(image->file);
        viff_header.y_offset=LSBFirstReadLong(image->file);
        viff_header.x_pixel_size=(float) LSBFirstReadLong(image->file);
        viff_header.y_pixel_size=(float) LSBFirstReadLong(image->file);
        viff_header.location_type=LSBFirstReadLong(image->file);
        viff_header.location_dimension=LSBFirstReadLong(image->file);
        viff_header.number_of_images=LSBFirstReadLong(image->file);
        viff_header.number_data_bands=LSBFirstReadLong(image->file);
        viff_header.data_storage_type=LSBFirstReadLong(image->file);
        viff_header.data_encode_scheme=LSBFirstReadLong(image->file);
        viff_header.map_scheme=LSBFirstReadLong(image->file);
        viff_header.map_storage_type=LSBFirstReadLong(image->file);
        viff_header.map_rows=LSBFirstReadLong(image->file);
        viff_header.map_columns=LSBFirstReadLong(image->file);
        viff_header.map_subrows=LSBFirstReadLong(image->file);
        viff_header.map_enable=LSBFirstReadLong(image->file);
        viff_header.maps_per_cycle=LSBFirstReadLong(image->file);
        viff_header.color_space_model=LSBFirstReadLong(image->file);
      }
    else
      {
        viff_header.rows=MSBFirstReadLong(image->file);
        viff_header.columns=MSBFirstReadLong(image->file);
        viff_header.subrows=MSBFirstReadLong(image->file);
        viff_header.x_offset=MSBFirstReadLong(image->file);
        viff_header.y_offset=MSBFirstReadLong(image->file);
        viff_header.x_pixel_size=(float) MSBFirstReadLong(image->file);
        viff_header.y_pixel_size=(float) MSBFirstReadLong(image->file);
        viff_header.location_type=MSBFirstReadLong(image->file);
        viff_header.location_dimension=MSBFirstReadLong(image->file);
        viff_header.number_of_images=MSBFirstReadLong(image->file);
        viff_header.number_data_bands=MSBFirstReadLong(image->file);
        viff_header.data_storage_type=MSBFirstReadLong(image->file);
        viff_header.data_encode_scheme=MSBFirstReadLong(image->file);
        viff_header.map_scheme=MSBFirstReadLong(image->file);
        viff_header.map_storage_type=MSBFirstReadLong(image->file);
        viff_header.map_rows=MSBFirstReadLong(image->file);
        viff_header.map_columns=MSBFirstReadLong(image->file);
        viff_header.map_subrows=MSBFirstReadLong(image->file);
        viff_header.map_enable=MSBFirstReadLong(image->file);
        viff_header.maps_per_cycle=MSBFirstReadLong(image->file);
        viff_header.color_space_model=MSBFirstReadLong(image->file);
      }
    for (i=0; i < 420; i++)
      (void) fgetc(image->file);
    /*
      Verify that we can read this VIFF image.
    */
    if ((viff_header.columns*viff_header.rows) == 0)
      {
        Warning("image column or row size is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if ((viff_header.data_storage_type != VFF_TYP_BIT) &&
        (viff_header.data_storage_type != VFF_TYP_1_BYTE))
      {
        Warning("data storage type is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (viff_header.data_encode_scheme != VFF_DES_RAW)
      {
        Warning("data encoding scheme is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if ((viff_header.map_storage_type != VFF_MAPTYP_NONE) &&
        (viff_header.map_storage_type != VFF_MAPTYP_1_BYTE))
      {
        Warning("map storage type is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if ((viff_header.color_space_model != VFF_CM_NONE) &&
        (viff_header.color_space_model != VFF_CM_ntscRGB) &&
        (viff_header.color_space_model != VFF_CM_genericRGB))
      {
        Warning("color space model is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (viff_header.location_type != VFF_LOC_IMPLICIT)
      {
        Warning("location type is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    if (viff_header.number_of_images != 1)
      {
        Warning("number of images is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    switch (viff_header.map_scheme)
    {
      case VFF_MS_NONE:
      {
        if (viff_header.number_data_bands < 3)
          {
            /*
              Create linear color ramp.
            */
            if (viff_header.data_storage_type == VFF_TYP_BIT)
              image->colors=2;
            else
              image->colors=1 << (viff_header.number_data_bands*8);
            image->colormap=(ColorPacket *)
              malloc(image->colors*sizeof(ColorPacket));
            if (image->colormap == (ColorPacket *) NULL)
              {
                Warning("memory allocation error",(char *) NULL);
                return((Image *) NULL);
              }
            for (i=0; i < image->colors; i++)
            {
              image->colormap[i].red=(255*i)/(image->colors-1);
              image->colormap[i].green=(255*i)/(image->colors-1);
              image->colormap[i].blue=(255*i)/(image->colors-1);
            }
          }
        break;
      }
      case VFF_MS_ONEPERBAND:
      case VFF_MS_SHARED:
      {
        unsigned char
          *viff_colormap;

        /*
          Read VIFF raster colormap.
        */
        image->colors=viff_header.map_columns;
        image->colormap=(ColorPacket *)
          malloc(image->colors*sizeof(ColorPacket));
        viff_colormap=(unsigned char *)
          malloc(image->colors*sizeof(unsigned char));
        if ((image->colormap == (ColorPacket *) NULL) ||
            (viff_colormap == (unsigned char *) NULL))
          {
            Warning("memory allocation error",(char *) NULL);
            DestroyImages(image);
            return((Image *) NULL);
          }
        (void) ReadData((char *) viff_colormap,1,(int) image->colors,
          image->file);
        for (i=0; i < image->colors; i++)
        {
          image->colormap[i].red=viff_colormap[i];
          image->colormap[i].green=viff_colormap[i];
          image->colormap[i].blue=viff_colormap[i];
        }
        if (viff_header.map_rows > 1)
          {
            (void) ReadData((char *) viff_colormap,1,(int) image->colors,
              image->file);
            for (i=0; i < image->colors; i++)
              image->colormap[i].green=viff_colormap[i];
          }
        if (viff_header.map_rows > 2)
          {
            (void) ReadData((char *) viff_colormap,1,(int) image->colors,
              image->file);
            for (i=0; i < image->colors; i++)
              image->colormap[i].blue=viff_colormap[i];
          }
        (void) free((char *) viff_colormap);
        break;
      }
      default:
      {
        Warning("colormap type is not supported",image->filename);
        DestroyImages(image);
        return((Image *) NULL);
      }
    }
    /*
      Allocate VIFF pixels.
    */
    if (viff_header.data_storage_type == VFF_TYP_BIT)
      packets=((viff_header.columns+7) >> 3)*viff_header.rows;
    else
      packets=
        viff_header.columns*viff_header.rows*viff_header.number_data_bands;
    viff_pixels=(unsigned char *) malloc(packets*sizeof(unsigned char));
    if (viff_pixels == (unsigned char *) NULL)
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    (void) ReadData((char *) viff_pixels,1,(int) packets,image->file);
    /*
      Create image.
    */
    image->alpha=(viff_header.number_data_bands == 4);
    image->class=
      (viff_header.number_data_bands < 3 ? PseudoClass : DirectClass);
    image->columns=viff_header.rows;
    image->rows=viff_header.columns;
    image->packets=image->columns*image->rows;
    image->pixels=(RunlengthPacket *)
      malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
    image->comments=(char *)
      malloc((strlen(image->filename)+2048)*sizeof(char));
    (void) sprintf(image->comments,
      "\n  Imported from VIFF raster image:  %s\n",image->filename);
    if ((image->pixels == (RunlengthPacket *) NULL) ||
        (image->comments == (char *) NULL))
      {
        Warning("memory allocation error",(char *) NULL);
        DestroyImages(image);
        return((Image *) NULL);
      }
    /*
      Convert VIFF raster image to runlength-encoded packets.
    */
    p=viff_pixels;
    q=image->pixels;
    if (viff_header.data_storage_type == VFF_TYP_BIT)
      {
        unsigned int
          polarity;

        /*
          Convert bitmap scanline to runlength-encoded color packets.
        */
        polarity=(viff_header.machine_dependency == VFF_DEP_DECORDER) ||
          (viff_header.machine_dependency == VFF_DEP_NSORDER);
        for (y=0; y < image->rows; y++)
        {
          /*
            Convert bitmap scanline to runlength-encoded color packets.
          */
          for (x=0; x < (image->columns >> 3); x++)
          {
            for (bit=0; bit < 8; bit++)
            {
              q->index=((*p) & (0x01 << bit) ? polarity : !polarity);
              q->length=0;
              q++;
            }
            p++;
          }
          if ((image->columns % 8) != 0)
            {
              for (bit=0; bit < (image->columns % 8); bit++)
              {
                q->index=((*p) & (0x01 << bit) ? polarity : !polarity);
                q->length=0;
                q++;
              }
              p++;
            }
        }
      }
    else
      if (image->class == PseudoClass)
        for (y=0; y < image->rows; y++)
        {
          /*
            Convert PseudoColor scanline to runlength-encoded color packets.
          */
          for (x=0; x < image->columns; x++)
          {
            q->index=(*p++);
            q->length=0;
            q++;
          }
        }
      else
        {
          unsigned long
            offset;

          /*
            Convert DirectColor scanline to runlength-encoded color packets.
          */
          offset=image->columns*image->rows;
          for (y=0; y < image->rows; y++)
          {
            for (x=0; x < image->columns; x++)
            {
              q->red=(*p);
              q->green=(*(p+offset));
              q->blue=(*(p+offset*2));
              if (image->colors != 0)
                {
                  q->red=image->colormap[q->red].red;
                  q->green=image->colormap[q->green].green;
                  q->blue=image->colormap[q->blue].blue;
                }
              q->index=(unsigned short) (image->alpha ? (*(p+offset*3)) : 0);
              q->length=0;
              p++;
              q++;
            }
          }
        }
    (void) free((char *) viff_pixels);
    if (image->class == PseudoClass)
      {
        SyncImage(image);
        CompressColormap(image);
      }
    /*
      Proceed to next image.
    */
    status=ReadData((char *) &viff_header.identifier,1,1,image->file);
    if ((status == True) && (viff_header.identifier == 0xab))
      {
        /*
          Allocate image structure.
        */
        image->next=AllocateImage("VIFF");
        if (image->next == (Image *) NULL)
          {
            DestroyImages(image);
            return((Image *) NULL);
          }
        image->next->file=image->file;
        (void) sprintf(image->next->filename,"%s.%u",image_info->filename,
          image->scene+1);
        image->next->scene=image->scene+1;
        image->next->previous=image;
        image=image->next;
      }
  } while ((status == True) && (viff_header.identifier == 0xab));
  while (image->previous != (Image *) NULL)
    image=image->previous;
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d X B M I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadXBMImage reads an X11 bitmap image file and returns it.  It
%  allocates the memory necessary for the new Image structure and returns a
%  pointer to the new image.
%
%  The format of the ReadXBMImage routine is:
%
%      image=ReadXBMImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadXBMImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadXBMImage(image_info)
ImageInfo
  *image_info;
{
  char
    data[2048];

  Image
    *image;

  register int
    x,
    y;

  register RunlengthPacket
    *q;

  register unsigned char
    bit;

  register unsigned short
    index;

  unsigned int
    byte;

  /*
    Allocate image structure.
  */
  image=AllocateImage("XBM");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Read X bitmap header.
  */
  while (fgets(data,sizeof(data)-1,image->file) != (char *) NULL)
    if (sscanf(data,"#define %*32s %u",&image->columns) == 1)
      break;
  while (fgets(data,sizeof(data)-1,image->file) != (char *) NULL)
    if (sscanf(data,"#define %*32s %u",&image->rows) == 1)
      break;
  if ((image->columns == 0) || (image->rows == 0))
    {
      Warning("XBM file is not in the correct format",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  while (fgets(data,sizeof(data)-1,image->file) != (char *) NULL)
    if (sscanf(data,"%*[^#] char"))
      break;
  if (feof(image->file))
    {
      Warning("XBM file is not in the correct format",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create image.
  */
  image->packets=image->columns*image->rows;
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  if (image->pixels == (RunlengthPacket *) NULL)
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create colormap.
  */
  image->class=PseudoClass;
  image->colors=2;
  image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
  if (image->colormap == (ColorPacket *) NULL)
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  image->colormap[0].red=0;
  image->colormap[0].green=0;
  image->colormap[0].blue=0;
  image->colormap[1].red=255;
  image->colormap[1].green=255;
  image->colormap[1].blue=255;
  /*
    Initial image comment.
  */
  image->comments=(char *) malloc((strlen(image->filename)+2048)*sizeof(char));
  if (image->comments == (char *) NULL)
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  (void) sprintf(image->comments,"\n  Imported from X11 bitmap file:  %s\n",
    image->filename);
  /*
    Convert X bitmap image to runlength-encoded packets.
  */
  q=image->pixels;
  for (y=0; y < image->rows; y++)
  {
    bit=0;
    for (x=0; x < image->columns; x++)
    {
      if (bit == 0)
        (void) fscanf(image->file,"%i,",&byte);
      index=(byte & 0x01) ? 0 : 1;
      q->red=image->colormap[index].red;
      q->green=image->colormap[index].green;
      q->blue=image->colormap[index].blue;
      q->index=index;
      q->length=0;
      q++;
      bit++;
      byte>>=1;
      if (bit == 8)
        bit=0;
    }
  }
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d X C I m a g e                                                      %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadXCImage creates a constant image and initializes to the
%  background color of the X server and returns it.  It allocates the memory
%  necessary for the new Image structure and returns a pointer to the new
%  image.
%
%  The format of the ReadXCImage routine is:
%
%      image=ReadXCImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadXCImage returns a pointer to the image after
%      creating it. A null image is returned if there is a a memory shortage
%      or if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadXCImage(image_info)
ImageInfo
  *image_info;
{
  char
    *resource_value;

  Display
    *display;

  Image
    *image;

  int
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  unsigned int
    height,
    width;

  XPixelInfo
    pixel_info;

  XResourceInfo
    resource_info;

  XrmDatabase
    resource_database,
    server_database;

  XStandardColormap
    map_info;

  XVisualInfo
    *visual_info;

  /*
    Allocate image structure.
  */
  image=AllocateImage("XC");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  (void) strcpy(image->filename,image_info->filename);
  /*
    Open X server connection.
  */
  display=XOpenDisplay(image_info->server_name);
  if (display == (Display *) NULL)
    {
      Warning("unable to connect to X server",
        XDisplayName(image_info->server_name));
      return((Image *) NULL);
    }
  /*
    Set our forgiving error handler.
  */
  XSetErrorHandler(XError);
  /*
    Initialize resource database.
  */
  XrmInitialize();
  resource_database=XrmGetDatabase(display);
  resource_value=XResourceManagerString(display);
  if (resource_value == (char *) NULL)
    resource_value="";
  server_database=XrmGetStringDatabase(resource_value);
  XrmMergeDatabases(server_database,&resource_database);
  /*
    Get user defaults from X resource database.
  */
  XGetResourceInfo(resource_database,client_name,&resource_info);
  if (image_info->border_color != (char *) NULL)
    resource_info.border_color=image_info->border_color;
  /*
    Initialize visual info.
  */
  visual_info=XBestVisualInfo(display,"default",(char *) NULL,
    (XStandardColormap *) NULL);
  if (visual_info == (XVisualInfo *) NULL)
    {
      Warning("unable to get visual",resource_info.visual_type);
      return((Image *) NULL);
    }
  /*
    Determine border color.
  */
  map_info.colormap=XDefaultColormap(display,visual_info->screen);
  XGetPixelInfo(display,visual_info,&map_info,&resource_info,(Image *) NULL,
    &pixel_info);
  /*
    Initialize Image structure.
  */
  width=512;
  height=512;
  if (image_info->geometry != (char *) NULL)
    (void) XParseGeometry(image_info->geometry,&x,&y,&width,&height);
  image->columns=width;
  image->rows=height;
  image->packets=image->columns*image->rows;
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  image->comments=(char *) malloc((strlen(image->filename)+2048)*sizeof(char));
  if ((image->pixels == (RunlengthPacket *) NULL) ||
      (image->comments == (char *) NULL))
    {
      Warning("unable to allocate image","memory allocation error");
      DestroyImage(image);
      return((Image *) NULL);
    }
  (void) sprintf(image->comments,"\n  Imported from constant file:  %s\n",
    image->filename);
  /*
    Create colormap.
  */
  image->colors=1;
  image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
  if (image->colormap == (ColorPacket *) NULL)
    {
      Warning("unable to create image","memory allocation failed");
      DestroyImage(image);
      return((Image *) NULL);
    }
  image->colormap[0].red=pixel_info.border_color.red >> 8;
  image->colormap[0].green=pixel_info.border_color.green >> 8;
  image->colormap[0].blue=pixel_info.border_color.blue >> 8;
  q=image->pixels;
  for (i=0; i < (image->columns*image->rows); i++)
  {
    q->red=image->colormap[0].red;
    q->green=image->colormap[0].green;
    q->blue=image->colormap[0].blue;
    q->index=0;
    q->length=0;
    q++;
  }
  /*
    Free resources.
  */
  XFree((void *) visual_info);
  XCloseDisplay(display);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d X W D I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadXWDImage reads an X Window System window dump image file and
%  returns it.  It allocates the memory necessary for the new Image structure
%  and returns a pointer to the new image.
%
%  The format of the ReadXWDImage routine is:
%
%      image=ReadXWDImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadXWDImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadXWDImage(image_info)
ImageInfo
  *image_info;
{
  char
    *window_name;

  Display
    display;

  Image
    *image;

  int
    status,
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned short
    index;

  register unsigned long
    pixel;

  unsigned long
    lsb_first,
    packets;

  ScreenFormat
    screen_format;

  XColor
    *colors;

  XImage
    *ximage;

  XWDFileHeader
    header;

  /*
    Allocate image structure.
  */
  image=AllocateImage("XWD");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
     Read in header information.
  */
  status=ReadData((char *) &header,sizeof(header),1,image->file);
  if (status == False)
    {
      Warning("Unable to read dump file header",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Ensure the header byte-order is most-significant byte first.
  */
  lsb_first=1;
  if (*(char *) &lsb_first)
    MSBFirstOrderLong((char *) &header,sizeof(header));
  /*
    Check to see if the dump file is in the proper format.
  */
  if (header.file_version != XWD_FILE_VERSION)
    {
      Warning("XWD file format version mismatch",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  if (header.header_size < sizeof(header))
    {
      Warning("XWD header size is too small",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  packets=(header.header_size-sizeof(header));
  window_name=(char *) malloc((unsigned int) packets*sizeof(char));
  if (window_name == (char *) NULL)
    {
      Warning("unable to allocate memory",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  status=ReadData((char *) window_name,1,(int) packets,image->file);
  if (status == False)
    {
      Warning("unable to read window name from dump file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Initialize the X image.
  */
  display.byte_order=header.byte_order;
  display.bitmap_unit=header.bitmap_unit;
  display.bitmap_bit_order=header.bitmap_bit_order;
  display.pixmap_format=(&screen_format);
  display.nformats=1;
  screen_format.depth=header.pixmap_depth;
  screen_format.bits_per_pixel=(int) header.bits_per_pixel;
  ximage=XCreateImage(&display,(Visual *) NULL,
    (unsigned int) header.pixmap_depth,(int) header.pixmap_format,
    (int) header.xoffset,(char *) NULL,(unsigned int) header.pixmap_width,
    (unsigned int) header.pixmap_height,(int) header.bitmap_pad,
    (int) header.bytes_per_line);
  ximage->red_mask=header.red_mask;
  ximage->green_mask=header.green_mask;
  ximage->blue_mask=header.blue_mask;
  /*
    Read colormap.
  */
  colors=(XColor *) NULL;
  if (header.ncolors != 0)
    {
      colors=(XColor *) malloc((unsigned int) header.ncolors*sizeof(XColor));
      if (colors == (XColor *) NULL)
        {
          Warning("unable to allocate memory",(char *) NULL);
          DestroyImage(image);
          return((Image *) NULL);
        }
      status=ReadData((char *) colors,sizeof(XColor),(int) header.ncolors,
        image->file);
      if (status == False)
        {
          Warning("unable to read color map from dump file",image->filename);
          DestroyImage(image);
          return((Image *) NULL);
        }
      /*
        Ensure the header byte-order is most-significant byte first.
      */
      lsb_first=1;
      if (*(char *) &lsb_first)
        for (i=0; i < header.ncolors; i++)
        {
          MSBFirstOrderLong((char *) &colors[i].pixel,sizeof(unsigned long));
          MSBFirstOrderShort((char *) &colors[i].red,3*sizeof(unsigned short));
        }
    }
  /*
    Allocate the pixel buffer.
  */
  if (ximage->format == ZPixmap)
    packets=ximage->bytes_per_line*ximage->height;
  else
    packets=ximage->bytes_per_line*ximage->height*ximage->depth;
  ximage->data=(char *) malloc(packets*sizeof(unsigned char));
  if (ximage->data == (char *) NULL)
    {
      Warning("unable to allocate memory",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  status=ReadData(ximage->data,1,(int) packets,image->file);
  if (status == False)
    {
      Warning("unable to read dump pixmap",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert image to MIFF format.
  */
  image->columns=ximage->width;
  image->rows=ximage->height;
  /*
    Initial image comment.
  */
  if ((ximage->red_mask > 0) || (ximage->green_mask > 0) ||
      (ximage->blue_mask > 0))
    image->class=DirectClass;
  else
    image->class=PseudoClass;
  image->colors=header.ncolors;
  image->packets=image->columns*image->rows;
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  image->comments=(char *)
    malloc((strlen(image->filename)+2048)*sizeof(char));
  if ((image->pixels == (RunlengthPacket *) NULL) ||
      (image->comments == (char *) NULL))
    {
      Warning("unable to allocate memory",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  (void) sprintf(image->comments,"\n  Imported from X11 dump file:  %s\n",
    image->filename);
  q=image->pixels;
  switch (image->class)
  {
    case DirectClass:
    {
      register unsigned long
        color;

      unsigned long
        blue_mask,
        blue_shift,
        green_mask,
        green_shift,
        red_mask,
        red_shift;

      /*
        Determine shift and mask for red, green, and blue.
      */
      red_mask=ximage->red_mask;
      red_shift=0;
      while ((red_mask & 0x01) == 0)
      {
        red_mask>>=1;
        red_shift++;
      }
      green_mask=ximage->green_mask;
      green_shift=0;
      while ((green_mask & 0x01) == 0)
      {
        green_mask>>=1;
        green_shift++;
      }
      blue_mask=ximage->blue_mask;
      blue_shift=0;
      while ((blue_mask & 0x01) == 0)
      {
        blue_mask>>=1;
        blue_shift++;
      }
      /*
        Convert X image to DirectClass packets.
      */
      if (image->colors != 0)
        for (y=0; y < image->rows; y++)
        {
          for (x=0; x < image->columns; x++)
          {
            pixel=XGetPixel(ximage,x,y);
            index=(unsigned short) ((pixel >> red_shift) & red_mask);
            q->red=(unsigned char) (colors[index].red >> 8);
            index=(unsigned short) ((pixel >> green_shift) & green_mask);
            q->green=(unsigned char) (colors[index].green >> 8);
            index=(unsigned short) ((pixel >> blue_shift) & blue_mask);
            q->blue=(unsigned char) (colors[index].blue >> 8);
            q->index=0;
            q->length=0;
            q++;
          }
        }
      else
        for (y=0; y < image->rows; y++)
          for (x=0; x < image->columns; x++)
          {
            pixel=XGetPixel(ximage,x,y);
            color=(pixel >> red_shift) & red_mask;
            q->red=(unsigned char)
              ((((unsigned long) color*65535)/red_mask) >> 8);
            color=(pixel >> green_shift) & green_mask;
            q->green=(unsigned char)
              ((((unsigned long) color*65535)/green_mask) >> 8);
            color=(pixel >> blue_shift) & blue_mask;
            q->blue=(unsigned char)
              ((((unsigned long) color*65535)/blue_mask) >> 8);
            q->index=0;
            q->length=0;
            q++;
          }
      break;
    }
    case PseudoClass:
    {
      /*
        Convert X image to PseudoClass packets.
      */
      image->colormap=(ColorPacket *) malloc(image->colors*sizeof(ColorPacket));
      if (image->colormap == (ColorPacket *) NULL)
        {
          Warning("unable to allocate memory",(char *) NULL);
          DestroyImage(image);
          return((Image *) NULL);
        }
      for (i=0; i < image->colors; i++)
      {
        image->colormap[i].red=colors[i].red >> 8;
        image->colormap[i].green=colors[i].green >> 8;
        image->colormap[i].blue=colors[i].blue >> 8;
      }
      for (y=0; y < image->rows; y++)
        for (x=0; x < image->columns; x++)
        {
          pixel=XGetPixel(ximage,x,y);
          q->red=(unsigned char) (colors[pixel].red >> 8);
          q->green=(unsigned char) (colors[pixel].green >> 8);
          q->blue=(unsigned char) (colors[pixel].blue >> 8);
          q->index=(unsigned short) pixel;
          q->length=0;
          q++;
        }
      CompressColormap(image);
      break;
    }
  }
  /*
    Free image and colormap.
  */
  (void) free((char *) window_name);
  if (header.ncolors != 0)
    (void) free((char *) colors);
  XDestroyImage(ximage);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  R e a d Y U V I m a g e                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadYUVImage reads an image with raw Y, U, and V bytes and returns
%  it.  It allocates the memory necessary for the new Image structure and
%  returns a pointer to the new image.  U and V, normally -0.5 through 0.5,
%  are expected to be normalized to the range 0 through 255 fit withing a byte.
%
%  The format of the ReadYUVImage routine is:
%
%      image=ReadYUVImage(image_info)
%
%  A description of each parameter follows:
%
%    o image:  Function ReadYUVImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
static Image *ReadYUVImage(image_info)
ImageInfo
  *image_info;
{
  Image
    *image;

  int
    x,
    y;

  register int
    i;

  register RunlengthPacket
    *q;

  register unsigned char
    *p;

  unsigned char
    *yuv_pixels;

  unsigned int
    height,
    width;

  /*
    Allocate image structure.
  */
  image=AllocateImage("YUV");
  if (image == (Image *) NULL)
    return((Image *) NULL);
  /*
    Open image file.
  */
  (void) strcpy(image->filename,image_info->filename);
  OpenImage(image,"r");
  if (image->file == (FILE *) NULL)
    {
      Warning("unable to open file",image->filename);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Create image.
  */
  width=512;
  height=512;
  if (image_info->geometry != (char *) NULL)
    (void) XParseGeometry(image_info->geometry,&x,&y,&width,&height);
  image->columns=width;
  image->rows=height;
  image->packets=image->columns*image->rows;
  yuv_pixels=(unsigned char *)
    malloc((unsigned int) image->packets*3*sizeof(unsigned char));
  image->pixels=(RunlengthPacket *)
    malloc((unsigned int) image->packets*sizeof(RunlengthPacket));
  if ((yuv_pixels == (unsigned char *) NULL) ||
      (image->pixels == (RunlengthPacket *) NULL))
    {
      Warning("memory allocation error",(char *) NULL);
      DestroyImage(image);
      return((Image *) NULL);
    }
  /*
    Convert raster image to runlength-encoded packets.
  */
  (void) ReadData((char *) yuv_pixels,3,(int) (image->columns*image->rows),
    image->file);
  p=yuv_pixels;
  switch (image_info->interlace)
  {
    case NoneInterlace:
    default:
    {
      /*
        No interlacing:  YUVYUVYUVYUVYUVYUV...
      */
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->red=(*p++);
        q->green=(*p++);
        q->blue=(*p++);
        q->index=0;
        q->length=0;
        q++;
      }
      break;
    }
    case LineInterlace:
    {
      /*
        Line interlacing:  YYY...UUU...VVV...YYY...UUU...VVV...
      */
      for (y=0; y < image->rows; y++)
      {
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->red=(*p++);
          q->index=0;
          q->length=0;
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->green=(*p++);
          q++;
        }
        q=image->pixels+y*image->columns;
        for (x=0; x < image->columns; x++)
        {
          q->blue=(*p++);
          q++;
        }
      }
      break;
    }
    case PlaneInterlace:
    {
      /*
        Plane interlacing:  YYYYYY...UUUUUU...VVVVVV...
      */
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->red=(*p++);
        q->index=0;
        q->length=0;
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->green=(*p++);
        q++;
      }
      q=image->pixels;
      for (i=0; i < (image->columns*image->rows); i++)
      {
        q->blue=(*p++);
        q++;
      }
      break;
    }
  }
  (void) free((char *) yuv_pixels);
  TransformRGBImage(image,YUVColorspace);
  CloseImage(image);
  return(image);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%   R e a d I m a g e                                                         %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Function ReadImage reads an image and returns it.  It allocates
%  the memory necessary for the new Image structure and returns a pointer to
%  the new image.  By default, the image format is determined by its magic
%  number. To specify a particular image format, precede the filename with an
%  explicit image format name and a colon (i.e.  ps:image) or as the filename
%  suffix  (i.e. image.ps).
%
%  The format of the ReadImage routine is:
%
%      image=ReadImage(image_info)
%
%  A description of each parameter follows:
%
%    o image: Function ReadImage returns a pointer to the image after
%      reading.  A null image is returned if there is a a memory shortage or
%      if the image cannot be read.
%
%    o image_info: Specifies a pointer to an ImageInfo structure.
%
%
*/
Image *ReadImage(image_info)
ImageInfo
  *image_info;
{
  static char
    *ImageTypes[]=
    {
      "ALPHA",
      "AVS",
      "BMP",
      "CMYK",
      "EPS",
      "FAX",
      "FITS",
      "GIF",
      "GRAY",
      "HISTOGRAM",
      "IRIS",
      "JPEG",
      "JPG",
      "MIFF",
      "MTV",
      "PBM",
      "PCX",
      "PGM",
      "PICT",
      "PPM",
      "PNM",
      "PS",
      "PS2",
      "RAS",
      "RGB",
      "RLE",
      "SUN",
      "TGA",
      "TEXT",
      "TIFF",
      "VICAR",
      "VIFF",
      "X",
      "XBM",
      "XC",
      "XV",
      "XWD",
      "YUV",
      (char *) NULL,
    };

  char
    magick[12],
    magic_number[12],
    *p;

  Image
    decode_image,
    *image;

  register char
    c,
    *q;

  register int
    i;

  unsigned int
    temporary_file;

  /*
    Look for explicit 'format:image' in filename.
  */
  *magick='\0';
  (void) strcpy(decode_image.filename,image_info->filename);
  p=decode_image.filename;
  while ((*p != ':') && (*p != '\0'))
    p++;
  if ((*p == ':') && ((p-decode_image.filename) < sizeof(magic_number)))
    {
      /*
        User specified image format.
      */
      (void) strncpy(magic_number,decode_image.filename,
        p-decode_image.filename);
      magic_number[p-decode_image.filename]='\0';
      for (q=magic_number; *q != '\0'; q++)
      {
        c=(*q);
        if (isascii(c) && islower(c))
          *q=toupper(c);
      }
      for (i=0; ImageTypes[i] != (char *) NULL; i++)
        if (strcmp(magic_number,ImageTypes[i]) == 0)
          {
            /*
              Strip off image format prefix.
            */
            p++;
            (void) strcpy(decode_image.filename,p);
            (void) strcpy(magick,magic_number);
            break;
          }
    }
  temporary_file=False;
  if (*magick == '\0')
    {
      /*
        Look for 'image.format' in filename.
      */
      (void) strcpy(magick,"MIFF");
      p=decode_image.filename+strlen(decode_image.filename)-1;
      while ((*p != '.') && (p > decode_image.filename))
        p--;
      if ((*p == '.') && (strlen(p) < sizeof(magic_number)))
        {
          /*
            File specified image format?
          */
          (void) strcpy(magic_number,p+1);
          for (q=magic_number; *q != '\0'; q++)
          {
            c=(*q);
            if (isascii(c) && islower(c))
              *q=toupper(c);
          }
          for (i=0; ImageTypes[i] != (char *) NULL; i++)
            if (strcmp(magic_number,ImageTypes[i]) == 0)
              {
                (void) strcpy(magick,magic_number);
                break;
              }
        }
      /*
        Determine type from image magic number.
      */
      temporary_file=(*decode_image.filename == '-');
      if (temporary_file)
        {
          char
            *directory;

          int
            c;

          /*
            Copy standard input to temporary file.
          */
          directory=(char *) getenv("TMPDIR");
          if (directory == (char *) NULL)
            directory="/tmp";
          (void) sprintf(decode_image.filename,"%s/magickXXXXXX",directory);
          (void) mktemp(decode_image.filename);
          decode_image.file=fopen(decode_image.filename,"w");
          if (decode_image.file == (FILE *) NULL)
            return((Image *) NULL);
          c=getchar();
          while (c != EOF)
          {
            (void) putc(c,decode_image.file);
            c=getchar();
          }
          (void) fclose(decode_image.file);
        }
      /*
        Open image file.
      */
      *magic_number='\0';
      OpenImage(&decode_image,"r");
      if (decode_image.file != (FILE *) NULL)
        {
          /*
            Read magic number.
          */
          (void) ReadData(magic_number,sizeof(char),sizeof(magic_number),
            decode_image.file);
          CloseImage(&decode_image);
        }
      /*
        Determine the image format.
      */
      if (strncmp(magic_number,"BM",2) == 0)
        (void) strcpy(magick,"BMP");
      if (strncmp(magic_number,"GIF8",4) == 0)
        (void) strcpy(magick,"GIF");
      if (strncmp(magic_number,"\001\332",2) == 0)
        (void) strcpy(magick,"IRIS");
      if (strncmp(magic_number,"\377\330\377",3) == 0)
        (void) strcpy(magick,"JPEG");
      else
        if ((strcmp(magick,"JPEG") == 0) || (strcmp(magick,"JPG") == 0))
          (void) strcpy(magick,"MIFF");
      if ((unsigned char) *magic_number == 0x0a)
        (void) strcpy(magick,"PCX");
      if ((*magic_number == 'P') && isdigit(magic_number[1]))
        (void) strcpy(magick,"PNM");
      if (strncmp(magic_number,"%!",2) == 0)
        (void) strcpy(magick,"PS");
      if (strncmp(magic_number,"\131\246\152\225",4) == 0)
        (void) strcpy(magick,"SUN");
      if ((strncmp(magic_number,"\115\115",2) == 0) ||
          (strncmp(magic_number,"\111\111",2) == 0))
        (void) strcpy(magick,"TIFF");
      if (strncmp(magic_number,"\122\314",2) == 0)
        (void) strcpy(magick,"RLE");
      if ((strncmp(magic_number,"LBLSIZE",7) == 0) ||
         (strncmp(magic_number,"NJPL1I",6) == 0))
        (void) strcpy(magick,"VICAR");
      if ((unsigned char) *magic_number == 0xab)
        (void) strcpy(magick,"VIFF");
      if (strncmp(magic_number,"#define",7) == 0)
        (void) strcpy(magick,"XBM");
      if ((magic_number[1] == 0x00) && (magic_number[2] == 0x00))
        if ((magic_number[5] == 0x00) && (magic_number[6] == 0x00))
          if ((magic_number[4] == 0x07) || (magic_number[7] == 0x07))
            (void) strcpy(magick,"XWD");
    }
  /*
    Call appropriate image reader based on image type.
  */
  (void) strcpy(image_info->filename,decode_image.filename);
  switch (*magick)
  {
    case 'A':
    {
      if (strcmp(magick,"ALPHA") == 0)
        image=ReadALPHAImage(image_info);
      else
        image=ReadAVSImage(image_info);
      break;
    }
    case 'B':
    {
      image=ReadBMPImage(image_info);
      break;
    }
    case 'C':
    {
      image=ReadCMYKImage(image_info);
      break;
    }
    case 'E':
    {
      image=ReadPSImage(image_info);
      break;
    }
    case 'F':
    {
      if (strcmp(magick,"FAX") == 0)
        image=ReadFAXImage(image_info);
      else
        image=ReadFITSImage(image_info);
      break;
    }
    case 'G':
    {
      if (strcmp(magick,"GIF") == 0)
        image=ReadGIFImage(image_info);
      else
        image=ReadGRAYImage(image_info);
      break;
    }
    case 'H':
    {
      image=ReadHISTOGRAMImage(image_info);
      break;
    }
    case 'I':
    {
      image=ReadIRISImage(image_info);
      break;
    }
    case 'J':
    {
      image=ReadJPEGImage(image_info);
      break;
    }
    case 'M':
    {
      if (strcmp(magick,"MIFF") == 0)
        image=ReadMIFFImage(image_info);
      else
        image=ReadMTVImage(image_info);
      break;
    }
    case 'P':
    {
      if (strcmp(magick,"PCX") == 0)
        image=ReadPCXImage(image_info);
      else
        if (strcmp(magick,"PICT") == 0)
          image=ReadPICTImage(image_info);
        else
          if ((strcmp(magick,"PS") == 0) || (strcmp(magick,"PS2") == 0))
            image=ReadPSImage(image_info);
          else
            image=ReadPNMImage(image_info);
      break;
    }
    case 'R':
    {
      if (strcmp(magick,"RAS") == 0)
        image=ReadSUNImage(image_info);
      else
        if (strcmp(magick,"RGB") == 0)
          image=ReadRGBImage(image_info);
        else
          image=ReadRLEImage(image_info);
      break;
    }
    case 'S':
    {
      image=ReadSUNImage(image_info);
      break;
    }
    case 'T':
    {
      if (strcmp(magick,"TGA") == 0)
        image=ReadTARGAImage(image_info);
      else
        if (strcmp(magick,"TIFF") == 0)
          image=ReadTIFFImage(image_info);
        else
          image=ReadTEXTImage(image_info);
      break;
    }
    case 'V':
    {
      if (strcmp(magick,"VICAR") == 0)
        image=ReadVICARImage(image_info);
      else
        image=ReadVIFFImage(image_info);
      break;
    }
    case 'X':
    {
      if (strcmp(magick,"X") == 0)
        image=ReadXImage(image_info->filename,image_info->server_name,False,
          False,False,True);
      else
        if (strcmp(magick,"XC") == 0)
          image=ReadXCImage(image_info);
        else
          if (strcmp(magick,"XBM") == 0)
            image=ReadXBMImage(image_info);
          else
            if (strcmp(magick,"XV") == 0)
              image=ReadVIFFImage(image_info);
            else
              image=ReadXWDImage(image_info);
      break;
    }
    case 'Y':
    {
      image=ReadYUVImage(image_info);
      break;
    }
    default:
      image=ReadMIFFImage(image_info);
  }
  if (temporary_file)
    (void) unlink(image_info->filename);
  if (image != (Image *) NULL)
    if (image->status)
      {
        Warning("an error has occurred reading from file",image->filename);
        return((Image *) NULL);
      }
  return(image);
}
