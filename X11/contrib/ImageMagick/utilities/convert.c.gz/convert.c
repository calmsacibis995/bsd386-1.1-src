/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%                CCCC   OOO   N   N  V   V  EEEEE  RRRR   TTTTT               %
%               C      O   O  NN  N  V   V  E      R   R    T                 %
%               C      O   O  N N N  V   V  EEE    RRRR     T                 %
%               C      O   O  N  NN   V V   E      R R      T                 %
%                CCCC   OOO   N   N    V    EEEEE  R  R     T                 %
%                                                                             %
%                                                                             %
%                 Convert a image from one format to another.                 %
%                                                                             %
%                                                                             %
%                                                                             %
%                              Software Design                                %
%                                John Cristy                                  %
%                                April 1992                                   %
%                                                                             %
%                                                                             %
%  Copyright 1993 E. I. Dupont de Nemours & Company                           %
%                                                                             %
%  Permission to use, copy, modify, distribute, and sell this software and    %
%  its documentation for any purpose is hereby granted without fee,           %
%  provided that the above Copyright notice appear in all copies and that     %
%  both that Copyright notice and this permission notice appear in            %
%  supporting documentation, and that the name of E. I. Dupont de Nemours     %
%  & Company not be used in advertising or publicity pertaining to            %
%  distribution of the software without specific, written prior               %
%  permission.  E. I. Dupont de Nemours & Company makes no representations    %
%  about the suitability of this software for any purpose.  It is provided    %
%  "as is" without express or implied warranty.                               %
%                                                                             %
%  E. I. Dupont de Nemours & Company disclaims all warranties with regard     %
%  to this software, including all implied warranties of merchantability      %
%  and fitness, in no event shall E. I. Dupont de Nemours & Company be        %
%  liable for any special, indirect or consequential damages or any           %
%  damages whatsoever resulting from loss of use, data or profits, whether    %
%  in an action of contract, negligence or other tortious action, arising     %
%  out of or in connection with the use or performance of this software.      %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Convert converts an input file using one image format to an output file
%  with a differing image format.
%
%  Convert recognizes the following image formats:
%
%    Tag   Description
%    ---------------------------------------------------
%    ALPHA Raw alpha bytes.
%    AVS   AVS X image file.
%    BMP   Microsoft Windows bitmap image file.
%    CMYK  Raw cyan, magenta, yellow, and black bytes.
%    EPS   Adobe Encapsulated PostScript file.
%    FAX   Group 3.
%    FITS  Flexible Image Transport System.
%    GIF   Compuserve Graphics image file.
%    GRAY  Raw gray bytes.
%    HISTOGRAM
%    IRIS  SGI RGB image file.
%    JPEG
%    MIFF  Machine Independant file format.
%    MTV
%    PCX       ZSoft IBM PC Paintbrush file
%    PICT  Apple Macintosh QuickDraw/PICT file.
%    PNM   Portable bitmap.
%    PS    Adobe PostScript file.
%    PS2   Adobe Level II PostScript file.
%    RGB   Raw red, green, and blue bytes.
%    RLE   Utah Run length encoded image file; read only.
%    SUN   SUN Rasterfile.
%    TEXT  raw text file; read only.
%    TGA   Truevision Targa image file.
%    TIFF  Tagged Image File Format.
%    VICAR read only.
%    VIFF  Khoros Visualization image file.
%    X     select image from X server screen.
%    XC    constant image of X server border color.
%    XBM   X11 bitmap file.
%    XWD   X Window System window dump image file.
%    YUV   Raw Y, U, and V bytes.  U and V, normally -0.5 through
%          0.5, are normalized to the range 0 through 255 to fit
%          within a byte.
%
%  The convert program syntax is:
%
%  Usage: convert [options ...] input_file output_file
%
%  Where options include:
%    -alpha              store alpha channel if the image has one
%    -colors value       preferred number of colors in the image
%    -clip geometry      preferred size and location of the clipped image
%    -colorspace type    GRAY, RGB, XYZ, YCbCr, YIQ, or YUV
%    -compress type      RunlengthEncoded or QEncoded
%    -density geometry   vertical and horizonal density of the image
%    -display server     obtain image or font from this X server
%    -dither             apply Floyd/Steinberg error diffusion to image
%    -font name          X11 font for displaying text
%    -geometry geometry  width and height of the image
%    -interlace type     NONE, LINE, or PLANE
%    -monochrome         transform image to black and white
%    -page geometry      size and location of the Postscript page
%    -quality value      JPEG quality setting
%    -scale geometry     preferred size factors of the image
%    -scene value        image scene number
%    -treedepth value    depth of the color classification tree
%    -verbose            print detailed information about the image
%
%  Change '-' to '+' in any option above to reverse its effect.  For
%  example,  specify +alpha to store the image without its alpha channel.
%
%  By default, the image format of `file' is determined by its magic
%  number.  To specify a particular image format, precede the filename
%  with an image format name and a colon (i.e. ps:image) or specify the
%  image type as the filename suffix (i.e. image.ps).  Specify 'file' as
%  '-' for standard input or output.
%
%
*/

#include "display.h"
#include "image.h"
#include "X.h"

/*
  Global declarations.
*/
char
  *client_name;

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%   U s a g e                                                                 %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Procedure Usage displays the program usage;
%
%  The format of the Usage routine is:
%
%      Usage()
%
%
*/
static void Usage()
{
  char
    **p;

  static char
    *ImageTypes[]=
    {
      "Tag   Description",
      "------------------------------------------------------------",
      "ALPHA Raw alpha bytes.",
      "AVS   AVS X image file.",
      "BMP   Microsoft Windows bitmap image file.",
      "CMYK  Raw cyan, magenta, yellow, and black bytes.",
      "EPS   Adobe Encapsulated PostScript file.",
      "FAX   Group 3.",
      "FITS  Flexible Image Transport System.",
      "GIF   Compuserve Graphics image file.",
      "GRAY  Raw gray bytes.",
      "HISTOGRAM",
      "IRIS  SGI RGB image file.",
      "JPEG",
      "MIFF  Machine Independant file format.",
      "MTV",
      "PCX   ZSoft IBM PC Paintbrush file.",
      "PICT  Apple Macintosh QuickDraw/PICT file.",
      "PNM   Portable bitmap.",
      "PS    Adobe PostScript file.",
      "PS2   Adobe Level II PostScript file.",
      "RGB   Raw red, green, and blue bytes.",
      "RLE   Utah Run length encoded image file; read only.",
      "SUN   SUN Rasterfile.",
      "TEXT  raw text file; read only.",
      "TGA   Truevision Targa image file.",
      "TIFF  Tagged Image File Format.",
      "VICAR read only.",
      "VIFF  Khoros Visualization image file.",
      "X     select image from X server screen.",
      "XC    constant image of X server border color.",
      "XBM   X11 bitmap file.",
      "XWD   X Window System window dump image file.",
      "YUV   Raw Y, U, and V bytes.  U and V, normally -0.5 through",
      "      0.5, are normalized to the range 0 through 255 to fit",
      "      within a byte.",
      (char *) NULL,
    },
    *options[]=
    {
      "-alpha              store alpha channel if the image has one",
      "-clip geometry      preferred size and location of the clipped image",
      "-colors value       preferred number of colors in the image",
      "-colorspace type    GRAY, RGB, XYZ, YCbCr, YIQ, or YUV",
      "-compress type      RunlengthEncoded or QEncoded",
      "-density geometry   vertical and horizonal density of the image",
      "-display server     obtain image or font from this X server",
      "-dither             apply Floyd/Steinberg error diffusion to image",
      "-font name          X11 font for displaying text",
      "-geometry geometry  width and height of the image",
      "-interlace type     NONE, LINE, or PLANE",
      "-monochrome         transform image to black and white",
      "-page geometry      size and location of the Postscript page",
      "-quality value      JPEG quality setting",
      "-scale geometry     preferred size factors of the image",
      "-scene value        image scene number",
      "-treedepth value    depth of the color classification tree",
      "-verbose            print detailed information about the image",
      (char *) NULL
    };
  (void) fprintf(stderr,"Usage: %s [options ...] input_file output_file\n",
    client_name);
  (void) fprintf(stderr,"\nWhere options include:\n");
  for (p=options; *p != (char *) NULL; p++)
    (void) fprintf(stderr,"  %s\n",*p);
  (void) fprintf(stderr,
    "\nChange '-' to '+' in any option above to reverse its effect.  For\n");
  (void) fprintf(stderr,
    "example,  specify +alpha to store the image without an alpha channel.\n");
  (void) fprintf(stderr,
    "\nBy default, the image format of `file' is determined by its magic\n");
  (void) fprintf(stderr,
    "number.  To specify a particular image format, precede the filename\n");
  (void) fprintf(stderr,
    "with an image format name and a colon (i.e. ps:image) or specify the\n");
  (void) fprintf(stderr,
    "image type as the filename suffix (i.e. image.ps).  Specify 'file' as\n");
  (void) fprintf(stderr,"'-' for standard input or output.\n");
  (void) fprintf(stderr,"\nThe following image formats are recognized: \n\n");
  for (p=ImageTypes; *p != (char *) NULL; p++)
    (void) fprintf(stderr,"  %s\n",*p);
  exit(1);
}

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                             %
%                                                                             %
%                                                                             %
%  M a i n                                                                    %
%                                                                             %
%                                                                             %
%                                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
*/
int main(argc,argv)
int
  argc;

char
  *argv[];
{
#define NotInitialized  (unsigned int) (~0)

  char
    *border_color,
    *clip_geometry,
    *density,
    *filename,
    *font,
    *image_geometry,
    *option,
    *page_geometry,
    *scale_geometry,
    *server_name;

  double
    normalized_maximum_error,
    normalized_mean_error;

  Image
    *image,
    *next_image;

  ImageInfo
    image_info;

  int
    i,
    status,
    x;

  time_t
    start_time;

  unsigned int
    alpha,
    colorspace,
    compression,
    dither,
    interlace,
    monochrome,
    mean_error_per_pixel,
    number_colors,
    quality,
    scene,
    tree_depth,
    verbose;

  unsigned long
    total_colors;

  /*
    Initialize program variables.
  */
  client_name=argv[0];
  if (argc < 3)
    Usage();
  /*
    Read image and convert to MIFF format.
  */
  alpha=NotInitialized;
  border_color=(char *) NULL;
  clip_geometry=(char *) NULL;
  colorspace=RGBColorspace;
  compression=UndefinedCompression;
  density=(char *) NULL;
  dither=False;
  font=(char *) NULL;
  image=(Image *) NULL;
  image_geometry=(char *) NULL;
  interlace=NoneInterlace;
  monochrome=False;
  number_colors=0;
  page_geometry=(char *) NULL;
  quality=75;
  scale_geometry=(char *) NULL;
  scene=0;
  server_name=(char *) NULL;
  start_time=time((time_t *) NULL);
  tree_depth=0;
  verbose=False;
  /*
    Check command syntax.
  */
  filename=(char *) NULL;
  for (i=1; i < (argc-1); i++)
  {
    option=argv[i];
    if (((int) strlen(option) < 2) || ((*option != '-') && (*option != '+')))
      {
        /*
          Read input image.
        */
        filename=option;
        GetImageInfo(&image_info);
        (void) strcpy(image_info.filename,filename);
        image_info.server_name=server_name;
        image_info.font=font;
        image_info.geometry=image_geometry;
        image_info.page=page_geometry;
        image_info.density=density;
        image_info.border_color=border_color;
        image_info.interlace=interlace;
        image_info.monochrome=monochrome;
        image_info.quality=quality;
        image_info.verbose=verbose;
        if (image != (Image *) NULL)
          Error("input image already specified",filename);
        image=ReadImage(&image_info);
        if (image == (Image *) NULL)
          exit(1);
      }
    else
      switch(*(option+1))
      {
        case 'a':
        {
          alpha=(*option == '-');
          break;
        }
        case 'b':
        {
          if (strncmp("bordercolor",option+1,7) == 0)
            {
              border_color=(char *) NULL;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing color on -bordercolor",(char *) NULL);
                  border_color=argv[i];
                }
              break;
            }
          break;
        }
        case 'c':
        {
          if (strncmp("clip",option+1,2) == 0)
            {
              clip_geometry=(char *) NULL;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing geometry on -clip",(char *) NULL);
                  clip_geometry=argv[i];
                }
              break;
            }
          if (strncmp("colors",option+1,7) == 0)
            {
              number_colors=0;
              if (*option == '-')
                {
                  i++;
                  if ((i == argc) || !sscanf(argv[i],"%d",&x))
                    Error("missing colors on -colors",(char *) NULL);
                  number_colors=atoi(argv[i]);
                }
              break;
            }
          if (strncmp("colorspace",option+1,7) == 0)
            {
              colorspace=RGBColorspace;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing type on -colorspace",(char *) NULL);
                  option=argv[i];
                  colorspace=UndefinedColorspace;
                  if (Latin1Compare("gray",option) == 0)
                    {
                      colorspace=GRAYColorspace;
                      number_colors=256;
                      tree_depth=8;
                    }
                  if (Latin1Compare("rgb",option) == 0)
                    colorspace=RGBColorspace;
                  if (Latin1Compare("xyz",option) == 0)
                    colorspace=XYZColorspace;
                  if (Latin1Compare("ycbcr",option) == 0)
                    colorspace=YCbCrColorspace;
                  if (Latin1Compare("yiq",option) == 0)
                    colorspace=YIQColorspace;
                  if (Latin1Compare("yuv",option) == 0)
                    colorspace=YUVColorspace;
                  if (colorspace == UndefinedColorspace)
                    Error("invalid colorspace type on -colorspace",option);
                }
              break;
            }
          if (strncmp("compress",option+1,3) == 0)
            {
              compression=NoCompression;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing type on -compress",(char *) NULL);
                  option=argv[i];
                  if (Latin1Compare("runlengthencoded",option) == 0)
                    compression=RunlengthEncodedCompression;
                  else
                    if (Latin1Compare("qencoded",option) == 0)
                      compression=QEncodedCompression;
                    else
                      Error("invalid compression type on -compress",option);
                }
              break;
            }
          Error("unrecognized option",option);
          break;
        }
        case 'd':
        {
          if (strncmp("density",option+1,3) == 0)
            {
              density=(char *) NULL;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing geometry on -density",(char *) NULL);
                  density=argv[i];
                }
              break;
            }
          if (strncmp("display",option+1,3) == 0)
            {
              server_name=(char *) NULL;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing server name on -display",(char *) NULL);
                  server_name=argv[i];
                }
              break;
            }
          if (strncmp("dither",option+1,3) == 0)
            {
              dither=(*option == '-');
              break;
            }
          Error("unrecognized option",option);
          break;
        }
        case 'f':
        {
          font=(char *) NULL;
          if (*option == '-')
            {
              i++;
              if (i == argc)
                Error("missing font name on -font",(char *) NULL);
              font=argv[i];
            }
          break;
        }
        case 'g':
        {
          image_geometry=(char *) NULL;
          if (*option == '-')
            {
              i++;
              if (i == argc)
                Error("missing geometry on -geometry",(char *) NULL);
              image_geometry=argv[i];
            }
          break;
        }
        case 'h':
        {
          Usage();
          break;
        }
        case 'i':
        {
          if (strncmp("interlace",option+1,3) == 0)
            {
              interlace=NoneInterlace;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing type on -interlace",(char *) NULL);
                  option=argv[i];
                  interlace=UndefinedInterlace;
                  if (Latin1Compare("none",option) == 0)
                    interlace=NoneInterlace;
                  if (Latin1Compare("line",option) == 0)
                    interlace=LineInterlace;
                  if (Latin1Compare("plane",option) == 0)
                    interlace=PlaneInterlace;
                  if (interlace == UndefinedInterlace)
                    Error("invalid interlace type on -interlace",option);
                }
              break;
            }
          Error("unrecognized option",option);
        }
        case 'm':
        {
          if (strncmp("monochrome",option+1,2) == 0)
            {
              monochrome=(*option == '-');
              if (monochrome)
                {
                  number_colors=2;
                  tree_depth=8;
                  colorspace=GRAYColorspace;
                }
              break;
            }
          Error("unrecognized option",option);
        }
        case 'p':
        {
          if (strncmp("page",option+1,2) == 0)
            {
              page_geometry=(char *) NULL;
              if (*option == '-')
                {
                  i++;
                  if (i == argc)
                    Error("missing page geometry on -page",(char *) NULL);
                  page_geometry=argv[i];
                }
              break;
            }
          Error("unrecognized option",option);
          break;
        }
        case 'q':
        {
          i++;
          if ((i == argc) || !sscanf(argv[i],"%d",&x))
            Error("missing quality on -quality",(char *) NULL);
          quality=atoi(argv[i]);
          break;
        }
        case 's':
        {
          if (strncmp("scale",option+1,3) == 0)
            {
              scale_geometry=(char *) NULL;
              if (*option == '-')
                {
                  i++;
                  if ((i == argc) || !sscanf(argv[i],"%f",(float *) &x))
                    Error("missing scale geometry on -scale",(char *) NULL);
                  scale_geometry=argv[i];
                }
              break;
            }
          if (strncmp("scene",option+1,3) == 0)
            {
              scene=0;
              if (*option == '-')
                {
                  i++;
                  if ((i == argc) || !sscanf(argv[i],"%d",&x))
                    Error("missing scene number on -scene",(char *) NULL);
                  scene=atoi(argv[i]);
                }
              break;
            }
          Error("unrecognized option",option);
          break;
        }
        case 't':
        {
          tree_depth=0;
          if (*option == '-')
            {
              i++;
              if ((i == argc) || !sscanf(argv[i],"%d",&x))
                Error("missing depth on -treedepth",(char *) NULL);
              tree_depth=atoi(argv[i]);
            }
          break;
        }
        case 'v':
        {
          verbose=(*option == '-');
          break;
        }
        default:
        {
          Error("unrecognized option",option);
          break;
        }
      }
  }
  if (image == (Image *) NULL)
    Error("missing an image file name",(char *) NULL);
  /*
    Write images.
  */
  do
  {
    total_colors=0;
    if (alpha != NotInitialized)
      image->alpha=alpha;
    if (compression != UndefinedCompression)
      image->compression=compression;
    if (scene != 0)
      image->scene=scene;
    (void) strcpy(image->filename,argv[i]);
    if (image->previous != (Image *) NULL)
      (void) sprintf(image->filename,"%s.%u",argv[i],image->scene);
    /*
      Transform image as defined by the clip, image and scale geometries.
    */
    TransformImage(&image,clip_geometry,image_geometry,scale_geometry);
    if (number_colors != 0)
      {
        /*
          Reduce the number of colors in the image.
        */
        if ((image->class == DirectClass) || (image->colors > number_colors) ||
            (colorspace == GRAYColorspace))
          QuantizeImage(image,number_colors,tree_depth,dither,colorspace,True);
        if (verbose)
          {
            /*
              Measure quantization error.
            */
            QuantizationError(image,&mean_error_per_pixel,
              &normalized_mean_error,&normalized_maximum_error);
            total_colors=NumberColors(image,(FILE *) NULL);
          }
        SyncImage(image);
      }
    status=WriteImage(&image_info,image);
    if (verbose)
      {
        /*
          Display detailed info about the image.
        */
        (void) fprintf(stderr,"[%u] %s=>%s %ux%u",image->scene,filename,
          image->filename,image->columns,image->rows);
        if (image->class == DirectClass)
          (void) fprintf(stderr," DirectClass");
        else
          if (total_colors == 0)
            (void) fprintf(stderr," PseudoClass %uc",image->colors);
          else
            {
              (void) fprintf(stderr," PseudoClass %lu=>%uc",total_colors,
                image->colors);
              (void) fprintf(stderr," %u/%.6f/%.6fe",mean_error_per_pixel,
                normalized_mean_error,normalized_maximum_error);
            }
        (void) fprintf(stderr," %s %lds\n",image->magick,
          time((time_t *) NULL)-start_time+1);
      }
    next_image=image->next;
    DestroyImage(image);
    image=next_image;
  } while (image != (Image *) NULL);
  return(!status);
}
