/*      HyperText Tranfer Protocol                                      HTTP.h
**      ==========================
*/

#ifndef HTTP_H
#define HTTP_H

#include "HTAccess.h"


extern HTProtocol HTTP;

#endif /* HTTP_H */
