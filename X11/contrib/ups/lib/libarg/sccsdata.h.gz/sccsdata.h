/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.1 2/17/89 */

#ifdef __STDC__
extern const char *_arg_sccsdata[];
#else
extern char *_arg_sccsdata[];
#endif
