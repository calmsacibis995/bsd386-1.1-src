/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.2 26/4/92 */

#ifdef __STDC__
extern const char *_mtrprog_sccsdata[];
#else
extern char *_mtrprog_sccsdata[];
#endif
