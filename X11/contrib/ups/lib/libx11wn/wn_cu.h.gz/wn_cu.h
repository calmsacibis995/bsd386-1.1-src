/* wn_cu.h - header file for wn_cu.c */

/*  Copyright 1991 Mark Russell, University of Kent at Canterbury.
 *
 *  You can do what you like with this source code as long as
 *  you don't try to make money out of it and you include an
 *  unaltered copy of this message (including the copyright).
 */

/* @(#)wn_cu.h	1.4 4/7/91 (UKC) */

void wn__set_x11_cursor_colors PROTO((XColor *fg_color, XColor *bg_color));
