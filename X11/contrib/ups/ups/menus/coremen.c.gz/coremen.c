#include <stdio.h>
#include <menu3.h>

MENU core_men = {
	0x440,
	3980,
	"write target core",
	99,
	-1,
	-1,
	600,
	47,
	0,
	0,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
