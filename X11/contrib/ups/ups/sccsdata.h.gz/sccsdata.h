/* sccsdata.h - header file for sccsdata.c */

/* @(#)sccsdata.h	1.1 2/19/89 */

#ifdef __STDC__
extern const char *_ups_sccsdata[];
#else
extern char *_ups_sccsdata[];
#endif
