# include "stdio.h"
# define U(x) ((unsigned char)(x))
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) (void)putc(c,yyout)
#if defined(__cplusplus) || defined(__STDC__)
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);

#ifndef __STDC__
#ifndef yyless
	void yyless(int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#endif

#endif
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO (void)fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

# line 3 "lex.l"
/*****************************************************************************/

# line 4 "lex.l"
/**       Copyright 1988 by Evans & Sutherland Computer Corporation,        **/

# line 5 "lex.l"
/**                          Salt Lake City, Utah                           **/

# line 6 "lex.l"
/**  Portions Copyright 1989 by the Massachusetts Institute of Technology   **/

# line 7 "lex.l"
/**                        Cambridge, Massachusetts                         **/

# line 8 "lex.l"
/**                                                                         **/

# line 9 "lex.l"
/**                           All Rights Reserved                           **/

# line 10 "lex.l"
/**                                                                         **/

# line 11 "lex.l"
/**    Permission to use, copy, modify, and distribute this software and    **/

# line 12 "lex.l"
/**    its documentation  for  any  purpose  and  without  fee is hereby    **/

# line 13 "lex.l"
/**    granted, provided that the above copyright notice appear  in  all    **/

# line 14 "lex.l"
/**    copies and that both  that  copyright  notice  and  this  permis-    **/

# line 15 "lex.l"
/**    sion  notice appear in supporting  documentation,  and  that  the    **/

# line 16 "lex.l"
/**    names of Evans & Sutherland and M.I.T. not be used in advertising    **/

# line 17 "lex.l"
/**    in publicity pertaining to distribution of the  software  without    **/

# line 18 "lex.l"
/**    specific, written prior permission.                                  **/

# line 19 "lex.l"
/**                                                                         **/

# line 20 "lex.l"
/**    EVANS & SUTHERLAND AND M.I.T. DISCLAIM ALL WARRANTIES WITH REGARD    **/

# line 21 "lex.l"
/**    TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES  OF  MERCHANT-    **/

# line 22 "lex.l"
/**    ABILITY  AND  FITNESS,  IN  NO  EVENT SHALL EVANS & SUTHERLAND OR    **/

# line 23 "lex.l"
/**    M.I.T. BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL  DAM-    **/

# line 24 "lex.l"
/**    AGES OR  ANY DAMAGES WHATSOEVER  RESULTING FROM LOSS OF USE, DATA    **/

# line 25 "lex.l"
/**    OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER    **/

# line 26 "lex.l"
/**    TORTIOUS ACTION, ARISING OUT OF OR IN  CONNECTION  WITH  THE  USE    **/

# line 27 "lex.l"
/**    OR PERFORMANCE OF THIS SOFTWARE.                                     **/

# line 28 "lex.l"
/*****************************************************************************/


# line 30 "lex.l"
/***********************************************************************
 *
 * $XConsortium: lex.l,v 1.62 89/12/10 17:46:33 jim Exp $
 *
 * .twmrc lex file
 *
 * 12-Nov-87 Thomas E. LaStrange		File created
 *
 ***********************************************************************/


# line 40 "lex.l"
/* #include <stdio.h> */
#include "gram.h"
#include "parse.h"
extern char *ProgramName;

extern int ParseError;

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 51 "lex.l"
			{ return (LB); }
break;
case 2:

# line 52 "lex.l"
			{ return (RB); }
break;
case 3:

# line 53 "lex.l"
			{ return (LP); }
break;
case 4:

# line 54 "lex.l"
			{ return (RP); }
break;
case 5:

# line 55 "lex.l"
			{ return (EQUALS); }
break;
case 6:

# line 56 "lex.l"
			{ return (COLON); }
break;
case 7:

# line 57 "lex.l"
			{ return PLUS; }
break;
case 8:

# line 58 "lex.l"
			{ return MINUS; }
break;
case 9:

# line 59 "lex.l"
			{ return OR; }
break;
case 10:

# line 61 "lex.l"
		{ int token = parse_keyword (yytext, 
							     &yylval.num);
				  if (token == ERRORTOKEN) {
				      twmrc_error_prefix();
				      fprintf (stderr,
				       "ignoring unknown keyword:  %s\n", 
					       yytext);
				      ParseError = 1;
				  } else 
				    return token;
				}
break;
case 11:

# line 73 "lex.l"
			{ yylval.num = F_EXEC; return FSKEYWORD; }
break;
case 12:

# line 74 "lex.l"
			{ yylval.num = F_CUT; return FSKEYWORD; }
break;
case 13:

# line 76 "lex.l"
		{ yylval.ptr = (char *)yytext; return STRING; }
break;
case 14:

# line 77 "lex.l"
		{ (void)sscanf(yytext, "%d", &yylval.num);
				  return (NUMBER);
				}
break;
case 15:

# line 80 "lex.l"
		{;}
break;
case 16:

# line 81 "lex.l"
			{;}
break;
case 17:

# line 82 "lex.l"
			{
				  twmrc_error_prefix();
				  fprintf (stderr, 
					   "ignoring character \"%s\"\n",
					   yytext);
				  ParseError = 1;
				}
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
yywrap() { return(1);}

#undef unput
#undef input
#undef output
#undef feof
#define unput(c)	twmUnput(c)
#define input()		(*twmInputFunc)()
#define output(c)	TwmOutput(c)
#define feof()		(1)
int yyvstop[] = {
0,

17,
0,

16,
17,
0,

16,
0,

11,
17,
0,

17,
0,

17,
0,

3,
17,
0,

4,
17,
0,

7,
17,
0,

8,
17,
0,

10,
17,
0,

14,
17,
0,

6,
17,
0,

5,
17,
0,

12,
17,
0,

1,
17,
0,

9,
17,
0,

2,
17,
0,

13,
0,

15,
0,

10,
0,

14,
0,

13,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	7,21,	
0,0,	0,0,	1,4,	1,5,	
0,0,	0,0,	0,0,	7,21,	
7,21,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	8,24,	0,0,	
0,0,	0,0,	1,6,	1,7,	
1,8,	0,0,	8,24,	8,25,	
7,22,	1,9,	1,10,	2,6,	
1,11,	2,8,	1,12,	1,13,	
23,28,	1,14,	2,9,	2,10,	
7,21,	2,11,	7,21,	2,12,	
0,0,	0,0,	0,0,	1,15,	
0,0,	0,0,	1,16,	8,24,	
0,0,	0,0,	0,0,	0,0,	
2,15,	0,0,	0,0,	2,16,	
0,0,	0,0,	0,0,	8,24,	
0,0,	8,24,	14,27,	14,27,	
14,27,	14,27,	14,27,	14,27,	
14,27,	14,27,	14,27,	14,27,	
0,0,	0,0,	0,0,	0,0,	
0,0,	21,23,	28,23,	1,17,	
0,0,	0,0,	7,23,	0,0,	
0,0,	0,0,	0,0,	0,0,	
2,17,	0,0,	23,23,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	13,26,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,18,	1,19,	1,20,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	2,18,	2,19,	2,20,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	13,26,	13,26,	
13,26,	13,26,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-10,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+6,
yycrank+0,	0,		yyvstop+8,
yycrank+-6,	0,		yyvstop+11,
yycrank+-29,	0,		yyvstop+13,
yycrank+0,	0,		yyvstop+15,
yycrank+0,	0,		yyvstop+18,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+24,
yycrank+71,	0,		yyvstop+27,
yycrank+30,	0,		yyvstop+30,
yycrank+0,	0,		yyvstop+33,
yycrank+0,	0,		yyvstop+36,
yycrank+0,	0,		yyvstop+39,
yycrank+0,	0,		yyvstop+42,
yycrank+0,	0,		yyvstop+45,
yycrank+0,	0,		yyvstop+48,
yycrank+-1,	yysvec+7,	0,	
yycrank+0,	0,		yyvstop+51,
yycrank+-14,	yysvec+7,	0,	
yycrank+0,	yysvec+8,	0,	
yycrank+0,	0,		yyvstop+53,
yycrank+0,	yysvec+13,	yyvstop+55,
yycrank+0,	yysvec+14,	yyvstop+57,
yycrank+-2,	yysvec+7,	yyvstop+59,
0,	0,	0};
struct yywork *yytop = yycrank+193;
struct yysvf *yybgin = yysvec+1;
unsigned char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,'"' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,'.' ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,
'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,
'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,
'.' ,'.' ,'.' ,01  ,01  ,01  ,01  ,01  ,
01  ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,
'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,
'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,'.' ,
'.' ,'.' ,'.' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ident	"@(#)libl:lib/ncform	1.7"
int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
	return(input());
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
	output(c);
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
