/*
 * about.c : The "About xarchie" panel
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void initAboutActions();
extern void popupAboutPanel();
extern void setAboutShellState();

