/*
 * actions.h : Definition of global action procedures
 *
 * George Ferguson, ferguson@cs.rochester.edu, 20 Oct 1991.
 * Version 2.0: 23 Apr 1993.
 */

#ifndef _ACTIONS_H
#define _ACTIONS_H

extern void initActions();

#endif /* _ACTIONS_H */
