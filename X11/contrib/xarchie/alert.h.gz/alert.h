/*
 * alert.h : External defs for alert functions
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#ifndef _ALERT_H
#define _ALERT_H

extern void alert0(),alert1(),alert2();

#endif
