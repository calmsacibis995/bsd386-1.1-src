/* config.h.  Generated automatically by configure.  */

#ifndef _CONFIG_H
#define _CONFIG_H

/* Define if you have the ANSI C header files.  */
#undef STDC_HEADERS

/* Define if you have <string.h>, otherwise assumes <strings.h> */
#define HAVE_STRING_H 1

/* Define if you have memory.h, and string.h doesn't declare the
   mem* functions.  */
#define HAVE_MEMORY_H 1

/* Adjust of your sys/param.h doesn't define MAXPATHLEN */
#define HAVE_SYS_PARAM_H 1
#ifndef HAVE_SYS_PARAM_H
# define MAXPATHLEN 1024
#endif

/* Define if your sys/time.h declares struct tm.  */
#undef TM_IN_SYS_TIME

/* Define if your sys/types.h declares FD_SET.  */
#define FD_SET_IN_SYS_TYPES_H 1
/* Define if your sys/select.h declares FD_SET.  */
#undef FD_SET_IN_SYS_SELECT_H
/* Define if your sys/inet.h declares FD_SET.  */
#undef FD_SET_IN_SYS_INET_H

/* Define if you have re_comp() and re_exec() */
#define HAVE_RE_COMP 1
/* Some systems use regcmp() and regex() instead (like AIX) */
#undef HAVE_REGCMP

/* Define if you have strcasecmp() */
#define HAVE_STRCASECMP 1

/* Define if you have random() */
#define HAVE_RANDOM 1
/* Some systems use rand() instead (like HPUX) */
#define HAVE_RAND 1

/* Define if you have the ANSI function strerror() */
#define HAVE_STRERROR 1

/* Define if you have errno (who doesn't)? */
#define HAVE_ERRNO 1

/* Define if you have sys_errlist (not needed if you have strerror) */
#define HAVE_SYS_ERRLIST 1

/* Define if you have getlogin() (who doesn't?) */
#define HAVE_GETLOGIN 1

/* Define if you have getpwuid() defined in <pwd.h> */
#define HAVE_GETPWUID 1

/* Define if you have strspn() */
#define HAVE_STRSPN 1

/* Define this if you need -lresolv in your link line (used by imake) */
#undef NEED_LRESOLV

#endif /*!_CONFIG_H*/
