/*
 * confirm.c : Confirmer popup
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#include <X11/Intrinsic.h>
#include "popups.h"

/*
 * Functions defined here:
 */
int confirm0();
static void confirmCallback();

/*
 * Data defined here:
 */
static Widget confirmShell;
static int confirmResult;

/*	-	-	-	-	-	-	-	-	*/

int
confirm0(str)
char *str;
{
    if (confirmShell == NULL)
	confirmShell = createPopup("confirm",2,confirmCallback);
    setPopupLabel(confirmShell,"confirm",str);
    popupMainLoop(confirmShell);
    return(confirmResult);
}

/*ARGSUSED*/
static void
confirmCallback(w,client_data,call_data)
Widget w;
XtPointer client_data;		/* button number */
XtPointer call_data;
{
    switch ((int)client_data) {
      case 0:			/* YES */
	confirmResult = 1;
	break;
      case 1:			/* NO */
	confirmResult = 0;
	break;
    }
    popupDone();
}
