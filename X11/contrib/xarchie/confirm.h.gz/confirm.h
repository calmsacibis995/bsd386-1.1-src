/*
 * confirm.h : External defs for confirmer functions
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#ifndef _CONFIRM_H
#define _CONFIRM_H

extern int confirm0();

#endif
