/*
 * debug.h : Macros for debug messages
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#ifdef DEBUG
#define DEBUG0(S)		fprintf(stderr,S)
#define DEBUG1(S,A1)		fprintf(stderr,S,A1)
#define DEBUG2(S,A1,A2)		fprintf(stderr,S,A1,A2)
#define DEBUG3(S,A1,A2,A3)	fprintf(stderr,S,A1,A2,A3)
#else
/*SUPPRESS 558*//* Saber: condition always false */
/*SUPPRESS 530*//* Saber: empty body of loop */
#define DEBUG0(S)
#define DEBUG1(S,A1)
#define DEBUG2(S,A1,A2)
#define DEBUG3(S,A1,A2,A3)
#endif
