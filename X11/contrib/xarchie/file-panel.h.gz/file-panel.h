/*
 * file-panel.h : Defs for the save-load-write panel
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#ifndef FILE_PANEL_H
#define FILE_PANEL_H

#define FILE_SAVE  1
#define FILE_LOAD  2
#define FILE_WRITE 3

extern void initFilePanelActions();
extern void updateFileWriteMode();
extern void setFileShellState();

#endif
