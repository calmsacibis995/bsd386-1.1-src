/*
 * ftp-actions.h : Defs for yet another layer of the ftp routines
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void initFtpActions();
extern void ftpGetSelectedItems(),ftpOpenSelectedItems();
extern void setFtpTraceShellState();
