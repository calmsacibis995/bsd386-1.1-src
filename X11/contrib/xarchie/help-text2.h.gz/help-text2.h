{
2
,"NAME"},{
7
,"SYNOPSIS"},{
20
,"DESCRIPTION"},{
55
,"USER'S GUIDE"},{
63
," What is Archie?"},{
100
," What is Xarchie?"},{
143
," The Xarchie Display"},{
238
," Basic Xarchie Usage"},{
248
,"  Querying"},{
292
,"  Aborting"},{
310
,"  Browsing"},{
387
,"  Expanding the Browser"},{
420
,"  Viewing Files"},{
466
,"  Retrieving Files"},{
509
,"  Saving, Loading, and Writing"},{
572
,"  Quitting Xarchie"},{
578
," Advanced Xarchie Usage"},{
588
,"  The Settings Panel"},{
627
,"  Archie host"},{
660
,"  Search mode"},{
688
,"  Sort mode"},{
758
,"  Nice level"},{
790
,"  Other Query Settings"},{
822
,"  FTP settings"},{
893
,"  Querying Hosts and Locations"},{
940
,"REFERENCE MANUAL"},{
952
," Command-line Options"},{
1093
," Non-widget Resources"},{
1112
,"  Query Resources"},{
1267
,"  Browser Resources"},{
1301
,"  FTP Resources"},{
1366
,"  Database Writing Resources"},{
1379
,"  Special Font Resources"},{
1412
,"  Other Resources"},{
1454
," Widget Hierarchies"},{
1460
,"  Main Xarchie Widgets"},{
1562
,"  Settings Panel Widgets"},{
1601
,"  File Panel Widgets"},{
1636
,"  View Window Widgets"},{
1676
,"  Help Panel Widgets"},{
1707
,"  About Panel Widgets"},{
1725
,"  Popup Widgets"},{
1746
,"  Menus"},{
1812
," Translation Actions"},{
1828
,"  Main panel actions"},{
1896
,"  Browser actions"},{
1973
,"  Settings actions"},{
2082
,"  File actions"},{
2119
,"  Help actions"},{
2140
,"  Miscellaneous actions"},{
2149
," Environment Variables"},{
2164
," Files"},{
2169
," Diagnostics"},{
2219
," Known Bugs"},{
2256
," Reporting Bugs"},{
2302
,"AUTHOR"},{
000,NULL}
