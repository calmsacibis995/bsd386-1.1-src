#!/bin/sh
#
# help-text2.sh : Extract the headings by taking the non-indented initial
#	parts of the help text strings. The output is a set of initializers
#	for a { lineno,string } structure. Since we can only use the
#	sed = command to print the line number, and it prints it on a
#	line by itself, the output is kinda gross. Sorry.
#
# George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
#

echo '{'
sed -n -e '/^NULL,$/=' -e 's/^\("..[^ "].*\)\\n",$/,\1"},{/p'
echo '000,NULL}'
