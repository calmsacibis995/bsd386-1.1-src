/*
 * hostname.h : Definition of "portable" hostname function
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern char *GetHostname();
