/*
 * menus.h : Defs for all the xarchie menus
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void initFileMenu();

extern void initQueryMenu();

extern void initSettingsMenu();
extern void updateSettingsMenuMarks();
extern void setSearchMenuMark(),setSortMenuMark();
extern void setNiceMenuMark(),setHostMenuMark();

extern void initFilePanelMenu();
