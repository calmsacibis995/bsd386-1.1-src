/*
 * menu.h : Menu creation rotuines
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void initMenuCreator();

extern Widget createMenu(/* char *name, char *item_basename,
			    int numItems,
			    SmeBSBObject *items,
			    XtCallbackProc callback */);

extern void clearAllItemMarks(/* Object *items, int numItems */);
extern void setIthItemMark(/* Object *items, int i, int numItems */);
