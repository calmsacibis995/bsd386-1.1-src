/*
 * patchlevel.h : xarchie version control
 *
 * George Ferguson, ferguson@cs.rochester.edu, 19 Nov 1991.
 * Version 2.0 : 23 Apr 1993.
 * Version 2.0.1: 26 Apr 1993
 * Version 2.0.2: 28 Apr 1993
 * Version 2.0.3: 13 May 1993
 * Version 2.0.4: 14 May 1993
 * Version 2.0.5:  1 Jun 1993
 * Version 2.0.6:  7 Jun 1993
 * Version 2.0.7: 30 Jun 1993
 * Version 2.0.8: 27 Jul 1993
 * Version 2.0.9: 24 Aug 1993
 */

#undef BETA
#define VERSION		2.0
#define PATCHLEVEL	9
