/*
 * popups.h : External defs for alert, confirm, and dialog boxes
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#ifndef POPUPS_H
#define POPUPS_H

extern Widget createPopup();			/* Generic popup routines */
extern void setPopupLabel();
extern void popupMainLoop();
extern void popupDone();			/* Call this when done */

#endif
