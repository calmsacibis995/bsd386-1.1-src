/*
 * query.h : Interface routines to Prospero querying
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#include "pfs.h"

extern void queryItemAndParse(),queryHostAndParse(),queryLocationAndParse();
extern VLINK stringQuery();
extern int parseArchieQueryResults(), parseStringQueryResults();
extern int handleProsperoErrors();
