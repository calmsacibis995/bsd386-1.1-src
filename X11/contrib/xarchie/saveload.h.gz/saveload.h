/*
 * saveload.h : Device-independent routines for dumping (ie printing),
 *	saving, and restoring state.
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#ifndef SAVELOAD_H
#define SAVELOAD_H

extern int save(),load(),writeToFile();

#endif
