/*
 * settings.h : External defs for the settings panel
 *
 * George Ferguson, ferguson@cs.rochester.edu, 22 Oct 1991.
 * Version 2.0: 23 Apr 1993.
 */

#ifndef SETTINGS_H
#define SETTINGS_H

extern void initSettings(),reinitSettings();
extern void setSettingsShellState();
extern void updateSettingsHost(),updateSettingsSearchType();
extern void updateSettingsSortType(),updateSettingsNiceLevel();
extern void updateSettingsAutoScroll();
extern void updateSettingsFtpType(),updateSettingsFtpPrompt();
extern void updateSettingsFtpTrace(),updateSettingsFtpStrip();
extern void setSettingsChangedFlag();

#endif /* SETTINGS_H */
