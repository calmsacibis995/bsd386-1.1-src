/*
 * status.c : Display-independent status indication routines
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

#include <stdio.h>
extern void setStatusText();		/* display.c */

/*
 * Functions defined here:
 */
void status0(), status1(), status2();

/*	-	-	-	-	-	-	-	-	*/

void
status0(str)
char *str;
{
    setStatusText(str);
}

void
status1(fmt,arg)
char *fmt,*arg;
{
    char buf[256];

    sprintf(buf,fmt,arg);
    status0(buf);
}

void
status2(fmt,arg1,arg2)
char *fmt,*arg1,*arg2;
{
    char buf[256];

    sprintf(buf,fmt,arg1,arg2);
    status0(buf);
}
