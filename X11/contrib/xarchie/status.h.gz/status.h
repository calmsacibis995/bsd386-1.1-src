/*
 * status.h
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void status0(), status1(), status2();
