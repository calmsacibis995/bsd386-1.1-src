/*
 * syntax.h : Defs for printing the usage message (anal aren't we)
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void syntax();
