/*
 * sysdefs.h : System functions that are tricky to get declared...
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

/* #include <stdlib.h> */
#ifdef __STDC__
extern char *malloc(unsigned ptr);
extern char *calloc(unsigned nelem, unsigned size);
extern int free(char *ptr);
extern char *getenv(const char *str);
extern void exit(int status);
extern void abort(void);
#else
extern char *malloc(),*calloc();
extern int free();
extern char *getenv();
extern void exit();
extern void abort();
#endif
