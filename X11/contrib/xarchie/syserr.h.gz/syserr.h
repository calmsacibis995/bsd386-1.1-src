/*
 * syserr.h : Portable interface to system error messages.
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 *
 */

/* Either the real errno or one of our making, for external use. */
#ifndef MSDOS
extern int errno;		/* MSDOS doesn't like this, apparently */
#endif /* !MSDOS */

extern void sysError();
