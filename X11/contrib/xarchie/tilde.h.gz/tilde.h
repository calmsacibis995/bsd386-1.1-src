/*
 * tilde.h : Defs for tilde expansion routine
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 *
 */

extern char *tildeExpand(/* char *file */);
