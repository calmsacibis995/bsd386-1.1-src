/*
 * username.h : Definition of "portable" username function
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern char *GetUsername();
