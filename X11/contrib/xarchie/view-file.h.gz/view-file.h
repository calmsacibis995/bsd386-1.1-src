/*
 * view-file.c : Defs for the popus when files are "opened" via ftp
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void initViewerActions();
extern void viewFile();
