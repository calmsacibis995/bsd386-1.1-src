/*
 * weight.h : Routines for ordering hosts by "weight"
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 * Based on a suggestion from Peter J Nilsson (pjn@ida.liu.se).
 */

typedef struct _hostWeightRec {
    char *name;
    int weight;
} HostWeightRec;

extern void initHostWeights(),reinitHostWeights();
extern int hostWeight(/* char *host */);
