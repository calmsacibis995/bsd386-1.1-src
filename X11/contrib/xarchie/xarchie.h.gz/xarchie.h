/*
 * xarchie.h : Definitions of the X globals and misc. functions
 *
 * George Ferguson, ferguson@cs.rochester.edu, 2 Nov 1991.
 * Version 2.0: 23 Apr 1993.
 */

#ifndef XARCHIE_H
#define XARCHIE_H

extern Display *display;
extern Screen *screen;
extern Window root;
extern Atom WM_DELETE_WINDOW,WM_PROTOCOLS;

extern XtAppContext appContext;
extern Widget toplevel;
extern Widget queryButton,abortButton;
extern Widget statusText;
extern Widget browserForm;
extern Widget browserUpButton,browserDownButton;
extern Widget browserViewports[],browserScrollbars[],browserLists[];
extern Widget searchText;
extern Widget hostText,locationText,fileText,sizeText,modesText,dateText;

extern char *program;
extern char *tmpDirectory;

extern void bye();
extern void setBusyStatus(),setIconStatus();

#endif /* XARCHIE_H */
