/*
 * xutil.h : Miscellaneous X functions
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void setWidgetString(
#if NeedFunctionPrototypes
    Widget w,
    char *str
#endif
);

extern void setWidgetLabel(
#if NeedFunctionPrototypes
    Widget w,
    char *str
#endif
);

extern char *getWidgetString(
#if NeedFunctionPrototypes
    Widget w
#endif
);

extern char *getWidgetLabel(
#if NeedFunctionPrototypes
    Widget w
#endif
);

extern void appendWidgetText(
#if NeedFunctionPrototypes
    Widget w,
    char *text
#endif
);

