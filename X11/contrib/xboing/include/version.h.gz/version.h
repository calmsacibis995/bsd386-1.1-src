#include "copyright.h"

extern int 	buildNum;
extern char *dateString;
extern char *whoString;
extern char *machineString;

#define VERSION 	1
#define REVNUM 		7000
