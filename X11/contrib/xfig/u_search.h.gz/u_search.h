/*
 * FIG : Facility for Interactive Generation of figures
 * Copyright (c) 1985 by Supoj Sutanthavibul
 *
 * "Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both the copyright
 * notice and this permission notice appear in supporting documentation. 
 * No representations are made about the suitability of this software for 
 * any purpose.  It is provided "as is" without express or implied warranty."
 */

void		init_searchproc_left();
void		init_searchproc_middle();
void		init_searchproc_right();

int		point_search_left();
int		point_search_middle();
int		point_search_right();

int		object_search_left();
int		object_search_middle();
int		object_search_right();

F_text	       *text_search();
F_compound     *compound_search();
F_compound     *compound_point_search();
