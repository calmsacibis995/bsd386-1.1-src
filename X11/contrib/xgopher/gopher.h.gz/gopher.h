/* gopher.h
   main gopher data structures */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/


#ifndef G_GOPHER_H
#define G_GOPHER_H

#include "conf.h"

#define BOOLEAN		int		/* for TRUE/FALSE variables */

typedef	long	gopherTime;
#define	NOT_LOADED	-99		/* special "time" */

typedef enum { copyTypeUnspec, copyTypeNone, copyTypeAscii,
	       copyTypeBinaryEOF } copyType;


/* =======================================================================*/

typedef struct accessListItemStruct {
        char            *address;
        BOOLEAN         numeric;
        struct accessListItemStruct   *next;
} accessListItem;

typedef accessListItem *accessList;

/* =======================================================================*/

#define vStringValue(vs) (vs)->data

typedef struct vStringStruct {
	int	len;			/* allocated length */
	char	*data;			/* string value */
	} vString;

/* =======================================================================*/
/* subclass type data for gopher item */

typedef struct subClassInfoStruct {
	char	*typeName;
	char	*typePrefix;
	accessList	*hostList;		/* access restricted list */
	BOOLEAN	(*checkAccess)();	/* to see if item can be accessed */
	BOOLEAN (*copyProc)();		/* to copy an item */
	copyType copyDataType;		/* data type of network data */
	BOOLEAN	(*processItem)();	/* to process (fetch) an item */
	void	(*initProc)();		/* class initialize procedure */
	void	(*doneProc)();		/* class terminate procedure */
	void	(*restartProc)();	/* clean up class for restart */
	} scInfo;


/* =======================================================================*/

/* gopherItem reflects the gopher directory structure of the protocol 
   plus a link to create lists of items. */

typedef struct gopherItemStruct {
	char		type;
	char		userStringAndPrefix[PREFIX_LEN + USER_STRING_LEN];
	vString		selector;
	char		host[HOST_STRING_LEN];
	int		port;
	BOOLEAN		plus;
	BOOLEAN		accessOk;
	scInfo		*sc;
	struct gopherItemStruct *next;
	} gopherItem, *gopherItemP;

/* header for a list of gopherItem's */

typedef struct gopherItemListStruct {
	gopherItemP	first;
	gopherItemP	last;
	} gopherItemList, *gopherItemListP;

/* userStringAndPrefix contains two strings concatenated together.
   The components, prefix and userString, are accesses with these macros. */

#define USER_STRING_PREFIX(gi)	((gi)->userStringAndPrefix)
#define USER_STRING(gi)		(((gi)->userStringAndPrefix)+PREFIX_LEN)

#define PREFIX(gi, p) {int i; char *c=(gi)->userStringAndPrefix;\
			for (i=0;i<PREFIX_LEN;i++) *c++ = *(p+i);}




/* Types of objects returned from a server */

#define A_FILE		'0'
#define A_DIRECTORY	'1'
#define A_CSO		'2'
#define A_ERROR		'3'
#define A_MAC_BINHEX	'4'
#define A_DOS_BINHEX	'5'
#define A_UNIX_UUENCODE	'6'
#define A_INDEX		'7'
#define A_TELNET	'8'
#define A_BINARY	'9'
#define A_IMAGE		'I'
#define A_TN3270	'T'
#define A_DUP_SERVER	'+'
#define A_SOUND		's'
#define A_EXTENDED	'='
#define A_UNKNOWN	'?'
#define A_EOI		'.'

#define A_BADREAD	'@'


/* =======================================================================*/

/* gopher directory data structures */

/* gopherDir maintains the contents of a directory, and the
   information required to reobtain the directory when necessary.
   The data structure reflects a bi-directional linked list of the
   user's traversal of gopher-space. */

typedef struct gopherDirStruct {
	struct gopherDirStruct	*previous;
	struct gopherDirStruct	*next;
	gopherItemP		selectorItem;
	gopherItemList		contents;
	gopherTime		created;     
	} gopherDir, *gopherDirP;


/* header for a list of gopherDir's */

typedef struct gopherDirListStruct {
        gopherDirP     first;
        gopherDirP     last;
        } gopherDirList, *gopherDirListP;



#endif /* G_GOPHER_H */
