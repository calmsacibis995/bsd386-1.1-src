/* oneLine.h
   global declarations to provide translations to the text widget
   to provide a one line text field widget. */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/

#ifndef	ONELINE_H
#define	ONELINE_H

/* Translations  for the asciiText widget to simulate a single-line
   text entry widget.  Disable any default translations that allow
   movement up/down by line/paragraphs/pages.  This also means making
   the Return key a no-op.

   However, the following line should NOT be added here.
       <Key>Return: no-op()\n\
   These translations cannot be overridden in the resource file, and
   we need <Key>Return to be an accept action for several widgets.
   Therefore, make sure to include the above translation in the resource
   file for any single-line text widget that does not otherwise
   set an action for Return. */

char *OneLineTextTr =  "#override\
<Key>Down: no-op()\n\
<Key>Up: no-op()\n\
<Key>Linefeed: no-op()\n\
Ctrl<Key>J: no-op()\n\
Ctrl<Key>M: no-op()\n\
Ctrl<Key>N: no-op()\n\
Ctrl<Key>O: no-op()\n\
Ctrl<Key>P: no-op()\n\
Ctrl<Key>R: no-op()\n\
Ctrl<Key>S: no-op()\n\
Ctrl<Key>V: no-op()\n\
Ctrl<Key>Z: no-op()\n\
Meta<Key>V: no-op()\n\
Meta<Key>Z: no-op()\
";

#endif	/* ONELINE_H */
