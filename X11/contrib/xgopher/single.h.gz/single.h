/* single.h
   declarations for functions in single.c */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/

#ifndef	SINGLE_H
#define	SINGLE_H
#include "gopher.h"
#include <X11/Intrinsic.h>

void		 displaySinglePanel(
);

void		endSinglePanel(
);

void		makeSinglePanel(
#ifdef PROTO
	Widget		/* top */
#endif
);

/* internal */

static Widget 	createTextFieldL(
#ifdef PROTO
	char *,		/* name */
	Widget,		/* parent */
	Widget		/* below */
#endif
);

static void	setText(
#ifdef PROTO
	Widget,		/* w */
	String		/* value */
#endif
);

static char	*getText(
#ifdef PROTO
	Widget		/* w */
#endif
);

static gopherItemP	buildSingleItem(
);

static void	processSingleItem(
);

static void	doneProc(
#ifdef PROTO
	Widget,		/* w */
	XtPointer,	/* client_data */
	XtPointer	/* call_data */
#endif
);

static void	cancelProc(
#ifdef PROTO
	Widget,		/* w */
	XtPointer,	/* client_data */
	XtPointer	/* call_data */
#endif
);

static void	singleMarkProc(
#ifdef PROTO
	Widget,		/* w */
	XtPointer,	/* client_data */
	XtPointer	/* call_data */
#endif
);

static void	singleHelpProc(
#ifdef PROTO
	Widget,		/* w */
	XtPointer,	/* client_data */
	XtPointer	/* call_data */
#endif
);

#endif	/* SINGLE_H */
