char *version = "\
XKeyCaps 1.27; Copyright (c) 1991, 1992, 1993 Jamie Zawinski <jwz@lucid.com>";
