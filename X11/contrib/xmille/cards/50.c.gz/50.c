# define static
# include	"_50"
