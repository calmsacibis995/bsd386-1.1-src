# define static
# include	"_blank"
