# define static
# include	"_flat"
# include	"flat_mask"
