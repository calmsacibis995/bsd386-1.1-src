# define static
# include	"_go"
# include	"go_mask"
