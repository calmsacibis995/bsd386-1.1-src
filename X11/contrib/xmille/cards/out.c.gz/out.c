# define static
# include "_out"
# include "out_mask"
