# define static
# include	"_right"
# include	"right_mask"
