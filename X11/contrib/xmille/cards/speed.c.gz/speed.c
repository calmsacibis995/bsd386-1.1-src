# define static
# include "_speed"
# include "speed_mask"
