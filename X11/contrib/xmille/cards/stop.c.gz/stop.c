# define static
# include	"_stop"
# include	"stop_mask"
