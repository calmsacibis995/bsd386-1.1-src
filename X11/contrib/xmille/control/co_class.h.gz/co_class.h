/*
 *	object classes used by co routines - private to co!
 */

extern Button		co_OK, co_CANCEL, co_NEW;
extern Scrollbar	co_SCROLL_LEFT_GUI, co_SCROLL_BOTTOM_GUI, co_SCROLL_LEFT_MENU;
extern XFontStruct	*co_font;
extern int		co_fore, co_back, co_background, co_border;
extern Display		*dpy;

