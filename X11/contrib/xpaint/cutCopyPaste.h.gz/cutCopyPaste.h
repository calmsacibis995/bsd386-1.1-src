/*
**  Just nice descriptions of some callbacks
*/
void StdUndoCallback(Widget, XtPointer, XtPointer);
void StdCopyCallback(Widget, XtPointer, XtPointer);
void StdPasteCallback(Widget, XtPointer, XtPointer);
void StdClearCallback(Widget, XtPointer, XtPointer);
void StdCutCallback(Widget, XtPointer, XtPointer);
void StdDuplicateCallback(Widget, XtPointer, XtPointer);
void StdSelectAllCallback(Widget, XtPointer, XtPointer);
void StdRegionFlipX(Widget, XtPointer, XtPointer);
void StdRegionFlipY(Widget, XtPointer, XtPointer);
void StdRegionInvert(Widget, XtPointer, XtPointer);

/*
**
*/
void ccpAddUndo(Widget, Widget);
void ccpAddCut(Widget, Widget);
void ccpAddCopy(Widget, Widget);
void ccpAddPaste(Widget, Widget);
void ccpAddClear(Widget, Widget);
void ccpAddDuplicate(Widget, Widget);
void ccpAddSaveRegion(Widget, Widget);
void ccpAddRegionInvert(Widget, Widget);
void ccpAddRegionFlipX(Widget, Widget);
void ccpAddRegionFlipY(Widget, Widget);

void ccpAddRegionSharpen(Widget, Widget);
void ccpAddRegionSmooth(Widget, Widget);
void ccpAddRegionEdge(Widget, Widget);

void ccpAddStdPopup(Widget);
