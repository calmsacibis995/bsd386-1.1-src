
/*  selectOp.c */
void	SelectSetCutMode(int);

/* circleOp.c */
Boolean	CircleGetStyle();
void	CircleSetStyle(Boolean);

/* fontOp.c */
void     FontChanged(Widget);

/* sprayOp.c */
Boolean	SprayGetStyle();
void	SpraySetStyle(Boolean);

/* brushOp.c */
Boolean EraseGetMode();
void	EraseSetMode(Boolean);

/* fontOp.c */
void	FontChanged(Widget);

/* boxOp.c */
void	BoxSetStyle(Boolean);
Boolean	BoxGetStyle();
