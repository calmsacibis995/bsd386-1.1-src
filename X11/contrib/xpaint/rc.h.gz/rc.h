
typedef struct {
	int	freed;
	int	ncolors;
	char	**colors;
	Boolean	*colorFlags;
	Pixel	*colorPixels;
	int	nimages;
	Image	**images;
} RCInfo;

RCInfo	*ReadRC();
