#define MAGIC_READER	"Best Guess"

typedef Image	*(*RWreadFunc)(char *);
typedef int	(*RWwriteFunc)(char *, Image *);
typedef int	(*RWtestFunc)(char *);

void		*RWtableGetEntry(char *);
RWreadFunc	RWtableGetReader(void *);
RWwriteFunc	RWtableGetWriter(void *);
char		**RWtableGetReaderList();
char		**RWtableGetWriterList();
char		*RWGetMsg();
void		*RWtableGetReaderID();
char    	*RWtableGetId(void *);

#ifdef MISSING_STDARG_H
void            RWSetMsg(...);
#else
void            RWSetMsg(char *, ...);
#endif
