/* $XConsortum: TekCMSglob.h,v 1.1 91/02/11 19:40:54 dave Exp $ */

#ifndef TEKCMSGLOB
#define TEKCMSGLOB

#define THOUSAND	1000

extern LtDefineEntry ErrorTbl [];

extern LtDefineEntry AllocTbl [];

extern LtDefineEntry FormatTbl [];
#endif
