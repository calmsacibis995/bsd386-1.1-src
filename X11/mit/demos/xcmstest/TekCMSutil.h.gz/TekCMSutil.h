/* $XConsortum: TekCMSutil.h,v 1.1 91/02/11 19:40:54 dave Exp $ */

#ifndef TEKCMSUTIL
#define TEKCMSUTIL




extern void
fPrintXcmsColorSpec();
extern void
fPrintXcmsColorSpecs();
extern void
fPrintXcmsColors();
extern void
fPrintXcmsColorsWithComp();
extern void
PrintXcmsColors();
extern void
PrintXcmsColorsWithComp();
extern void
PrintXcmsColor();
extern void
PrintXcmsColorSpecs();
extern void
PrintXcmsColorSpec();
#endif
