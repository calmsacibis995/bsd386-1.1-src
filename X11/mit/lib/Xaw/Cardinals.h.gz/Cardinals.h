/* $XConsortium: Cardinals.h,v 1.5 89/03/30 16:05:19 jim Exp $ */
/*

Copyright 1985, 1986, 1987 by the Massachusetts Institute of Technology

Permission to use, copy, modify, and distribute this
software and its documentation for any purpose and without
fee is hereby granted, provided that the above copyright
notice appear in all copies and that both that copyright
notice and this permission notice appear in supporting
documentation, and that the name of M.I.T. not be used in
advertising or publicity pertaining to distribution of the
software without specific, written prior permission.
M.I.T. makes no representations about the suitability of
this software for any purpose.  It is provided "as is"
without express or implied warranty.

*/

#ifndef _Cardinals_h
#define _Cardinals_h

#define ZERO	((Cardinal)0)
#define ONE	((Cardinal)1)
#define TWO	((Cardinal)2)
#define THREE	((Cardinal)3)
#define FOUR	((Cardinal)4)
#define FIVE	((Cardinal)5)
#define SIX	((Cardinal)6)
#define SEVEN	((Cardinal)7)
#define EIGHT	((Cardinal)8)
#define NINE	((Cardinal)9)
#define TEN	((Cardinal)10)

#endif /* _Cardinals_h */
