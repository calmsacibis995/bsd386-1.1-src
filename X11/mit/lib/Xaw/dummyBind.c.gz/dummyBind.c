/* libXaw: dummyBind.c
 *
 * This dummy function is only linked to the client if the client
 * doesn't supply one
 * Copyright (c) 1992, 1993 by Thomas Wolfram, Berlin, Germany
 * (thomas@aeon.in-berlin.de, wolf@prz.tu-berlin.de)
 *
 * $XFree86: mit/lib/Xaw/dummyBind.c,v 1.2 1993/03/27 09:11:02 dawes Exp $
 */

void _bind_to_sv3shlib_()
{
   /* do nothing */

}

