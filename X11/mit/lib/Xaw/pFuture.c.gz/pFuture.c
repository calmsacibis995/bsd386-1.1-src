/* libXaw : pFuture.c
 * ------------------
 *
 * Copyright (c) 1992, 1993 by Thomas Wolfram, Berlin, Germany
 * (thomas@aeon.in-berlin.de, wolf@prz.tu-berlin.de)
 *
 * $XFree86: mit/lib/Xaw/pFuture.c,v 1.3 1993/03/20 03:33:52 dawes Exp $
 */

#include <X11/IntrinsicP.h>

#ifdef SVR3SHLIB

WidgetClass __futureWidgetClass_0_ = 0;
WidgetClass __futureWidgetClass_1_ = 0;
WidgetClass __futureWidgetClass_2_ = 0;
WidgetClass __futureWidgetClass_3_ = 0;
WidgetClass __futureWidgetClass_4_ = 0;
WidgetClass __futureWidgetClass_5_ = 0;
WidgetClass __futureWidgetClass_6_ = 0;
WidgetClass __futureWidgetClass_7_ = 0;
WidgetClass __futureWidgetClass_8_ = 0;
WidgetClass __futureWidgetClass_9_ = 0;
WidgetClass __futureWidgetClass_10_ = 0;
WidgetClass __futureWidgetClass_11_ = 0;
WidgetClass __futureWidgetClass_12_ = 0;
WidgetClass __futureWidgetClass_13_ = 0;
WidgetClass __futureWidgetClass_14_ = 0;
WidgetClass __futureWidgetClass_15_ = 0;
WidgetClass __futureWidgetClass_16_ = 0;
WidgetClass __futureWidgetClass_17_ = 0;
WidgetClass __futureWidgetClass_18_ = 0;
WidgetClass __futureWidgetClass_19_ = 0;

char __libXaw_sp2__[32] = "";

#endif
