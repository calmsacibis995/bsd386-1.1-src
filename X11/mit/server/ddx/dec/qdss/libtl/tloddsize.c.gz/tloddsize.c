#if 0
The functionality of tlOddSize has been merged
with qdPolyFillBoxesOddSize in ../qdfill.c.
#endif

