#ifdef XDEBUG
#define debug(x)    printf x
#else
#define debug(x)
#endif

#define debug1	debug
#define debug2	debug
#define debug3	debug
#define debug4	debug
#define debug5	debug
#define debug6	debug
#define debug7	debug
#define debug8	debug
#define debug9	debug
#define debug10	debug
#define debug11	debug
#define debug12	debug
#define debug13	debug
