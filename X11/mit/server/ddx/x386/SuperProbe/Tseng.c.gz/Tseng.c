/*
 * Copyright 1993 by David Wexelblat <dwex@goblin.org>
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of David Wexelblat not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  David Wexelblat makes no representations
 * about the suitability of this software for any purpose.  It is provided
 * "as is" without express or implied warranty.
 *
 * DAVID WEXELBLAT DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL DAVID WEXELBLAT BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 */

/* $XFree86: mit/server/ddx/x386/SuperProbe/Tseng.c,v 2.2 1993/09/21 15:20:50 dawes Exp $ */

#include "Probe.h"

static Word Ports[] = {0x000, 0x000, 0x000, 0x3BF, 0x3CD};
#define NUMPORTS (sizeof(Ports)/sizeof(Word))

Chip_Descriptor Tseng_Descriptor = {
	"Tseng",
	Probe_Tseng,
	Ports,
	NUMPORTS,
	FALSE,
	FALSE,
	TRUE
};

#ifdef __STDC__
Bool Probe_Tseng(int *Chipset)
#else
Bool Probe_Tseng(Chipset)
int *Chipset;
#endif
{
	Bool result = FALSE;
	Byte old, old1;

	/* Add CRTC to enabled ports */
	Ports[0] = CRTC_IDX;
	Ports[1] = CRTC_REG;
	Ports[2] = inp(0x3CC) & 0x01 ? 0x3D8 : 0x3B8;
	EnableIOPorts(NUMPORTS, Ports);
	old = inp(0x3BF);
	old1 = inp(Ports[2]);
	outp(0x3BF, 0x03);
	outp(Ports[2], 0xA0);
	if (tstrg(0x3CD, 0x3F)) 
	{
		/* 
		 * It is a Tseng; now figure out which one, and
		 * set Chipset.
		 */
		result = TRUE;
		if (!testinx(CRTC_IDX, 0x1B))
		{
			if (testinx2(CRTC_IDX, 0x30, 0x1F))
			{
				*Chipset = CHIP_ET4000_W32;
			}
			else
			{
				*Chipset = CHIP_ET4000;
			}
		}
		else
		{
			*Chipset = CHIP_ET3000;
		}
	}
	outp(Ports[2], old1);
	outp(0x3BF, old);
	DisableIOPorts(NUMPORTS, Ports);
	return(result);
}
