/***************************************************************************
 * Start of VGA font saving and restoration code.
 * Created: Sun Jun 27 12:50:09 1993 by faith@cs.unc.edu
 *
 * Reference used:
 *   "VGA WONDER Programmer's Reference,"
 *      ATI Technologies, 1991.
 *      Release 1.2 -- Reference #PRG28800
 *      (Part No. 10709B0412)
 *
 * Some code from x386/vga256/drivers/ati/driver.c, which was written by:
 * Thomas Roell (roell@informatik.tu-muenchen.de), Per Lindqvist
 * (pgd@compuram.bbt.se), Doug Evans (dje@sspiff.UUCP), and Rik Faith
 * (faith@cs.unc.edu).
 *
 * Copyright 1990,91 by Thomas Roell, Dinkelscherben, Germany.
 * Copyright 1993 by Rickard E. Faith
 * Copyright 1993 by Kevin E. Martin, Chapel Hill, North Carolina.
 *
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of Thomas Roell not be used
 * in advertising or publicity pertaining to distribution of the software
 * without specific, written prior permission.  Thomas Roell makes no
 * representations about the suitability of this software for any purpose.
 * It is provided "as is" without express or implied warranty.
 *
 * THOMAS ROELL, PER LINDQVIST, DOUG EVANS, RICKARD E. FAITH AND KEVIN
 * E. MARTIN DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL THOMAS ROELL, PER LINDQVIST, DOUG EVANS, RICKARD E. FAITH
 * OR KEVIN E. MARTIN BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
 * THIS SOFTWARE.
 *
 * Modified for the Mach32 by Kevin E. Martin (martin@cs.unc.edu)
 */

/* $XFree86: mit/server/ddx/x386/accel/mach32/ativga.c,v 2.5 1993/10/02 07:14:19 dawes Exp $ */

#include "X.h"
#include "misc.h"
#include "input.h"
#include "os.h"
#include "xf86_OSlib.h"
#include "regmach32.h"

#if !defined(linux) && !defined(SVR4) && !defined(SYSV)
#define SAVE_TEXT
#endif
#define SAVE_FONT1

typedef struct {
   unsigned char MiscOutReg;
   unsigned char CRTC[25];	/* Crtc Controller */
   unsigned char Sequencer[5];	/* video Sequencer */
   unsigned char Graphics[9];	/* Video Graphics */
   unsigned char Attribute[21]; /* Video Atribute */
   unsigned char DAC[768];	/* Internal Colorlookuptable */
   void          *FontInfo1;	/* Fonts */
   unsigned char *TextInfo;	/* Screen text */
   unsigned char ATIExtRegBank[11]; /* ATI Registers B0,B1,B2,B3,
				       B5, B6,B8,B9, BE,A6,A7 */
} SaveBlock;

pointer               vgaBase  = NULL;

static SaveBlock      save      = { 0, };
static short          ATIExtReg = 0x1ce;
unsigned short vgaIOBase;

#define ER_B0   0               /* Extended Register indices (ATIExtRegBank) */
#define ER_B1   1
#define ER_B2   2
#define ER_B3   3
#define ER_B5   4
#define ER_B6   5
#define ER_B8   6
#define ER_B9   7
#define ER_BE   8
#define ER_A6   9
#define ER_A7   10

#define ATIReg0  ATIExtRegBank[ER_B0]
#define ATIReg1  ATIExtRegBank[ER_B1]
#define ATIReg2  ATIExtRegBank[ER_B2]
#define ATIReg3  ATIExtRegBank[ER_B3]
#define ATIReg5  ATIExtRegBank[ER_B5]
#define ATIReg6  ATIExtRegBank[ER_B6]
#define ATIReg8  ATIExtRegBank[ER_B8]
#define ATIReg9  ATIExtRegBank[ER_B9]
#define ATIRegE  ATIExtRegBank[ER_BE]
#define ATIRegA6 ATIExtRegBank[ER_A6]
#define ATIRegA7 ATIExtRegBank[ER_A7]

static int inATI(index)
     int index;
{
   outb(ATIExtReg, index);
   return inb(ATIExtReg + 1);
}

void mach32SaveVGAInfo(screen_idx)
     int screen_idx;
{
   unsigned char b2_save;
   unsigned char b8_save;
   int           i;

   if (!vgaBase) {
      vgaBase = xf86MapVidMem(screen_idx, VGA_REGION, (pointer)0xa0000,
			      64 * 1024);
   }

   /* The rest of this routine is mostly from ATISave() in
      x386/vga256/drivers/ati/driver.c */

   vgaIOBase = (inb(0x3cc) & 0x01) ? 0x3D0 : 0x3B0;
   
   /* Disable video */
   inb(vgaIOBase + 0x0A);	/* reset flip-flop */
   outb( 0x3c0, 0x00 );

   /* Unlock ATI specials */
   outb(ATIExtReg, (((b8_save = inATI(0xb8)) & 0xC0) << 8) | 0xb8);

   save.MiscOutReg = inb(0x3CC);

   b2_save = inATI(0xb2);
   outb(ATIExtReg, 0x00b2);	/* segment select 0 */

   save.ATIReg0  = inATI(0xb0);
   save.ATIReg1  = inATI(0xb1);
   save.ATIReg2  = b2_save;
   save.ATIReg3  = inATI(0xb3);
   save.ATIReg5  = inATI(0xb5);
   save.ATIReg6  = inATI(0xb6);
   save.ATIReg8  = b8_save;
   save.ATIRegE  = inATI(0xbe);
   save.ATIReg9  = inATI(0xb9);
   save.ATIRegA6 = inATI(0xa6);
   save.ATIRegA7 = inATI(0xa7);

   for (i=0; i<25; i++) {
      outb(vgaIOBase + 4,i);
      save.CRTC[i] = inb(vgaIOBase + 5);
   }
        
   for (i=0; i<21; i++) {
      inb(vgaIOBase + 0x0A); /* reset flip-flop */
      outb(0x3C0,i);
      save.Attribute[i] = inb(0x3C1);
   }

   for (i=0; i<9;  i++) {
      outb(0x3CE,i);
      save.Graphics[i]  = inb(0x3CF);
   }

   for (i=0; i<5;  i++) {
      outb(0x3C4,i);
      save.Sequencer[i] = inb(0x3C5);
   }
        
   /*                       
    * save the colorlookuptable 
    */
   outb(0x3C6,0xFF);
   outb(0x3C7,0x00);
   for (i=0; i<768; i++)
	 save.DAC[i] = inb(0x3C9); 

   /* Save fonts */

#ifdef SAVE_FONT1
   if (!save.FontInfo1)
	 save.FontInfo1 = (void *)xalloc(8192);
   inb(vgaIOBase + 0x0A);	/* reset flip-flop */
   outb(0x3C0,0x10); outb(0x3C0, 0x01); /* graphics mode */
   outw(0x3C4, 0x0402);			/* write to plane 2 */
   outw(0x3C4, 0x0604);			/* enable plane graphics */
   outw(0x3CE, 0x0204);			/* read plane 2 */
   outw(0x3CE, 0x0005);			/* write mode 0, read mode 0 */
   outw(0x3CE, 0x0506);			/* set graphics */
   bcopy(vgaBase, save.FontInfo1, 8192);
#endif /* SAVE_FONT1 */

#ifdef SAVE_TEXT
   if (!save.TextInfo)
	save.TextInfo = (unsigned char *)xalloc(8192);
   inb(vgaIOBase + 0x0A);	/* reset flip-flop */
   outb(0x3C0,0x10); outb(0x3C0, 0x01); /* graphics mode */
   outw(0x3C4, 0x0102);			/* write to plane 0 */
   outw(0x3C4, 0x0604);			/* enable plane graphics */
   outw(0x3CE, 0x0004);			/* read plane 0 */
   outw(0x3CE, 0x0005);			/* write mode 0, read mode 0 */
   outw(0x3CE, 0x0506);			/* set graphics */
   bcopy(vgaBase, save.TextInfo, 4096);
   outw(0x3C4, 0x0202);			/* write to plane 1 */
   outw(0x3C4, 0x0604);			/* enable plane graphics */
   outw(0x3CE, 0x0104);			/* read plane 1 */
   outw(0x3CE, 0x0005);			/* write mode 0, read mode 0 */
   outw(0x3CE, 0x0506);			/* set graphics */
   bcopy(vgaBase, save.TextInfo + 4096, 4096);
#endif /* SAVE_TEXT */
          
   /* Enable video */
   inb(vgaIOBase + 0x0A); /* reset flip-flop */
   outb( 0x3c0, 0x20 );
}

void mach32RestoreVGAInfo()
{
   /* This routine is mostly from ATIRestore() in
      x386/vga256/drivers/ati/driver.c */

   int i;

   if (vgaIOBase == 0x3B0)
	 save.MiscOutReg &= 0xFE;
   else
	 save.MiscOutReg |= 0x01;

   /* Disable video */
   (void) inb(vgaIOBase + 0x0A); /* reset flip-flop */
   outb(0x3C0, 0x00);

   /* Unlock ATI specials */
   outw(ATIExtReg, ((inATI(0xb8) & 0xC0) << 8) | 0xb8);

   /* Load Miscellaneous Output External Register */
   outb(0x3C2, save.MiscOutReg);

   outw(ATIExtReg, 0x00b2);	/* segment select 0 */
   
   if (save.FontInfo1 || save.TextInfo) {
      inb(vgaIOBase + 0x0A);	/* reset flip-flop */
      outb(0x3C0,0x10); outb(0x3C0, 0x01); /* graphics mode */

      if (save.FontInfo1) {
	 outw(0x3C4, 0x0402);	/* write to plane 2 */
	 outw(0x3C4, 0x0604);	/* enable plane graphics */
	 outw(0x3CE, 0x0204);	/* read plane 2 */
	 outw(0x3CE, 0x0005);	/* write mode 0, read mode 0 */
	 outw(0x3CE, 0x0506);	/* set graphics */
	 bcopy(save.FontInfo1, vgaBase, 8192);
      }
      if (save.TextInfo) {
	 outw(0x3C4, 0x0102);	/* write to plane 0 */
	 outw(0x3C4, 0x0604);	/* enable plane graphics */
	 outw(0x3CE, 0x0004);	/* read plane 0 */
	 outw(0x3CE, 0x0005);	/* write mode 0, read mode 0 */
	 outw(0x3CE, 0x0506);	/* set graphics */
	 bcopy(save.TextInfo, vgaBase, 4096);
	 outw(0x3C4, 0x0202);	/* write to plane 1 */
	 outw(0x3C4, 0x0604);	/* enable plane graphics */
	 outw(0x3CE, 0x0104);	/* read plane 1 */
	 outw(0x3CE, 0x0005);	/* write mode 0, read mode 0 */
	 outw(0x3CE, 0x0506);	/* set graphics */
	 bcopy(save.TextInfo + 4096, vgaBase, 4096);
      }
   }
        
   /* This sequence is from the "VGA Wonder Programmer's
      Reference Manual."  I assume it is correct :-)
      faith@cs.unc.edu (7Aug92) */

   /* Place Sequencer into Reset condition using its Reset Register */
   outw(0x3C4, 0x0100);

   /* Load ATI Extended Registers */
   outw(ATIExtReg, (save.ATIReg0  << 8) | 0xb0);
   outw(ATIExtReg, (save.ATIReg1  << 8) | 0xb1);
   outw(ATIExtReg, (save.ATIReg2  << 8) | 0xb2);
   outw(ATIExtReg, (save.ATIReg5  << 8) | 0xb5);
   outw(ATIExtReg, (save.ATIReg6  << 8) | 0xb6);
   outw(ATIExtReg, (save.ATIRegE  << 8) | 0xbe);
   outw(ATIExtReg, (save.ATIReg3  << 8) | 0xb3);
   outw(ATIExtReg, (save.ATIReg8  << 8) | 0xb8);
   outw(ATIExtReg, (save.ATIReg9  << 8) | 0xb9);
   outw(ATIExtReg, (save.ATIRegA6 << 8) | 0xa6);
   outw(ATIExtReg, (save.ATIRegA7 << 8) | 0xa7);
   
   /* Load Miscellaneous Output External Register */
   outb(0x3C2, save.MiscOutReg);
   
   /* Load Sequence Registers 1 through 4 */
   for (i=1; i<5;  i++)
	 outw(0x3C4, (save.Sequencer[i] << 8) | i);

   /* Restart Sequencer using Reset Register */
   outw(0x3C4, 0x0300);
   
   /* Load all 25 CRT Control Registers */
   /* But first, unlock CRTC registers 0 to 7 */
   outw(vgaIOBase + 4, ((save.CRTC[0x11] & 0x7F) << 8) | 0x11);
   for (i=0; i<25; i++)
	 outw(vgaIOBase + 4,(save.CRTC[i] << 8) | i);

   /* Reset Attribute Controller address/data flip-flop */
   (void) inb(vgaIOBase + 0x0A);

   /* Load all 20 Attribute Controller Registers */
   for (i=0; i<21; i++) {
      (void) inb(vgaIOBase + 0x0A);
      outb(0x3C0,i);
      outb(0x3C0, save.Attribute[i]);
   }

   /* Load all 9 Graphics Controller Registers */
   for (i=0; i<9; i++)
	 outw(0x3CE, (save.Graphics[i] << 8) | i);

   /* Load all 768 DAC Registers */
   outb(0x3C8,0x00);
   for (i=0; i<768; i++)
	 outb(0x3C9, save.DAC[i]);

   /* Reset Attribute Controller address/data flip-flop */
   (void) inb(vgaIOBase + 0x0A);

   /* Turn Attribute Controller on */
   outb(0x3C0, 0x20);
        
}

/*
 * End of VGA font saving and restoration code.
 *
 ***************************************************************************/
