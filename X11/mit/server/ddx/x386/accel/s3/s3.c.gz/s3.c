/*
 * Copyright 1990,91 by Thomas Roell, Dinkelscherben, Germany.
 * 
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Thomas Roell not be used in
 * advertising or publicity pertaining to distribution of the software
 * without specific, written prior permission.  Thomas Roell makes no
 * representations about the suitability of this software for any purpose. It
 * is provided "as is" without express or implied warranty.
 * 
 * THOMAS ROELL AND KEVIN E. MARTIN DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL THOMAS ROELL OR KEVIN E. MARTIN BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * Author:  Thomas Roell, roell@informatik.tu-muenchen.de
 * 
 * Rewritten for the 8514/A by Kevin E. Martin (martin@cs.unc.edu)
 * 
 * Header: /home/src/xfree86/mit/server/ddx/x386/accel/s3/RCS/s3.c,v 2.0
 * 1993/02/22 05:58:13 jon Exp
 * 
 * Modified by Amancio Hasty and Jon Tombs
 * 
 * Id: s3.c,v 2.6 1993/08/09 06:17:57 jon Exp jon
 */

/* $XFree86: mit/server/ddx/x386/accel/s3/s3.c,v 2.51 1993/10/16 17:31:09 dawes Exp $ */

#include "cfb.h"
#include "pixmapstr.h"
#include "fontstruct.h"
#include "s3.h"
#include "regs3.h"
#include "s3bcach.h"
#include "s3pcach.h"
#include "xf86_HWlib.h"
#define XCONFIG_FLAGS_ONLY
#include "xf86_Config.h"
#include "vga.h"
#include "s3linear.h"
#include "s3Bt485.h"

extern int s3MaxClock, s3MaxBt485Clock;
char s3Mbanks;
extern void NoopDDA();
void s3PrintIdent();

extern s3VideoChipPtr s3Drivers[];

int vgaInterlaceType = VGA_DIVIDE_VERT;
void (*vgaSaveScreenFunc)() = NoopDDA;

ScrnInfoRec s3InfoRec =
{
   FALSE,			/* Bool configured */
   -1,				/* int tmpIndex */
   -1,				/* int scrnIndex */
   s3Probe,			/* Bool (* Probe)() */
   (Bool (*)())NoopDDA,		/* Bool (* Init)() */
   NoopDDA,			/* void (* EnterLeaveVT)() */
   NoopDDA,			/* void (* EnterLeaveMonitor)() */
   NoopDDA,			/* void (* EnterLeaveCursor)() */
   NoopDDA,			/* void (* AdjustFrame)() */
   (Bool (*)())NoopDDA,		/* Bool (* SwitchMode)() */
   s3PrintIdent,		/* void (* PrintIdent)() */
   8,				/* int depth */
   8,				/* int bitsPerPixel */
   PseudoColor,			/* int defaultVisual */
   -1, -1,			/* int virtualX,virtualY */
   -1, -1, -1, -1,		/* int frameX0, frameY0, frameX1, frameY1 */
   {0,},			/* OFlagSet options */
   {0,},			/* OFlagSet clockOptions */   
   {0, },              		/* OFlagSet xconfigFlag */
   NULL,			/* char *chipset */
   0,				/* int clocks */
   {0,},			/* int clock[MAXCLOCKS] */
   0,				/* int maxClock */
   0,				/* int videoRam */
   0xC0000,                     /* int BIOSbase */  
   240, 180,			/* int width, height */
   0,				/* unsigned long  speedup */
   NULL,			/* DisplayModePtr modes */   
   NULL,			/* char           *clockprog */
   -1,			        /* int textclock */
   FALSE,			/* Bool           bankedMono */
   "S3",			/* char           *name */
   {0, },			/* RgbRec blackColour */
   {0, },			/* RgbRec whiteColour */
   s3ValidTokens,		/* int *validTokens */
   S3_PATCHLEVEL,		/* char *patchlevel */
};

short s3alu[16] =
{
   MIX_0,
   MIX_AND,
   MIX_SRC_AND_NOT_DST,
   MIX_SRC,
   MIX_NOT_SRC_AND_DST,
   MIX_DST,
   MIX_XOR,
   MIX_OR,
   MIX_NOR,
   MIX_XNOR,
   MIX_NOT_DST,
   MIX_SRC_OR_NOT_DST,
   MIX_NOT_SRC,
   MIX_NOT_SRC_OR_DST,
   MIX_NAND,
   MIX_1
};

static unsigned S3_IOPorts[] = {
	0x42E8, 0x4AE8, 0x82E8, 0x86E8, 0x8AE8, 0x8EE8, 0x92E8, 0x96E8,
	0x9AE8, 0x9EE8, 0xA2E8, 0xA6E8, 0xAAE8, 0xAEE8, 0xB2E8, 0xB6E8,
	0xBAE8, 0xBEE8, 0xE2E8, 0xE2EA,
};
static int Num_S3_IOPorts = (sizeof(S3_IOPorts)/sizeof(S3_IOPorts[0]));

extern miPointerScreenFuncRec x386PointerScreenFuncs;
Bool  (*s3ClockSelectFunc) ();
static Bool LegendClockSelect();
static Bool s3ClockSelect();
static Bool icd2061ClockSelect();
ScreenPtr s3savepScreen;
Bool  s3Localbus = FALSE;
Bool  s3LinearAperture = FALSE;
Bool  s3Mmio928 = FALSE;
unsigned char s3LinApOpt;
int s3BankSize;
int s3DisplayWidth;
pointer vgaBase = NULL;
pointer s3VideoMem = NULL;

extern Bool x386Exiting, x386Resetting, x386ProbeFailed, x386Verbose;

static Bool AlreadyInited = FALSE;
static Bool s3ModeSwitched = FALSE;

int s3ScissB;
unsigned char s3SwapBits[256];
unsigned char s3Port40;
unsigned char s3Port51;
unsigned char s3Port54;
void (*s3ImageReadFunc)();
void (*s3ImageWriteFunc)();
void (*s3ImageFillFunc)();
int s3MAX_SLOTS;
int s3FC_MAX_HEIGHT = 32;
CacheFont8Ptr s3HeadFont, s3FontCache;
int s3hotX, s3hotY;
Bool s3BlockCursor, s3ReloadCursor;


/*
 * s3PrintIdent -- print identification message
 */
void
s3PrintIdent()
{
  int i, j, n = 0, c = 0;
  char *id;

  ErrorF("  %s: accelerated server for S3 graphics adaptors (Patchlevel %s)\n",
	 s3InfoRec.name, s3InfoRec.patchLevel);

  ErrorF("      ");
  for (i = 0; s3Drivers[i]; i++)
    for (j = 0; id = (s3Drivers[i]->ChipIdent)(j); j++, n++)
    {
      if (n)
      {
        ErrorF(",");
        c++;
        if (c + 1 + strlen(id) < 70)
        {
          ErrorF(" ");
          c++;
        }
        else
        {
          ErrorF("\n      ");
          c = 0;
        }
      }
      ErrorF("%s", id);
      c += strlen(id);
    }
  ErrorF("\n");
}

/*
 * s3Probe -- probe and initialize the hardware driver
 */
Bool
s3Probe()
{
   DisplayModePtr pMode, pEnd;
   unsigned char config, tmp;
   int i, j, numClocks;
   int tx, ty;
   OFlagSet validOptions;

   xf86ClearIOPortList(s3InfoRec.scrnIndex);
   xf86AddIOPorts(s3InfoRec.scrnIndex, Num_VGA_IOPorts, VGA_IOPorts);
   xf86AddIOPorts(s3InfoRec.scrnIndex, Num_S3_IOPorts, S3_IOPorts);

   /* Enable I/O access */
   xf86EnableIOPorts(s3InfoRec.scrnIndex);

   vgaIOBase = (inb(0x3CC) & 0x01) ? 0x3D0 : 0x3B0;
   vgaCRIndex = vgaIOBase + 4;
   vgaCRReg = vgaIOBase + 5;

   outb(vgaCRIndex, 0x11);	/* for register CR11, (Vertical Retrace End) */
   outb(vgaCRReg, 0x00);		/* set to 0 */

   outb(vgaCRIndex, 0x38);		/* check if we have an S3 */
   outb(vgaCRReg, 0x00);

   /* Make sure we can't write when locked */

   if (testinx2(vgaCRIndex, 0x35, 0x0f)) {
      xf86DisableIOPorts(s3InfoRec.scrnIndex);
      return(FALSE);
   }
 
   outb(vgaCRIndex, 0x38);	/* for register CR38, (REG_LOCK1) */
   outb(vgaCRReg, 0x48);	/* unlock S3 register set for read/write */

   /* Make sure we can write when unlocked */

   if (!testinx2(vgaCRIndex, 0x35, 0x0f)) {
      xf86DisableIOPorts(s3InfoRec.scrnIndex);
      return(FALSE);
   }

   outb(vgaCRIndex, 0x36);		/* for register CR36 (CONFG_REG1), */
   config = inb(vgaCRReg);		/* get amount of vram installed */

   outb(vgaCRIndex, 0x30);
   s3ChipId = inb(vgaCRReg);         /* get chip id */

   if (!S3_ANY_SERIES(s3ChipId)) {
      ErrorF("%s %s: Unknown S3 chipset: chip_id = 0x%02x\n", 
	     XCONFIG_PROBED,s3InfoRec.name,s3ChipId);
      xf86DisableIOPorts(s3InfoRec.scrnIndex);
      return(FALSE);
   }

   for (i = 0; s3Drivers[i]; i++) {
      if ((s3Drivers[i]->ChipProbe)()) {
	 x386ProbeFailed = FALSE;
	 s3InfoRec.Init = s3Drivers[i]->ChipInitialize;
	 s3InfoRec.EnterLeaveVT = s3Drivers[i]->ChipEnterLeaveVT;
	 s3InfoRec.AdjustFrame = s3Drivers[i]->ChipAdjustFrame;
	 s3InfoRec.SwitchMode = s3Drivers[i]->ChipSwitchMode;
	 break;
      }
   }
   if (x386ProbeFailed) {
      if (s3InfoRec.chipset) {
	 ErrorF("%s: '%s' is an invalid chipset", s3InfoRec.name,
		s3InfoRec.chipset);
      }
      xf86DisableIOPorts(s3InfoRec.scrnIndex);
      return(FALSE);
   }

   OFLG_ZERO(&validOptions);
   OFLG_SET(OPTION_LEGEND, &validOptions);
   OFLG_SET(OPTION_NOLINEAR_MODE, &validOptions);
   OFLG_SET(OPTION_NO_MEM_ACCESS, &validOptions);
   OFLG_SET(OPTION_MEM_ACCESS, &validOptions);
   OFLG_SET(OPTION_BT485, &validOptions);
   OFLG_SET(OPTION_NO_BT485, &validOptions);
   OFLG_SET(OPTION_BT485_CURS, &validOptions);
   OFLG_SET(OPTION_SHOWCACHE, &validOptions);
   xf86VerifyOptions(&validOptions, &s3InfoRec);
   if (OFLG_ISSET(OPTION_MEM_ACCESS, &s3InfoRec.options) &&
       OFLG_ISSET(OPTION_NO_MEM_ACCESS, &s3InfoRec.options)) {
      ErrorF("%s: Warning: Options \"memaccess\" and \"nomemaccess\" are ",
	     s3InfoRec.name);
      ErrorF("incompatible.\n\t\"nomemaccess\" will be assumed.\n");
   }

   s3Localbus = ((config & 0x03) == 1);

   if (x386Verbose) {
      if ((config & 0x03) == 0) {
         ErrorF("%s %s: card type: EISA\n",
              XCONFIG_PROBED, s3InfoRec.name);
      }
      if (s3Localbus) {
         ErrorF("%s %s: card type: 386/486 localbus\n",
              XCONFIG_PROBED, s3InfoRec.name);
      }
      if ((config & 0x03) == 3) {
         ErrorF("%s %s: card type: ISA\n",
	      XCONFIG_PROBED, s3InfoRec.name);
      }
   }

   if (x386Verbose) {
      if (S3_801_928_SERIES(s3ChipId)) {
	 if (S3_801_SERIES(s3ChipId)) {
	    if (!((config & 0x03) == 3))
		ErrorF("%s %s: chipset:   805\n",
                   XCONFIG_PROBED, s3InfoRec.name);
	    else
		ErrorF("%s %s: chipset:   801\n",
                   XCONFIG_PROBED, s3InfoRec.name);
	 } else if (S3_928_SERIES(s3ChipId)) {
	    ErrorF("%s %s: chipset:   928 \n",
                   XCONFIG_PROBED, s3InfoRec.name);
	 }
      } else if (S3_911_SERIES(s3ChipId)) {
	 if (S3_911_ONLY(s3ChipId)) {
	    ErrorF("%s %s: chipset:   911 \n",
                   XCONFIG_PROBED, s3InfoRec.name);
	 } else if (S3_924_ONLY(s3ChipId)) {
	    ErrorF("%s %s: chipset:   924\n",
                   XCONFIG_PROBED, s3InfoRec.name);
	 } else {
	    ErrorF("%s %s: S3 chipset type unknown, chip_id = 0x%02x\n",
		   XCONFIG_PROBED, s3InfoRec.name, s3ChipId);
	 }
      }
   }

   if (x386Verbose) {
      ErrorF("%s %s: chipset driver: %s\n",
	     OFLG_ISSET(XCONFIG_CHIPSET, &s3InfoRec.xconfigFlag) ?
		XCONFIG_GIVEN : XCONFIG_PROBED,
	     s3InfoRec.name, s3InfoRec.chipset);
   }

   if (!s3InfoRec.videoRam) {
      if ((config & 0x20) != 0) {	/* if bit 5 is a 1, then 512k RAM */
	 s3InfoRec.videoRam = 512;
      } else {			/* must have more than 512k */
	 if (S3_911_SERIES(s3ChipId)) {
	    s3InfoRec.videoRam = 1024;
	 } else {
	    switch ((config & 0xC0) >> 6) {	/* look at bits 6 and 7 */
	       case 0:
	         s3InfoRec.videoRam = 4096;
		 break;
	       case 1:
	         s3InfoRec.videoRam = 3072;
		 break;
	       case 2:
		 s3InfoRec.videoRam = 2048;
	         break;
	       case 3:
	         s3InfoRec.videoRam = 1024;
		 break;
	    }
	 }
      }
      if (x386Verbose) {
         ErrorF("%s %s: videoram:  %dk",
              XCONFIG_PROBED, s3InfoRec.name, s3InfoRec.videoRam);
      }
   } else {
      if (x386Verbose) {
	 ErrorF("%s %s: videoram:  %dk", 
              XCONFIG_GIVEN, s3InfoRec.name, s3InfoRec.videoRam);
      }
   }
   if (s3InfoRec.videoRam > 1024)
      s3Mbanks = -1;
   else
      s3Mbanks = 0;

   if (OFLG_ISSET(OPTION_LEGEND, &s3InfoRec.options)) {
      s3ClockSelectFunc = LegendClockSelect;
      numClocks = 32;
   } else {
      s3ClockSelectFunc = s3ClockSelect;
      numClocks = 16;
   }

   if (OFLG_ISSET(CLOCK_OPTION_ICD2061A, &s3InfoRec.clockOptions)) {
      s3ClockSelectFunc = icd2061ClockSelect;
      if (x386Verbose)
         ErrorF("\n%s %s: Using ICD2061A programmable clock\n",
            XCONFIG_GIVEN, s3InfoRec.name);
      numClocks = 3;
   } else if (OFLG_ISSET(CLOCK_OPTION_ICD2061ASL, &s3InfoRec.clockOptions)) {
      s3ClockSelectFunc = icd2061ClockSelect;
      if (x386Verbose)
         ErrorF("\n%s %s: Using slow ICD2061A programmable clock\n",
            XCONFIG_GIVEN, s3InfoRec.name);
      numClocks = 3;
   } else if (!s3InfoRec.clocks) 
      vgaGetClocks(numClocks, s3ClockSelectFunc);

   if (x386Verbose) {
      if (! OFLG_ISSET(CLOCK_OPTION_PROGRAMABLE, &s3InfoRec.clockOptions)) {
	 for (j = 0; j < s3InfoRec.clocks; j++) {
	    if ((j % 8) == 0)
               ErrorF("\n%s %s: clocks:",
                OFLG_ISSET(XCONFIG_CLOCKS,&s3InfoRec.xconfigFlag) ?
                    XCONFIG_GIVEN : XCONFIG_PROBED , 
                s3InfoRec.name);
	    ErrorF(" %6.2f", (double)s3InfoRec.clock[j] / 1000.0);
         }
         ErrorF("\n");
      } 
   }

   /*
    * Handle Bt485.
    */
   if (OFLG_ISSET(OPTION_BT485, &s3InfoRec.options)) {
      if (!S3_801_928_SERIES(s3ChipId)) {
         ErrorF("%s %s: Bt485 cannot be supported on 911/924\n",
	        XCONFIG_PROBED, s3InfoRec.name);
	 OFLG_CLR(OPTION_BT485, &s3InfoRec.options);
      } else {
         ErrorF("%s %s: Programming for BrookTree Bt485 RAMDAC\n",
	        XCONFIG_GIVEN, s3InfoRec.name);
      }
   } else if ((!OFLG_ISSET(OPTION_NO_BT485, &s3InfoRec.options)) &&
	      (S3_801_928_SERIES(s3ChipId))) {
      /*
       * Probe for the bloody thing.  Set 0x3C6 to a bogus value, then
       * try to get the Bt485 status register.  If it's there, then we will
       * get something else back from this port.
       */
      tmp = inb(0x3C6);
      outb(0x3C6, 0xFF);
      if ((s3InBtStatReg() & 0xC0) == 0x80) {
	 /*
	  * Found it.
	  */
	 ErrorF("%s %s: Detected a BrookTree Bt485 RAMDAC\n",
	        XCONFIG_PROBED, s3InfoRec.name);
	 OFLG_SET(OPTION_BT485, &s3InfoRec.options);
      }
      outb(0x3C6, tmp);
   }
   if (OFLG_ISSET(OPTION_BT485_CURS, &s3InfoRec.options)) {
      if (OFLG_ISSET(OPTION_NO_BT485, &s3InfoRec.options)) {
         ErrorF("%s %s: Use of Bt485 disabled in Xconfig; won't use cursor\n",
	        XCONFIG_GIVEN, s3InfoRec.name);
	 OFLG_CLR(OPTION_BT485_CURS, &s3InfoRec.options);
      } else {
	 if (!S3_928_SERIES(s3ChipId)) {
            ErrorF("%s %s: Bt485 is only supported on 928 boards\n",
	           XCONFIG_PROBED, s3InfoRec.name);
	    OFLG_CLR(OPTION_BT485_CURS, &s3InfoRec.options);
	 } else {
            ErrorF("%s %s: Using hardware cursor from Bt485 RAMDAC\n",
	           XCONFIG_GIVEN, s3InfoRec.name);
	    if (!OFLG_ISSET(OPTION_BT485, &s3InfoRec.options)) {
               ErrorF("%s %s: Assuming Bt485 is present\n",
	              XCONFIG_PROBED, s3InfoRec.name);
	       OFLG_SET(OPTION_BT485, &s3InfoRec.options);
	    }
	 }
      }
   }

   if (OFLG_ISSET(OPTION_BT485, &s3InfoRec.options))
      s3InfoRec.maxClock = s3MaxBt485Clock;
   else
      s3InfoRec.maxClock = s3MaxClock;

   tx = s3InfoRec.virtualX;
   ty = s3InfoRec.virtualY;
   pMode = pEnd = s3InfoRec.modes;
   do {
      x386LookupMode(pMode, &s3InfoRec);
      if ((pMode->HDisplay * (1 + pMode->VDisplay)) >
	  s3InfoRec.videoRam * 1024) {
	 ErrorF("%s: Too little memory for mode %s\n", s3InfoRec.name,
		pMode->name);
	 ErrorF("%s: NB. 1 scan line is required for the hardware cursor\n",
	        s3InfoRec.name);
	 xf86DisableIOPorts(s3InfoRec.scrnIndex);
	 return (FALSE);
      }
      s3InfoRec.virtualX = max(s3InfoRec.virtualX, pMode->HDisplay);
      s3InfoRec.virtualY = max(s3InfoRec.virtualY, pMode->VDisplay);
      pMode = pMode->next;
   } while (pMode != pEnd);
   if ((tx != s3InfoRec.virtualX) || (ty != s3InfoRec.virtualY))
      OFLG_CLR(XCONFIG_VIRTUAL,&s3InfoRec.xconfigFlag);

 /*
  * It would seem the S3 can only do two accelarated screen widths
  */
   if (s3InfoRec.virtualX <= 1024) {
      s3DisplayWidth = 1024;
   } else if (s3InfoRec.virtualX <= 1280) {
      if (S3_911_SERIES(s3ChipId)) {
	 ErrorF("%s: Unsupported width for the S3 911 series chipsets\n",
		s3InfoRec.name);
	 ErrorF("%s: Maximum supported width is 1024\n", s3InfoRec.name);
	 xf86DisableIOPorts(s3InfoRec.scrnIndex);
	 return (FALSE);
      }
      s3DisplayWidth = 1280;
   } else {
      ErrorF("%s: Illegal screen size: (%dx%d)\n", s3InfoRec.name,
	     s3InfoRec.virtualX, s3InfoRec.virtualY);
      ErrorF("  Virtual width must be no greater than 1280\n");
      xf86DisableIOPorts(s3InfoRec.scrnIndex);
      return (FALSE);
   }
   if ((s3DisplayWidth * (1 + s3InfoRec.virtualY)) > s3InfoRec.videoRam * 1024) {
      ErrorF("%s %s: Display size %dx%d is too large: ", 
             OFLG_ISSET(XCONFIG_VIRTUAL,&s3InfoRec.xconfigFlag) ?
                 XCONFIG_GIVEN : XCONFIG_PROBED,
             s3InfoRec.name,
	     s3DisplayWidth, s3InfoRec.virtualY);
      xf86DisableIOPorts(s3InfoRec.scrnIndex);
      return (FALSE);
   }
   if (x386Verbose) {
      ErrorF("%s %s: Virtual resolution set to %dx%d\n", 
             OFLG_ISSET(XCONFIG_VIRTUAL,&s3InfoRec.xconfigFlag) ?
                 XCONFIG_GIVEN : XCONFIG_PROBED,
             s3InfoRec.name,
	     s3InfoRec.virtualX, s3InfoRec.virtualY);
   }

   return TRUE;
}

static Bool
s3ClockSelect(no)
     int   no;

{
   unsigned char temp;
   static unsigned char save1, save2;
 
   UNLOCK_SYS_REGS;
   
   switch(no)
   {
   case CLK_REG_SAVE:
      save1 = inb(0x3CC);
      outb(vgaCRIndex, 0x42);
      save2 = inb(vgaCRReg);
      break;
   case CLK_REG_RESTORE:
      outb(0x3C2, save1);
      outb(vgaCRIndex, 0x42);
      outb(vgaCRReg, save2);
      break;
   default:
      if (no == 0x03)
      {
	 /*
	  * Clock index 3 is a 0Hz clock on all the S3-recommended 
	  * synthesizers (except the Chrontel).  A 0Hz clock will lock up 
	  * the chip but good (requiring power to be cycled).  Nuke that.
	  */
         LOCK_SYS_REGS;
	 return(FALSE);
      }
      temp = inb(0x3CC);
      outb(0x3C2, temp | 0x0C);
      outb(vgaCRIndex, 0x42);
      outb(vgaCRReg, no);
      usleep(150000);
   }
   LOCK_SYS_REGS;
   return(TRUE);
}

static Bool
LegendClockSelect(no)
     int   no;
{

 /*
  * Sigma Legend special handling
  * 
  * The Legend uses an ICS 1394-046 clock generator.  This can generate 32
  * different frequencies.  The Legend can use all 32.  Here's how:
  * 
  * There are two flip/flops used to latch two inputs into the ICS clock
  * generator.  The five inputs to the ICS are then
  * 
  * ICS     ET-4000 ---     --- FS0     CS0 FS1     CS1 FS2     ff0 flip/flop 0
  * outbut FS3     CS2 FS4     ff1     flip/flop 1 outbut
  * 
  * The flip/flops are loaded from CS0 and CS1.  The flip/flops are latched by
  * CS2, on the rising edge. After CS2 is set low, and then high, it is then
  * set to its final value.
  * 
  */
   static unsigned char save1, save2;
   unsigned char temp = inb(0x3CC);

   switch(no)
   {
   case CLK_REG_SAVE:
      save1 = inb(0x3CC);
      outb(vgaCRIndex, 0x34);
      save2 = inb(vgaCRReg);
      break;
   case CLK_REG_RESTORE:
      outb(0x3C2, save1);
      outw(vgaCRIndex, 0x34 | (save2 << 8));
      break;
   default:
      outb(0x3C2, (temp & 0xF3) | ((no & 0x10) >> 1) | (no & 0x04));
      outw(vgaCRIndex, 0x0034);
      outw(vgaCRIndex, 0x0234);
      outw(vgaCRIndex, ((no & 0x08) << 6) | 0x34);
      outb(0x3C2, (temp & 0xF3) | ((no << 2) & 0x0C));
   }
   return(TRUE);
}

static Bool
icd2061ClockSelect(no)
     int   no;
{
   long  clockNo;
   long  freq;
   Bool result = TRUE;

   UNLOCK_SYS_REGS;
   switch(no)
   {
   case CLK_REG_SAVE:
   case CLK_REG_RESTORE:
      result = s3ClockSelect(no);
      break;
   default:
      if (no < 2) {
         result = s3ClockSelect(no);
      } else {
	 if (no >= s3InfoRec.clocks) {
	    ErrorF("%s: Clock number too high (%d)\n", s3InfoRec.name, no);
	    result = FALSE;
	    break;
	 }
	 /* Start with freq in kHz */
	 freq = s3InfoRec.clock[no];
	 if (OFLG_ISSET(OPTION_BT485, &s3InfoRec.options)) {
	    if (freq > s3MaxBt485Clock) {
	       ErrorF("%s %s: Specified dot clock (%7.3f) too high for Bt485.",
		      XCONFIG_PROBED, s3InfoRec.name, freq / 1000.0);
	       ErrorF("\tUsing %7.3Mhz\n", s3MaxBt485Clock / 1000.0);
	       freq = s3MaxBt485Clock;
            }
	    if (freq > 67500) {
	       /* Use Bt485 clock doubler - Bit 3 of Command Reg 3 */
	       freq /= 2;
	       s3OutBtRegCom3(0xF7, 0x08);
	    } else {
	       /* No doubler */
	       s3OutBtRegCom3(0xF7, 0x00);
	    }
	 } else {
	    if (freq > s3MaxClock) {
	       ErrorF("%s %s: Specified dot clock (%7.3f) too high for RAMDAC.",
		      XCONFIG_PROBED, s3InfoRec.name, freq / 1000.0);
	       ErrorF("\tUsing %7.3MHz\n", s3MaxClock / 1000.0);
	       freq = s3MaxClock;
	    }
         }
	 /* Convert freq to Hz */
	 freq *= 1000;
	 if (OFLG_ISSET(CLOCK_OPTION_ICD2061A, &s3InfoRec.clockOptions)) {
            clockNo = ICD2061ACalcClock(freq, 2);
            ICD2061ASetClock(clockNo);
            ICD2061ASetClock(clockNo);
            ICD2061ASetClock(clockNo);
	 } else {
	    AltICD2061SetClock(freq, 2);
	    AltICD2061SetClock(freq, 2);
	    AltICD2061SetClock(freq, 2);
	 }
         outb(vgaCRIndex, 0x42);/* select the clock */
         outb(vgaCRReg, 0x02);
	 usleep(150000);
      }
   }
   LOCK_SYS_REGS;
   return(result);
}
