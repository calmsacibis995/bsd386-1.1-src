/* $XFree86: mit/server/ddx/x386/x386Version.h,v 2.44 1993/10/18 12:16:19 dawes Exp $ */

#define X386_VERSION " 2.0 "
