#!/bin/sh
prog=$1
dir=$2

$prog $dir/.* $dir/*

