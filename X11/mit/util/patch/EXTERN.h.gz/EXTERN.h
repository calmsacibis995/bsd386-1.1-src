/* $Header: EXTERN.h,v 2.0 86/09/17 15:35:37 lwall Exp $
 *
 * $Log:	EXTERN.h,v $
 * Revision 2.0  86/09/17  15:35:37  lwall
 * Baseline for netwide release.
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
