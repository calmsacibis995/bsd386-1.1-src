/* $Header: version.h,v 2.0 86/09/17 15:40:14 lwall Exp $
 *
 * $Log:	version.h,v $
 * Revision 2.0  86/09/17  15:40:14  lwall
 * Baseline for netwide release.
 * 
 */

void version();
