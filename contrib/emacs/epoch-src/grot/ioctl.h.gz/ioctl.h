
/*
 * $Header: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/grot/ioctl.h,v 1.1.1.1 1992/07/28 00:45:34 polk Exp $
 */
/* Emacs ioctl emulation for VMS */
