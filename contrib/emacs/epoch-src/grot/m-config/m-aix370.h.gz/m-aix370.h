
/*
 * $Header: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/grot/m-config/m-aix370.h,v 1.1.1.1 1992/07/28 00:45:42 polk Exp $
 */
#ifndef LINT
static char rcsid[] = "$Author: polk $ $Date: 1992/07/28 00:45:42 $ $Source: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/grot/m-config/m-aix370.h,v $ $Revision: 1.1.1.1 $";
#endif
/* m- file for ibm aix370.
   Copyright (C) 1989 Free Software Foundation, Inc.

This file is part of GNU Emacs.

GNU Emacs is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.  No author or distributor
accepts responsibility to anyone for the consequences of using it
or for whether it serves any particular purpose or works at all,
unless he says so in writing.  Refer to the GNU Emacs General Public
License for full details.

Everyone is granted permission to copy, modify and redistribute
GNU Emacs, but only under the conditions described in the
GNU Emacs General Public License.   A copy of this license is
supposed to have been given to you along with GNU Emacs so you
can know your rights and responsibilities.  It should be in a
file named COPYING.  Among other things, the copyright notice
and this notice must be preserved on all copies.  */

/* The following three symbols give information on
 the size of various data types.  */

#define SHORTBITS 16		/* Number of bits in a short */

#define INTBITS 32		/* Number of bits in an int */

#define LONGBITS 32		/* Number of bits in a long */

/* i370 is big-endian: lowest numbered byte is most significant. */

#define BIG_ENDIAN

/* Define NO_ARG_ARRAY if you cannot take the address of the first of a
 * group of arguments and treat it as an array of the arguments.  */

#define NO_ARG_ARRAY

/* Define how to take a char and sign-extend into an int.
   On machines where char is signed, this is a no-op.  */

#define SIGN_EXTEND_CHAR(c) ((((int) (c)) << 24) >> 24) 
#define EXPLICIT_SIGN_EXTEND

/* Now define a symbol for the cpu type, if your compiler
   does not define it automatically:
   Ones defined so far include vax, m68000, ns16000, pyramid,
   orion, tahoe, APOLLO and many others */

#define AIX370
#define xa370
#ifndef AIX
#define AIX
#endif
#undef  SYSTEM_TYPE
#define SYSTEM_TYPE "ibm-aix-370"

/* Use type int rather than a union, to represent Lisp_Object */

#define NO_UNION_TYPE

/* AIX 370 and 386 are COFF */
 
#define COFF

/* use curses, so we get all the stuff in terminf, especially hft's */

#define LIBS_TERMCAP -lcurses

/* AIX no libg */
 
#define LIBS_DEBUG


/* stud01@CC4.KULEUVEN.AC.BE (Barbe Albert) suggests this addition. */

#define START_FILES pre-crt0.o /lib/mcrt0.o


/* Define VIRT_ADDR_VARIES if the virtual addresses of
   pure and impure space as loaded can vary, and even their
   relative order cannot be relied on.

   Otherwise Emacs assumes that text space precedes data space,
   numerically.  */

/* Define addresses, macros, change some setup for dump */

#define NO_REMAP

/* Since NO_REMAP, problem with statics doesn't exist */
#undef static

#define _setjmp setjmp
#define _longjmp longjmp
 
#define TEXT_START 0
#define SEGMENT_MASK 0

/* Load on page boundary */
 
/* Fix provided by stud01@CC4.KULEUVEN.AC.BE (Barbe Albert). */
/* #define DATA_SECTION_ALIGNMENT 0x00000fff */
#define DATA_SECTION_ALIGNMENT 0x00001000


/* delete the following line to foil optimization, enable debugging */
#define C_DEBUG_SWITCH -g
 
#define C_SWITCH_MACHINE -DDOPTIONS -D_BSD -Hoff=Char_default_unsigned

#define LIBX11_MACHINE -lX11

#define BSTRING
#define HAVE_DUP2
#define HAVE_GETTIMEOFDAY
#define HAVE_SELECT
#define HAVE_TIMEVAL
#define HAVE_VFORK

/*
 * 	Define SYSV_SYSTEM_DIR to use the V.3 getdents/readir
 *	library functions.  Almost, but not quite the same as
 *	the 4.2 functions
 */
#define SYSV_SYSTEM_DIR
#define HAVE_CLOSEDIR  /* This system, unlike ordinary SYSV, has closedir.  */

/*
 *	Define NONSYSTEM_DIR_LIBRARY to make Emacs emulate
 *      The 4.2 opendir, etc., library functions.
 */
#undef  NONSYSTEM_DIR_LIBRARY

/* But don't use utimes() -- it causes SIGSEGV!  Use utime() instead. */
#define USE_UTIME

/* AIX defines FIONREAD, but it does not work.  */
/* #define BROKEN_FIONREAD */

/* Define C_ALLOCA if this machine does not support a true alloca
   and the one written in C should be used instead.
   Define HAVE_ALLOCA to say that the system provides a properly
   working alloca function and it should be used.
   Define neither one if an assembler-language alloca
   in the file alloca.s should be used.  */

#define C_ALLOCA
#define STACK_DIRECTION -1 /* tell alloca.c which way it grows */
#define LIBS_MACHINE -lbsd

#define DEFAULT_ENTRY_ADDRESS start
#define OBJECTS_MACHINE hftctl.o
#define LD_SWITCH_MACHINE -xa 
