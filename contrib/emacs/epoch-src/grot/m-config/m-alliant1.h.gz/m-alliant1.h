/* config.h should include this file for version 1 of Alliant's
   operating system.  */

#define ALLIANT_1
#include "m-alliant.h"
