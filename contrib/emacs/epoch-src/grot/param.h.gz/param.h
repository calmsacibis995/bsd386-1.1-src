
/*
 * $Header: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/grot/param.h,v 1.1.1.1 1992/07/28 00:45:35 polk Exp $
 */

/* This is so that Emacs can run on VMS... */
#define EXEC_PAGESIZE 512
