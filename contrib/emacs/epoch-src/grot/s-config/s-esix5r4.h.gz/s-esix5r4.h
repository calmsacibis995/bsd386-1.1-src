/* Definitions for ESIX System V 4.0.3A, a variant of V.4 for the 386.  */

#include "s-usg5-4.h"

#define LIB_X11_LIB     -lsocket -lc /usr/lib/libX11.so.4.2
#define C_SWITCH_SYSTEM -DBSTRING
