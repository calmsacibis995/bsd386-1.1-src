#include "s-vms.h"
#define VMS4_0
