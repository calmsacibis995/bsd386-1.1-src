
/*
 * $Header: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/grot/vlimit.h,v 1.1.1.1 1992/07/28 00:45:35 polk Exp $
 */

/* Dummy for Emacs so that we can run on VMS... */
#define LIM_DATA 0
