/* undo handling for GNU Emacs.
   Copyright (C) 1990 Free Software Foundation, Inc.

This file is part of GNU Emacs.

GNU Emacs is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 1, or (at your option)
any later version.

GNU Emacs is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU Emacs; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/*
 * $Revision: 1.1.1.1 $
 * $Source: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/undo.c,v $
 * $Date: 1992/07/28 00:45:31 $
 * $Author: polk $
 */
#ifndef LINT
static char rcsid[] = "$Author: polk $ $Date: 1992/07/28 00:45:31 $ $Source: /bsdi/MASTER/BSDI_OS/contrib/emacs/epoch-src/undo.c,v $ $Revision: 1.1.1.1 $";
#endif

#include "config.h"
#include "lisp.h"
#include "buffer.h"
#include "window.h"
#include "button.h"

#ifdef DEFINE_CHANGE_FUNCTIONS
/* Functions to call before and after each text change. */
Lisp_Object Vbefore_change_function;
Lisp_Object Vafter_change_function;
Lisp_Object Vafter_movement_function;
#endif

/* Last buffer for which undo information was recorded.  */
Lisp_Object last_undo_buffer;

#ifdef DEFINE_CHANGE_FUNCTIONS
/* Record whether before_change_function or after_change_function are active.
 */
/* This variable could be replaced by a buffer-local variable. */
static int change_function_active;

/* Allow change functions to be used again
   even if there was an error or signal. */
change_function_restore (arg)
     Lisp_Object arg;
{
  change_function_active = 0;
}

/* signal a change to the buffer immediatly before it happens */
signal_before_change (pos, delpos)
  int pos, delpos;
{
  int count = specpdl_ptr - specpdl;

  if (!NULL (Vbefore_change_function) && (!change_function_active))
      {
        change_function_active = 1;
        record_unwind_protect (change_function_restore, Qnil);
        call2(Vbefore_change_function,
              make_number(pos),
              make_number(delpos));
        unbind_to (count);
      }
}
/* signal the previous change immediatly after it happens */
signal_after_change (pos, inspos, dellen)
     int pos, inspos, dellen;
{
  int count = specpdl_ptr - specpdl;

  if (!NULL (Vafter_change_function) && (!change_function_active))
      {
        change_function_active = 1;
        record_unwind_protect (change_function_restore, Qnil);
        call3(Vafter_change_function,
             make_number(pos),
             make_number(inspos),
             make_number(dellen));
        unbind_to (count);
      }
}

/* signal after cursor movement (no text changes) */
signal_after_movement(last_point)
     int last_point;
{
  int count = specpdl_ptr - specpdl;

  if (!NULL(Vafter_movement_function) && (!change_function_active))
    {
      change_function_active = 1;
      record_unwind_protect (change_function_restore,Qnil);
      call1(Vafter_movement_function,
	    make_number(last_point));
      unbind_to(count);
    }
}

#endif

/* Record an insertion that just happened or is about to happen,
   for LENGTH characters at position BEG.
   (It is possible to record an insertion before or after the fact
   because we don't need to record the contents.)  */

record_insert (beg, length)
     Lisp_Object beg, length;
{
  Lisp_Object lbeg, lend;

  if (current_buffer != XBUFFER (last_undo_buffer))
    Fundo_boundary ();
  XSET (last_undo_buffer, Lisp_Buffer, current_buffer);

  if (EQ (current_buffer->undo_list, Qt))
    return;
  if (MODIFF <= current_buffer->save_modified)
    record_first_change ();

  /* If this is following another insertion and consecutive with it
     in the buffer, combine the two.  */
  if (XTYPE (current_buffer->undo_list) == Lisp_Cons)
    {
      Lisp_Object elt;
      elt = XCONS (current_buffer->undo_list)->car;
      if (XTYPE (elt) == Lisp_Cons
	  && XTYPE (XCONS (elt)->car) == Lisp_Int
	  && XTYPE (XCONS (elt)->cdr) == Lisp_Int
	  && XINT (XCONS (elt)->cdr) == beg)
	{
	  XSETINT (XCONS (elt)->cdr, beg + length);
	  return;
	}
    }

  XFASTINT (lbeg) = beg;
  XFASTINT (lend) = beg + length;
  current_buffer->undo_list = Fcons (Fcons (lbeg, lend), current_buffer->undo_list);
}

/* Record that a deletion is about to take place,
   for LENGTH characters at location BEG with BTN_LIST affected buttons.  */

record_delete (beg, length,btn_list)
     int beg, length;
     Lisp_Object btn_list;
{
  Lisp_Object lbeg, llength, lend, sbeg;
  Lisp_Object bstart,bend;
  Lisp_Object button,buttons = Qnil;

  if (current_buffer != XBUFFER (last_undo_buffer))
    Fundo_boundary ();
  XSET (last_undo_buffer, Lisp_Buffer, current_buffer);

  if (EQ (current_buffer->undo_list, Qt))
    return;
  if (MODIFF <= current_buffer->save_modified)
    record_first_change ();

  if (point == beg + length)
    XSET (sbeg, Lisp_Int, -beg);
  else
    XFASTINT (sbeg) = beg;
  XFASTINT (lbeg) = beg;
  XFASTINT (llength) = length;
  XFASTINT (lend) = beg + length;

  /* Accumulate info regarding affected buttons.
   * Must store the button object as well as present start and end pos
   * Button info is a list of elements, each element being a list
   * (oldstart oldend button)
   */
  while (CONSP(btn_list))
    {
      button = Fcar(btn_list);
      
      buttons =
	Fcons(Fcons(make_number(marker_position(XBUTTON(button)->start)),
		    Fcons(make_number(marker_position(XBUTTON(button)->end)),
			  Fcons(button,Qnil))),
	      buttons);
      btn_list = Fcdr(btn_list);
    }

  /* Add this to undo list for buffer.  Form is:
   * ("text" pos button-list)
   */
  current_buffer->undo_list =
    Fcons (Fcons (Fbuffer_substring(lbeg,lend),
		  Fcons (sbeg,buttons)),
	   current_buffer->undo_list);
}

/* Record that a replacement is about to take place,
   for LENGTH characters at location BEG.
   The replacement does not change the number of characters.  */

record_change (beg, length)
     int beg, length;
{
  record_delete (beg, length, Qnil);
  record_insert (beg, length);
}

/* Record that an unmodified buffer is about to be changed.
   Record the file modification date so that when undoing this entry
   we can tell whether it is obsolete because the file was saved again.  */

record_first_change ()
{
  Lisp_Object high, low;
  XFASTINT (high) = (current_buffer->modtime >> 16) & 0xffff;
  XFASTINT (low) = current_buffer->modtime & 0xffff;
  current_buffer->undo_list = Fcons (Fcons (Qt, Fcons (high, low)), current_buffer->undo_list);
}

DEFUN ("undo-boundary", Fundo_boundary, Sundo_boundary, 0, 0, 0,
  "Mark a boundary between units of undo.\n\
An undo command will stop at this point,\n\
but another undo command will undo to the previous boundary.")
  ()
{
  Lisp_Object tem;
  if (EQ (current_buffer->undo_list, Qt))
    return Qnil;
  tem = Fcar (current_buffer->undo_list);
  if (!NULL (tem))
    current_buffer->undo_list = Fcons (Qnil, current_buffer->undo_list);
  return Qnil;
}

/* At garbage collection time, make an undo list shorter at the end,
   returning the truncated list.
   MINSIZE and MAXSIZE are the limits on size allowed, as described below.
   In practice, these are the values of undo-threshold and
   undo-high-threshold.  */

Lisp_Object
truncate_undo_list (list, minsize, maxsize)
     Lisp_Object list;
     int minsize, maxsize;
{
  Lisp_Object prev, next, save_prev;
  int size_so_far = 0;

  prev = Qnil;
  next = list;
  save_prev = Qnil;

  while (XTYPE (next) == Lisp_Cons)
    {
      Lisp_Object elt;
      elt = XCONS (next)->car;

      /* When we get to a boundary, decide whether to truncate
	 either before or after it.  The lower threshold, MINSIZE,
	 tells us to truncate after it.  If its size pushes past
	 the higher threshold MAXSIZE as well, we truncate before it.  */
      if (NULL (elt))
	{
	  if (size_so_far > maxsize)
	    break;
	  save_prev = prev;
	  if (size_so_far > minsize)
	    break;
	}

      /* Add in the space occupied by this element and its chain link.  */
      size_so_far += 8;
      if (XTYPE (elt) == Lisp_Cons)
	{
	  size_so_far += 8;
	  if (XTYPE (XCONS (elt)->car) == Lisp_String)
	    size_so_far += 6 + XSTRING (XCONS (elt)->car)->size;
	}

      /* Advance to next element.  */
      prev = next;
      next = XCONS (next)->cdr;
    }

  /* If we scanned the whole list, it is short enough; don't change it.  */
  if (NULL (next))
    return list;

  /* Truncate at the boundary where we decided to truncate.  */
  if (!NULL (save_prev))
    {
      XCONS (save_prev)->cdr = Qnil;
      return list;
    }
  else
    return Qnil;
}

DEFUN ("primitive-undo", Fprimitive_undo, Sprimitive_undo, 2, 2, 0,
  "Undo N records from the front of the list LIST.\n\
Return what remains of the list.")
  (count, list)
     Lisp_Object count, list;
{
  register int arg = XINT (count);

  extern int buffer_shared;
  extern Lisp_Object selected_window;
  extern int update_mode_lines;
  
#if 0  /* This is a good feature, but would make undo-start
	  unable to do what is expected.  */
  Lisp_Object tem;

  /* If the head of the list is a boundary, it is the boundary
     preceding this command.  Get rid of it and don't count it.  */
  tem = Fcar (list);
  if (NULL (tem))
    list = Fcdr (list);
#endif

  while (arg > 0)
    {
      while (1)
	{
	  Lisp_Object next, car, cdr, cadr, cddr;
	  next = Fcar (list);
	  list = Fcdr (list);
	  if (NULL (next))
	    break;
	  car = Fcar (next);
	  cdr = Fcdr (next);
	  cadr = CONSP(cdr) ? Fcar(cdr) : Qnil;
	  cddr = CONSP(cdr) ? Fcdr(cdr) : Qnil;
	  if (EQ (car, Qt))
	    {
	      Lisp_Object high, low;
	      int mod_time;
	      high = Fcar (cdr);
	      low = Fcdr (cdr);
	      mod_time = (high << 16) + low;
	      /* If this records an obsolete save
		 (not matching the actual disk file)
		 then don't mark unmodified.  */
	      if (mod_time != current_buffer->modtime)
		break;
#ifdef CLASH_DETECTION
	      Funlock_buffer ();
#endif /* CLASH_DETECTION */
	      Fset_buffer_modified_p (Qnil);
	      if (current_buffer == XBUFFER(XWINDOW(selected_window)->buffer)
		  && buffer_shared == 1)
		{
		  update_mode_lines = 0;
		  XWINDOW(selected_window)->update_mode_line = Qt;
		}
	    }
	  else if (XTYPE (car) == Lisp_Int && XTYPE (cdr) == Lisp_Int)
	    {
	      Lisp_Object end;
	      if (XINT (car) < BEGV
		  || XINT (cdr) > ZV)
		error ("Changes to be undone are outside visible portion of buffer");
	      Fdelete_region (car, cdr);
	      Fgoto_char (car);
	    }
	  else if (XTYPE (car) == Lisp_String && XTYPE (cadr) == Lisp_Int)
	    {
	      Lisp_Object membuf;
	      int pos = XINT (cadr);
	      membuf = car;
	      if (pos < 0)
		{
		  if (-pos < BEGV || -pos > ZV)
		    error ("Changes to be undone are outside visible portion of buffer");
		  SET_PT (-pos);
		  Finsert (1, &membuf);
		}
	      else
		{
		  if (pos < BEGV || pos > ZV)
		    error ("Changes to be undone are outside visible portion of buffer");
		  SET_PT (pos);
		  Finsert_before_markers (1, &membuf);
		  SET_PT (pos);
		}
	      /* Now restore buttons (if any) */
	      while (CONSP(cddr))
		{
		  Lisp_Object binfo = Fcar(cddr);
		  Lisp_Object button = Fcar(Fcdr(Fcdr(binfo)));

		  if (BUTTONP(button) && !NULL(Fbutton_buffer(button)))
		    {
		      Fmove_button(button,Fcar(binfo),Fcar(Fcdr(binfo)),Qnil);
		    }

		  cddr = Fcdr(cddr);
		}
	    }
	}
      arg--;
    }

  return list;
}

syms_of_undo ()
{
  defsubr (&Sprimitive_undo);
  defsubr (&Sundo_boundary);
#ifdef DEFINE_CHANGE_FUNCTIONS
  change_function_active = 0; /* initially inactive */

  DEFVAR_LISP ("before-change-function", &Vbefore_change_function,
              "Function to call before each text change.\n\
 Two arguments are passed to the function: the position of the change\n\
 and the position of end of the region deleted.\n\
 \n\
 While executing the before-change-function, changes to buffers do not\n\
 cause calls to any before-change-function or after-change-function.");
   Vbefore_change_function = Qnil;

  DEFVAR_LISP ("after-change-function", &Vafter_change_function,
              "Function to call after each text change.\n\
 Three arguments are passed to the function: the position of the change,\n\
 the position of the end of the region deleted, and the position of \n\
 the end of the region inserted.\n\
 \n\
 While executing the after-change-function, changes to buffers do not\n\
 cause calls to any before-change-function or after-change-function.");
   Vafter_change_function = Qnil;

  DEFVAR_LISP ("after-movement-function", &Vafter_movement_function,
	       "Function to call after point movement (with no text change).\n\
 No arguments are passed to this function.\n\
 \n\
 While executing the after-movement-function, changes to buffers do not\n\
 cause calls to any before-change or after-change function.");
  Vafter_movement_function = Qnil;

#endif
}
