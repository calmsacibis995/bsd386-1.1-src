/* This is so that Emacs can run on VMS... */
#define EXEC_PAGESIZE 512
