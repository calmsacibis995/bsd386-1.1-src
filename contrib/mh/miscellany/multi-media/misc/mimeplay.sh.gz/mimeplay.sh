#!/bin/sh -f

P=/tmp/mime$$.mhn Q=/tmp/mime$$.sh

cat > $P

echo "trap \"rm -f $P $Q\" 0 1 2 3 13 15"		 > $Q
echo "mhn -file $P -show"				>> $Q
echo "echo -n \"Press <return> to continue... \""	>> $Q
echo "read x"						>> $Q
chmod +x $Q

(xterm -e $Q >/dev/null 2>&1 &) &
