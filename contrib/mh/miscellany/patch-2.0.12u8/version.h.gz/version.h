/* $Header: /bsdi/MASTER/BSDI_OS/contrib/mh/miscellany/patch-2.0.12u8/version.h,v 1.1.1.1 1994/01/04 22:31:29 sanders Exp $
 *
 * $Log: version.h,v $
 * Revision 1.1.1.1  1994/01/04  22:31:29  sanders
 * Initial import of MH 6.8.3
 *
 * Revision 2.0  86/09/17  15:40:14  lwall
 * Baseline for netwide release.
 * 
 */

void version();
