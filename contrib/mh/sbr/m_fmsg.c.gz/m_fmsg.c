/* m_fmsg.c - free a folder */
#ifndef	lint
static char ident[] = "@(#)$Id: m_fmsg.c,v 1.1.1.1 1994/01/04 22:30:26 sanders Exp $";
#endif	/* lint */

#include "../h/mh.h"
#include <stdio.h>


void	m_fmsg (mp)
register struct msgs *mp;
{
    register int    i;

    if (mp == NULL)
	return;

    if (mp -> foldpath)
	free (mp -> foldpath);
#ifdef	MTR
    free ((char *) mp -> msgbase);
#endif	/* MTR */
    for (i = 0; mp -> msgattrs[i]; i++)
	free (mp -> msgattrs[i]);
    free ((char *) mp);
}
