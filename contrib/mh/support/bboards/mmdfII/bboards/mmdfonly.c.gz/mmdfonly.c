/* mmdfonly.c - subroutines for stand-alone BBoards MMDF-II channel */


/* VARARGS2 */

void admonish (what, fmt, a, b, c, d, e, f)
char   *what,
       *fmt,
       *a,
       *b,
       *c,
       *d,
       *e,
       *f;
{
}
