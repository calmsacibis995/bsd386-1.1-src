/* popauth.h - POP authorization DB definitions */
/* @(#)$Id: popauth.h,v 1.1.1.1 1994/01/04 22:30:10 sanders Exp $ */


struct authinfo {
    char    auth_secret[16];
    int	    auth_secretlen;
};
