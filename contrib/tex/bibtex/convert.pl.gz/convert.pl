#!/bin/sh
# Convert Bibtex to C.
# 
sed=/bin/sed

cat ../lib/common.defines $1 \
	| ../web2c/web2c -hconfig.h \
        | $sed -e '1a\
\#include \<setjmp.h\> \
jmp_buf jmp9998, jmp32; int lab31=0;
s/goto lab31 ; /{lab31=1; return;}/
s/goto lab32/longjmp(jmp32,1)/
s/goto lab9998/longjmp(jmp9998,1)/g
s/lab31://
s/lab32://
s/hack1 () ;/if(setjmp(jmp9998)==1) goto lab9998;if(setjmp(jmp32)==0)while(true)/
s/hack2 ()/break/
/^void main_body/,$s/while ( true/while ( lab31==0/' \
	| ../web2c/fixwrites > $2

$sed -e 's/(buftype)//g' -e 's/(pdstype)//g' < coerce.h > xcoerce.h
mv -f xcoerce.h coerce.h
