/* This file is present just so pathsrch.h can include it (TeX is an
   exception in needing a configuration file to specify more than
   paths).  */
